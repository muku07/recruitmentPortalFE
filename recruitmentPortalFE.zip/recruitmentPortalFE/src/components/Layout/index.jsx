import React from "react";
import Footer from "../Footer";
import LogoHeader from "../LogoHeader";
import SideBar from "../SideBar";

import { Outlet } from "react-router-dom";

export const Layout = () => {
  return (
    <>
      <SideBar />
      <Outlet />
      <Footer />
    </>
  );
};
