import React from "react";
import ReactRoundedImage from "react-rounded-image";
import MyPhoto from "../../assets/your-img.png";
import { Maindiv } from "./AvatarElements";

function AvatarElement() {
  return (
    <Maindiv>
      <ReactRoundedImage
        roundedColor="white"
        image={MyPhoto}
        roundedSize="2"
        imageWidth="80"
        imageHeight="80"
      />
    </Maindiv>
  );
}

export default AvatarElement;
