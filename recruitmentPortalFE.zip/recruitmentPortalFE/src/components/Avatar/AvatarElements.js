import styled from "styled-components";

export const Maindiv = styled.div`
  display: "flex";
  background-color: #fff;
  margin-top: 2%;
  margin-left: 28%;
  width: 0vh;
  //z-index: -1;
 // z-index: 9;
 // height: 50vh;
 position:relative;
`;
