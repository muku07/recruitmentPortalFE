import { DateTime } from "luxon";

const Direction = {
  ASCENDING: 1,
  DESCENDING: 0,
};

export let initialState = {
  blogs: [],
  defaultBlogsOrder: [],
  updateBlogs: {},
  drawerOpen: false,
  dateDirection: Direction.ASCENDING,
  dateTimeScopeFrom: null,
  dateTimeScopeTo: null,
  nameDirection: Direction.ASCENDING,
  tagSearchQuery: "",
  selectedTags: [],
  defaultSelectedTags: [],
  blogSearchQuery: "",
  blogSearchQueryLength: 0,
  updateExpandFirst: {},
};

// this assumes passed dates are in USA format of month/day/year
const parseDate = (dateAsString) => {
  // var dateParts = dateAsString.split("/");

  // // new Date(year, monthIndex, day)
  // let date = new Date(
  //   parseInt(dateParts[2], 10),
  //   parseInt(dateParts[0], 10) - 1,
  //   parseInt(dateParts[1], 10)
  // );
  // return date;
  return DateTime.fromFormat(dateAsString, "yyyy-MM-dd", {});
};

export function searchBlogsByTitle(allBlogs, searchQuery) {
  const searchBy = "title";
  // If length of allBlogs isn't 0: filter the blogs based upon the filterBy const;
  let filteredBlogs =
    allBlogs && allBlogs.length > 0
      ? allBlogs.slice().filter((blog) => {
          if (
            blog[searchBy]?.toLowerCase().includes(searchQuery?.toLowerCase())
          )
            return blog;
        })
      : allBlogs;

  return filteredBlogs;
}

export function reducer(state, action) {
  switch (action.type) {
    case "init": {
      // used to reset state easier
      initialState = {
        ...initialState,
        defaultBlogsOrder: action.blogs,
        blogs: action.blogs,
        updateBlogs: action.updateBlogsFunction,
        selectedTags: action.tags,
        defaultSelectedTags: action.tags,
      };

      return {
        ...state,
        defaultBlogsOrder: action.blogs,
        blogs: action.blogs,
        updateBlogs: action.updateBlogsFunction,
        selectedTags: action.tags,
        defaultSelectedTags: action.tags,
        // updateExpandFirst: action.updateExpandFirstFunction,
        // dateTimeScopeTo: DateTime.local(DateTime.now()),
      };
    }

    case "drawer":
      switch (action.sesame) {
        case "open":
          document.getElementById("drawer-close")?.classList.remove("fadeout");
          document.getElementById("drawer-open")?.classList.add("fadeout");
          return { ...state, drawerOpen: true };
        case "close":
          document.getElementById("drawer-close")?.classList.add("fadeout");
          document.getElementById("drawer-open")?.classList.remove("fadeout");
          return { ...state, drawerOpen: false };
      }
    case "clear": {
      const filterContainer = document.getElementById("FilterSortChips");
      for (const chip of filterContainer.childNodes) {
        chip.classList.remove("deselected");
      }

      state.updateBlogs(
        searchBlogsByTitle(state.defaultBlogsOrder, state.blogSearchQuery)
      );
      return {
        ...initialState,
        // dateTimeScopeFrom: null,
        // dateTimeScopeTo: null,
      };
    }
    case "search": {
      console.log(action.query.length);
      let searchedBlogs = searchBlogsByTitle(
        action.query.length > state.blogSearchQueryLength
          ? state.blogs
          : state.defaultBlogsOrder,
        action.query
      );

      searchedBlogs = searchedBlogs
        .filter((blog) =>
          // filter out the blogs that use a language not in the selected list.
          blog.tags === null
            ? true
            : blog.tags.every((lang) => state.selectedTags.indexOf(lang) > -1)
        )
        .sort((a, b) =>
          state.dateDirection == Direction.ASCENDING
            ? parseDate(a.submittedDate) > parseDate(b.submittedDate)
            : parseDate(a.submittedDate) < parseDate(b.submittedDate)
        )
        .sort((a, b) =>
          state.nameDirection == Direction.ASCENDING
            ? ("" + a.title).localeCompare(b.title)
            : ("" + b.title).localeCompare(a.title)
        );

      state.updateBlogs([...searchedBlogs]);
      return {
        ...state,
        blogSearchQuery: action.query,
        blogSearchQueryLength: action.query.length,
        blogs: searchedBlogs,
      };
    }
    case "date":
      switch (action.task) {
        case "ascending": {
          let ascBlogs = state.blogs.slice();
          ascBlogs.sort(
            (a, b) => parseDate(b.submittedDate) - parseDate(a.submittedDate)
          );

          state.updateBlogs([...ascBlogs]);
          return {
            ...state,
            dateDirection: Direction.ASCENDING,
            blogs: ascBlogs,
          };
        }
        case "descending": {
          let descBlogs = state.blogs.slice();
          descBlogs.sort(
            (a, b) => parseDate(a.submittedDate) - parseDate(b.submittedDate)
          );

          state.updateBlogs([...descBlogs]);
          return {
            ...state,
            dateDirection: Direction.DESCENDING,
            blogs: descBlogs,
          };
        }
        case "from": {
          let newBlogs = state.defaultBlogsOrder
            .slice()
            .filter(
              (blog) =>
                action.value <= parseDate(blog.submittedDate) &&
                (blog.tags == undefined ||
                  blog.tags?.every(
                    (lang) => state.selectedTags.indexOf(lang) > -1
                  ))
            );

          state.updateBlogs([...newBlogs]);
          return {
            ...state,
            dateTimeScopeFrom: action.value,
            blogs: [...newBlogs],
          };
        }
        case "to": {
          let newBlogs = state.defaultBlogsOrder
            .slice()
            .filter(
              (blog) =>
                action.value >= parseDate(blog.submittedDate) &&
                (blog.tags == undefined ||
                  blog.tags?.every(
                    (lang) => state.selectedTags.indexOf(lang) > -1
                  ))
            );

          state.updateBlogs([...newBlogs]);
          return {
            ...state,
            dateTimeScopeTo: action.value,
            blogs: [...newBlogs],
          };
        }
      }
    case "name":
      switch (action.task) {
        case "a-z": {
          let ascBlogs = state.blogs
            .slice()
            .sort((a, b) => ("" + a.title).localeCompare(b.title));

          state.updateBlogs([...ascBlogs]);
          return {
            ...state,
            nameDirection: Direction.ASCENDING,
            blogs: ascBlogs,
          };
        }
        case "z-a": {
          let descBlogs = state.blogs
            .slice()
            .sort((a, b) => ("" + b.title).localeCompare(a.title));

          state.updateBlogs([...descBlogs]);
          return {
            ...state,
            nameDirection: Direction.DESCENDING,
            blogs: [...descBlogs],
          };
        }
      }
    case "tags":
      switch (action.task) {
        case "toggleTag": {
          let newTags = state.selectedTags.slice();
          let newBlogs = state.blogs.slice();

          if (newTags.includes(action.value)) {
            // tag already enabled, will get disabled
            newTags = newTags.filter((i) => i !== action.value); // remove from tags
            action.element.classList.add("deselected"); // add CSS class
            newBlogs = newBlogs.filter(
              (blog) => !blog.tags?.includes(action.value)
            );
          } else {
            // tag already disabled, will get enabled
            newTags = [...newTags, action.value]; // add to new tags
            action.element.classList.remove("deselected"); // remove CSS class

            let blogsWithTag = searchBlogsByTitle(
              state.defaultBlogsOrder,
              state.blogSearchQuery
            ).filter((blog) =>
              // filter out blogs that don't have the toggled tag
              blog.tags?.includes(action.value) ||
              // filter out the blogs that use a language not in the selected list.
              blog.tags === null
                ? true
                : blog.tags.every((lang) => newTags.indexOf(lang) > -1)
            );

            // combine these with blogs already present on the page
            newBlogs = new Set([...blogsWithTag, ...state.blogs]);
          }
          state.updateBlogs([...newBlogs]);

          return {
            ...state,
            selectedTags: [...newTags],
            blogs: [...newBlogs],
          };
        }
        case "search": {
          if (action.query.length == 0)
            return { ...state, selectedTags: state.defaultSelectedTags };

          let newTags = state.selectedTags
            .slice()
            .filter((tag) =>
              tag.toLowerCase().includes(action.query.toLowerCase())
            );

          return { ...state, selectedTags: [...newTags] };
        }
      }
    default:
      throw new Error(`Unknown action type: ${action.type}`);
  }
}
