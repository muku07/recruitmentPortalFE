import SwipeableDrawer from "@mui/material/SwipeableDrawer";
import { styled } from "@mui/material/styles";
import Typography from "@mui/material/Typography";

export const FilterSortContainer = styled("div")`
  position: fixed;
  right: 0;
  top: 0;
  margin: 0 !important;
  display: flex;
  flex-direction: column;
`;

export const SwipeableDrawerTypography = styled(Typography)`
  & * {
  }
`;

export const StyledSwipeableDrawer = styled(SwipeableDrawer)`
  & > .MuiPaper-root {
    display: flex;
    flex-direction: row;
    background-color: transparent !important;
    overflow: visible;
    /* transition: transform 500ms cubic-bezier(0, 0, 0.2, 1); */

    & > .fadeout {
      opacity: 0;
      scale: 0;
      transform: translateX(-1.35rem);
      transition-delay: 175ms;
      transition: opacity 1s linear, scale 1s linear !important;
    }

    // target the close FAB/button
    & > button {
      position: absolute;
      z-index: -1;
      box-shadow: 0 0 0 0.05rem rgba(50, 50, 50, 0.2);
    }
    // target the vertical container in swipeable
    & > div {
      display: grid;
      grid-template-columns: 100%;
      align-content: start;
      grid-gap: 0.5rem;
      background-color: var(--bg-primary);
      padding: 0.75rem;
      max-width: 15rem;
      font-weight: 600 !important;
      overflow-y: scroll;
      & :not(label) {
        font-weight: 600;
      }
      & h6 {
        font-size: 2rem;
        &:first-of-type {
          margin: auto;
        }
      }
      .MuiTypography-subtitle2 {
        font-size: 1rem;
      }
      // target deselected tags
      & > div .deselected {
        color: var(--text);
        border-color: var(--disabled);
      }
    }
  }
`;
