import React, { useEffect, useReducer } from "react";
import Fab from "@mui/material/Button";
import TuneRoundedIcon from "@mui/icons-material/TuneRounded";
import DeleteForeverIcon from "@mui/icons-material/DeleteForever";
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";
import SearchIcon from "@mui/icons-material/Search";
import Button from "@mui/material/Button";
import Chip from "@mui/material/Chip";
import TextField from "@mui/material/TextField";
import Typography from "@mui/material/Typography";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { AdapterLuxon } from "@mui/x-date-pickers/AdapterLuxon";
import {
  StyledSwipeableDrawer,
  SwipeableDrawerTypography,
  FilterSortContainer,
} from "./FilterSortElements";
import AppliedFilters from "../AppliedFilters";
import { initialState, reducer } from "./reducer";
import { LocalizationProvider } from "@mui/x-date-pickers";
import { useGetTags } from "../../../Services/API/Utilities/BlogsApi";

const fabStyles = {
  backgroundColor: "var(--bg-primary)",
  borderRadius: "1rem 0 0 1rem",
  width: "3rem",
  margin: "1rem 0 auto 0",
  boxShadow: "0 0 0 0.05rem rgba(115, 115, 115, 0.6)",
  transition: "all 0.25s ease-in-out",
  "&:hover": {
    backgroundColor: "var(--bg-primary)",
    scale: "1.2",
    transform: "translateX(-0.2rem)",
  },
};

const menuChip = (label, onClick) => {
  return (
    <Chip
      variant="outlined"
      color="primary"
      size="small"
      label={label}
      onClick={onClick}
      sx={{ fontWeight: 600, borderWidth: "0.15rem" }}
    />
  );
};

function FilterSort({ allBlogs, updateState, searchQuery, expandFirst }) {
  const [state, dispatch] = useReducer(reducer, initialState);
  const [tags, error, loading] = useGetTags();

  useEffect(() => {
    dispatch({
      type: "init",
      updateBlogsFunction: updateState,
      blogs: allBlogs,
      tags: tags,
      updateExpandFirstFunction: expandFirst,
    });
  }, [tags]);

  useEffect(() => {
    if (searchQuery?.length > 0)
      dispatch({ type: "search", query: searchQuery });
  }, [searchQuery]);

  return (
    <FilterSortContainer sx={{ zIndex: 99 }}>
      <Fab
        id="drawer-open"
        variant="extended"
        onClick={() => dispatch({ type: "drawer", sesame: "open" })}
        sx={fabStyles}
      >
        <TuneRoundedIcon />
      </Fab>
      <StyledSwipeableDrawer
        anchor="right"
        open={state.drawerOpen}
        onClose={() => dispatch({ type: "drawer", sesame: "close" })}
        onOpen={() => dispatch({ type: "drawer", sesame: "open" })}
        variant="persistent"
      >
        <Fab
          id="drawer-close"
          onClick={() => dispatch({ type: "drawer", sesame: "close" })}
          sx={{
            ...fabStyles,
            left: "-3.75rem",
          }}
        >
          <CloseRoundedIcon />
        </Fab>
        <div>
          <SwipeableDrawerTypography variant="h6">
            Filter & Sort
          </SwipeableDrawerTypography>
          <Button onClick={() => dispatch({ type: "clear" })}>
            Clear all
            <DeleteForeverIcon />
          </Button>

          <Typography variant="subtitle2">By date:</Typography>
          {menuChip("Date desc", () =>
            dispatch({
              type: "date",
              task: "descending",
            })
          )}
          {menuChip("Date asc", () =>
            dispatch({
              type: "date",
              task: "ascending",
            })
          )}
          <LocalizationProvider
            dateAdapter={AdapterLuxon}
            adapterLocale={"en-gb"}
          >
            <DatePicker
              openTo="year"
              views={["year", "month", "day"]}
              label="From"
              value={state.dateTimeScopeFrom}
              mask={"dd/MM/yyyy"}
              inputFormat="dd/MM/yyyy"
              disableFuture
              onChange={(newDate) =>
                dispatch({ type: "date", task: "from", value: newDate })
              }
              renderInput={(params) => (
                <TextField {...params} helperText={null} id={"DateFromInput"} />
              )}
            />
            <DatePicker
              openTo="year"
              views={["year", "month", "day"]}
              label="To"
              value={state.dateTimeScopeTo}
              mask={"dd/MM/yyyy"}
              inputFormat="dd/MM/yyyy"
              disableFuture
              onChange={(newDate) =>
                dispatch({ type: "date", task: "to", value: newDate })
              }
              renderInput={(params) => (
                <TextField {...params} helperText={null} id={"DateToInput"} />
              )}
            />
          </LocalizationProvider>

          <Typography variant="subtitle2">By name:</Typography>
          {menuChip("A-Z", () => dispatch({ type: "name", task: "a-z" }))}
          {menuChip("Z-A", () => dispatch({ type: "name", task: "z-a" }))}

          <Typography variant="subtitle2">By tags:</Typography>
          <TextField
            variant="outlined"
            label="Search tags"
            InputProps={{
              endAdornment: <SearchIcon sx={{ color: "var(--disabled)" }} />,
            }}
            onChange={(e) =>
              dispatch({ type: "tags", task: "search", query: e.target.value })
            }
          />
          {loading ? (
            <>
              <p>Loading tags..</p>
              {error && <p>{error}</p>}
            </>
          ) : (
            <AppliedFilters
              id="FilterSortChips"
              filters={state.defaultSelectedTags}
              onClick={(event, tagValue) =>
                dispatch({
                  type: "tags",
                  task: "toggleTag",
                  value: tagValue,
                  element: event.currentTarget,
                })
              }
              styles={{ margin: "0.075rem 0.145rem" }}
            />
          )}
        </div>
      </StyledSwipeableDrawer>
    </FilterSortContainer>
  );
}

export default React.memo(FilterSort);
