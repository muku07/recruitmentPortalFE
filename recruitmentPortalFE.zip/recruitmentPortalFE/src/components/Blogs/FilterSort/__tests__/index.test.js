import React, { useState, useEffect } from "react";
import FilterSort from "..";
import BlogCard from "..";
import { render, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";

const test_blogs = [
  {
    blogId: 24,
    title: "Another Blog",
    publishedBy: "Max",
    blogImage: "http://dummyimage.com/204x221.png/cc0000/ffffff",
    typeId: 1,
    details: "This is the details of this blog",
    submittedDate: "2022-09-30",
    userId: 1,
    approvedDate: null,
    status: null,
    statusId: 3,
    tags: null,
  },
  {
    blogId: 27,
    title: "The second blog",
    publishedBy: "1",
    blogImage: "http://dummyimage.com/204x221.png/cc0000/ffffff",
    typeId: 1,
    details: "This is the details of this blog",
    submittedDate: "2022-10-04",
    userId: 1,
    approvedDate: null,
    status: null,
    statusId: 3,
    tags: null,
  },
  {
    blogId: 28,
    title: "Third blog",
    publishedBy: "1",
    blogImage: "http://dummyimage.com/204x221.png/cc0000/ffffff",
    typeId: 1,
    details: "This is the details of this blog",
    submittedDate: "2022-08-03",
    userId: 1,
    approvedDate: null,
    status: null,
    statusId: 3,
    tags: null,
  },
  {
    blogId: 29,
    title: "Last of the blogs",
    publishedBy: "1",
    blogImage: "http://dummyimage.com/204x221.png/cc0000/ffffff",
    typeId: 1,
    details: "This is the details of this blog",
    submittedDate: "2022-10-08",
    userId: 1,
    approvedDate: null,
    status: null,
    statusId: 3,
    tags: null,
  },
];

let drawerContainer;
let drawerContainerChildren;

test("Testing the component renders.", () => {
  render(<FilterSort />);
});

test("TEXT: Drawer title", () => {
  render(<FilterSort />);

  fireEvent.click(document.getElementById("drawer-open"));

  drawerContainer =
    document.getElementById("drawer-open").nextSibling.firstChild.lastChild;
  drawerContainerChildren = drawerContainer.childNodes;

  expect(drawerContainer).toBeVisible();

  expect(drawerContainerChildren[0].textContent).toBe("Filter and Sort");
});

test("TEXT: Clear all button", () => {
  expect(drawerContainerChildren[1].textContent).toBe("Clear all");
});

test("TEXT: by date", () => {
  expect(drawerContainerChildren[2].textContent).toBe("By date:");
});

test("TEXT: By date desc button", () => {
  expect(drawerContainerChildren[3].textContent).toBe("Date desc");
});

test("TEXT: By date asc button", () => {
  expect(drawerContainerChildren[4].textContent).toBe("Date asc");
});

test("TEXT: From date picker inner", () => {
  expect(drawerContainerChildren[5].textContent).toContain("From");
});

test("TEXT: To date pickers inner", () => {
  expect(drawerContainerChildren[6].textContent).toContain("To");
});

test("TEXT: By name", () => {
  expect(drawerContainerChildren[7].textContent).toBe("By name:");
});

test("TEXT: A-Z sorting button", () => {
  expect(drawerContainerChildren[8].textContent).toBe("A-Z");
});

test("TEXT: Z-A sorting button", () => {
  expect(drawerContainerChildren[9].textContent).toBe("Z-A");
});

test("TEXT: By tags text", () => {
  expect(drawerContainerChildren[10].textContent).toBe("By tags:");
});

test("TEXT: Search tags input text", () => {
  expect(drawerContainerChildren[11].textContent).toContain("Search tags");
});

let blogsToTest;
//https://stackoverflow.com/questions/66186191/react-testing-library-how-to-test-a-component-that-requires-the-usestate-hook-f
const Wrapper = () => {
  const [blogs, setBlogs] = useState(test_blogs);
  useEffect(() => (blogsToTest = blogs), [blogs]);
  return (
    <>
      <FilterSort allBlogs={blogs} updateState={setBlogs} />
      {blogs.length > 0 ? (
        blogs.map((blog) => <BlogCard key={blog.blogId} blog={blog} />)
      ) : (
        <h1 style={{ gridColumn: "1/-1", margin: "auto" }}>No results found</h1>
      )}
    </>
  );
};

test("Testing sorting by date descending", async () => {
  render(<Wrapper />);
  expect(blogsToTest[0].blogId === 24);

  //click the date desc button
  await fireEvent.click(
    document.getElementById("drawer-open").nextSibling.firstChild.lastChild
      .childNodes[3]
  );

  expect(blogsToTest[0].blogId).toBe(28);
});

test("Testing sorting by date ascending", async () => {
  render(<Wrapper />);

  expect(blogsToTest[0].blogId).toBe(24);

  //click the date asc button
  await fireEvent.click(
    document.getElementById("drawer-open").nextSibling.firstChild.lastChild
      .childNodes[4]
  );

  expect(blogsToTest[0].blogId).toBe(29);
});

test("Testing from date", async () => {
  render(<Wrapper />);

  expect(blogsToTest[0].blogId).toBe(24);
  const fromInput = document.getElementById("DateFromInput");

  expect(blogsToTest.length).toBe(4);

  await fireEvent.change(fromInput, { target: { value: "05/09/2022" } });
  await fireEvent.keyPress(fromInput, { key: "Enter", code: 13, charCode: 13 });

  expect(fromInput.value).toBe("05/09/2022");

  expect(blogsToTest.length).toBe(3);
});

test("Testing to date", async () => {
  render(<Wrapper />);

  expect(blogsToTest[0].blogId).toBe(24);
  const toInput = document.getElementById("DateToInput");

  await fireEvent.change(toInput, { target: { value: "30/09/2022" } });
  await fireEvent.keyPress(toInput, { key: "Enter", code: 13, charCode: 13 });

  expect(toInput.value).toBe("30/09/2022");

  expect(blogsToTest.length).toBe(2);
});

test("Testing name sorting: A-Z", async () => {
  render(<Wrapper />);

  expect(blogsToTest[0].blogId).toBe(24);

  await fireEvent.click(
    document.getElementById("drawer-open").nextSibling.firstChild.lastChild
      .childNodes[8]
  );

  expect(blogsToTest[0].title).toBe("Another Blog");
  expect(blogsToTest[1].title).toBe("Last of the blogs");
  expect(blogsToTest[2].title).toBe("The second blog");
  expect(blogsToTest[3].title).toBe("Third blog");
});

test("Testing name sorting: Z-A", async () => {
  render(<Wrapper />);

  expect(blogsToTest[0].blogId).toBe(24);

  await fireEvent.click(
    document.getElementById("drawer-open").nextSibling.firstChild.lastChild
      .childNodes[9]
  );

  expect(blogsToTest[0].title).toBe("Third blog");
  expect(blogsToTest[1].title).toBe("The second blog");
  expect(blogsToTest[2].title).toBe("Last of the blogs");
  expect(blogsToTest[3].title).toBe("Another Blog");
});
