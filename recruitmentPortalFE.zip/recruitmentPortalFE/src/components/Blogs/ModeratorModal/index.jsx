import TextField from '@mui/material/TextField';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import Button from "@mui/material/Button";
import { Typography } from "@mui/material";

function ModeratorModal( { isOpen, onClose, blogData}) {
  //console.log("isOpen" , isOpen)
  //console.log(blogData)

  if(!isOpen) return null;

return (

  <Dialog
    sx={{
      left: "3.125rem",}}
    fullWidth
    maxWidth= "md"
    open={isOpen}
    onClose={onClose}>

    <DialogContent>

      <Typography 
        variant="h5"
        sx={{
          marginTop: "1.25rem", 
          marginBottom: "1rem", 
          marginLeft: "1.25rem"
        }} >
        Reject blog entry "{blogData[0].title}"?
      </Typography>

     <TextField
        sx={{
          width: "95%",
          marginLeft: "1.25rem",
        }}
        multiline
        rows={3}
        autoFocus
        margin="normal"
        id="explanation"
        label="Please provide reasoning for rejecting this entry"
        variant="outlined"    
      />

</DialogContent>

    <DialogActions>

      <Button onClick={onClose} 
        color="primary" 
        sx={{ fontWeight: 600, 
          marginBottom: "1.75rem", 
          marginRight: "1rem" }}> 
        Cancel </Button> 


      <Button onClick={onClose} 
        color="error" 
        variant="contained" 
        disableElevation 
        sx={{ fontWeight: 600, 
          marginBottom: "1.875rem" , 
          marginRight: "2.5rem" }} > 
        Reject Entry</Button>

    </DialogActions>

  </Dialog>

);
};


export default ModeratorModal;

