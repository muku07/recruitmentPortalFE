import React from "react";

import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import {
  ImageCard,
  MediaBackground,
  TitleDateCont,
} from "./ReadDetailedBlogCardElements";
import AppliedFilters from "../AppliedFilters";

function ReadDetailedBlogCard({ blogData, blogImage }) {
  return (
    <Card sx={{ maxWidth: 870, margin: "auto", flexWrap: "wrap" }}>
      {/* <CardMedia
        component="img"
        height="140"
        image="/static/images/cards/contemplative-reptile.jpg"
        alt="green iguana"
      /> */}

      {blogImage ? <ImageCard src={blogImage} /> : <MediaBackground />}

      <CardContent>
        <TitleDateCont>
          <Typography gutterBottom variant="h5" component="div" align="left">
            {blogData.title}
          </Typography>

          <Typography gutterBottom variant="h7" component="div" align="right">
            {blogData.submittedDate}
          </Typography>
        </TitleDateCont>

        <Typography gutterBottom variant="subtitle1" component="div">
          {blogData.publishedBy}
        </Typography>

        <AppliedFilters filters={blogData.tags} />

        <Typography variant="body1" color="text.secondary" fontWeight="bold">
          {blogData.details}
        </Typography>

        <br />

        {/* <Typography variant="body2" color="text.secondary">
              {blogData.details}
            </Typography>

            <br /> */}
      </CardContent>
    </Card>
  );
}

export default ReadDetailedBlogCard;
