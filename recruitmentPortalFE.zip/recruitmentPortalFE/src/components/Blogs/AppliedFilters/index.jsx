import Stack from "@mui/material/Stack";
import { StyledChip } from "./Elements";
import React from "react";

function AppliedFilters({ id, filters, onClick, styles }) {
  return (
    <Stack
      id={id}
      direction="row"
      flexWrap="wrap"
      alignContent="flex-start"
      marginBottom="-0.3rem"
    >
      {filters?.map((filt, i) => (
        <StyledChip
          key={i}
          label={filt}
          size="small"
          sx={{
            margin: " auto 0.3rem 0.3rem 0",
            ...styles,
          }}
          onClick={(event) => onClick(event, filt)}
        />
      ))}
    </Stack>
  );
}

export default React.memo(AppliedFilters);
