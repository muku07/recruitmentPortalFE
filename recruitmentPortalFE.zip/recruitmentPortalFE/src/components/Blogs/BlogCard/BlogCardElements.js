import { styled } from "@mui/material/styles";
import Card from "@mui/material/Card";
import CardMedia from "@mui/material/CardMedia";
import CardContent from "@mui/material/CardContent";
import CardActions from "@mui/material/CardActions";
import Button from "@mui/material/Button";

export const StyledCard = styled(Card)`
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  position: relative;

  &.featuredFirst {
    grid-column: 1/-1;
    flex-direction: row;
    min-height: 18rem;
    max-height: 18rem;
    display: grid;
    grid-template-columns: 50% 50%;
    grid-template-rows: 3fr 1fr;

    & > img {
      max-width: 100%;
      min-width: 100%;
      max-height: 100% !important;
      min-height: 100% !important;
      grid-row: 1/-1;
    }
    & > div:first-of-type {
      text-align: right;
      padding: 2rem !important;
      max-height: 100%;

      & > h5 {
        font-size: 2rem;
        margin-bottom: 0.5rem;
      }

      & > p {
        max-height: 35%;
      }

      & > div {
        display: none;
      }
    }
    & > div:nth-of-type(3) {
      margin-bottom: 2rem;
      min-width: 35%;
      justify-content: flex-end;
      padding-right: 2rem;

      & > button {
        margin: 0 !important;
        padding: 0 !important;
        justify-content: flex-end;
      }
    }
  }
`;

export const StyledCardMedia = styled(CardMedia)`
  max-height: 12rem;
  min-height: 12rem; // no idea why you can't just set height..
  width: 100%;
  object-fit: cover;
  overflow: hidden;
`;

export const StyledCardContent = styled(CardContent)`
  padding: 0.75rem !important;
  display: flex;
  flex-direction: column;
  height: inherit;

  & > :last-child {
    flex-grow: 5;
    margin-top: auto;
  }
`;

export const StyledButton = styled(Button)`
  font-size: 0.75rem;
  line-height: 0.75rem;
  vertical-align: middle;
  margin: 1% auto !important;
  padding: 0.4rem 10% 0.3rem;
  width: 45%;
  text-transform: capitalize;
  font-weight: 600;
  white-space: nowrap;
`;

export const StyledCardActions = styled(CardActions)`
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  justify-content: space-between;
  align-items: center;
`;
