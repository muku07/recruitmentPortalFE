import { memo } from "react";
import Typography from "@mui/material/Typography";
import AppliedFilters from "../AppliedFilters";
import {
  StyledCard,
  StyledCardMedia,
  StyledCardContent,
  StyledButton,
  StyledCardActions,
} from "./BlogCardElements";
import { Chip } from "@mui/material";
import { useMsal } from "@azure/msal-react";
import { DateTime } from "luxon";
import { useNavigate } from "react-router-dom";

const BASE_URL = "https://mapii-blog-service.azurewebsites.net";

const BlogReviewStatus = {
  DRAFT: 1,
  PENDING: 2,
  APPROVED: 3,
  REJECTED: 4,
  DELETED: 5,
};

function CardButtons({ blogStatus, blogAuthor, blogId }) {
  const navigate = useNavigate();
  const { _, accounts } = useMsal();

  switch (blogStatus) {
    case BlogReviewStatus.REJECTED:
      return (
        <>
          <StyledButton>Edit</StyledButton>
          <StyledButton color="error">Discard</StyledButton>
        </>
      );
    case BlogReviewStatus.DRAFT:
      return (
        <>
          <StyledButton>Edit</StyledButton>
          <StyledButton
            variant="contained"
            color="success"
            size="small"
            disableElevation
          >
            Publish
          </StyledButton>
        </>
      );
    case BlogReviewStatus.PENDING:
      // is user owner(discard or revert to draft) or verifier (read, approve, reject)?
      return sessionStorage.getItem("role") === "ROLE_ADMIN" &&
        blogAuthor.toLowerCase().indexOf(accounts[0].name.toLowerCase()) >
          -1 ? (
        <>
          <StyledButton color="warning">Discard</StyledButton>
          <StyledButton
            variant="contained"
            color="primary"
            size="small"
            disableElevation
          >
            Revert to draft
          </StyledButton>
        </>
      ) : (
        <>
          <StyledButton
            onClick={() => navigate(`blogs/${blogId}`)}
            sx={{ width: "100%" }}
          >
            Read entry
          </StyledButton>
          <StyledButton color="error">Reject</StyledButton>
          <StyledButton variant="contained" color="success" disableElevation>
            Approve
          </StyledButton>
        </>
      );
    default:
      return (
        <StyledButton onClick={() => navigate(`/blogs/${blogId}`)}>
          Read entry
        </StyledButton>
      );
  }
}

function StatusChip({ status }) {
  let chipColour = "";
  let statusAsText = "pending";

  switch (status) {
    case BlogReviewStatus.DRAFT:
      chipColour = "success";
      statusAsText = "draft";
      break;
    case BlogReviewStatus.APPROVED:
      chipColour = "primary";
      statusAsText = "approved";
      break;
    case BlogReviewStatus.REJECTED:
      chipColour = "warning";
      statusAsText = "rejected";
      break;
    default:
      chipColour = "warning";
      break;
  }

  return (
    <Chip
      label={statusAsText}
      size="small"
      color={chipColour}
      sx={{
        position: "absolute",
        margin: "0.5rem",
        top: 0,
        right: 0,
        width: "10rem",
        height: "2rem",
        maxWidth: "25%",
        fontSize: "0.65rem",
        textTransform: "capitalize",
      }}
    />
  );
}

function BlogCard({ blog, expandFirst = false, hideStatusChip = false }) {
  return (
    <StyledCard className={expandFirst && "featuredFirst"}>
      <StyledCardMedia
        component="img"
        image={`${BASE_URL}/blogs/image?blogId=${blog.blogId}`}
        onError={(e) => {
          e.currentTarget.src =
            "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=";
        }}
        alt={"A display image for the " + blog.title + " blog"}
        sx={{
          background:
            "linear-gradient(89.89deg, #61ff71 -4.44%, #8960ff 73.36%)",
        }}
      />
      {!hideStatusChip && <StatusChip status={blog.statusId} />}
      <StyledCardContent>
        <Typography variant="h5">{blog.title}</Typography>
        {expandFirst ? (
          <Typography variant="body1">{blog.details}</Typography>
        ) : (
          <>
            {blog.publishedBy.length > 0 && (
              <Typography variant="subtitle1" sx={{ marginBottom: "auto" }}>
                Published by {blog.publishedBy}
              </Typography>
            )}
            <Typography variant="subtitle2">
              {blog.submittedDate &&
                DateTime.fromFormat(blog.submittedDate, "yyyy-MM-dd", {})
                  .setLocale("en-GB")
                  .toLocaleString()}
            </Typography>
          </>
        )}

        <AppliedFilters
          filters={blog.tags}
          sx={{ flexGrow: 5, alignContent: "center" }}
        />
      </StyledCardContent>
      <StyledCardActions>
        <CardButtons
          blogStatus={blog.statusId}
          blogAuthor={blog.publishedBy}
          blogId={blog.blogId}
        />
      </StyledCardActions>
    </StyledCard>
  );
}

export default memo(BlogCard);
