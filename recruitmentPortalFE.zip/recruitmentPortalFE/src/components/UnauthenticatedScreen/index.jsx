import React from "react";

import { UnauthImg, UnauthorizedPage } from "./UnauthenticatedElements";
import unauth from "../../assets/unauth.svg";

function UnauthenticatedScreen() {
  return (
    <>
      <UnauthorizedPage>
        <UnauthImg src={unauth} />
      </UnauthorizedPage>
    </>
  );
}

export default UnauthenticatedScreen;
