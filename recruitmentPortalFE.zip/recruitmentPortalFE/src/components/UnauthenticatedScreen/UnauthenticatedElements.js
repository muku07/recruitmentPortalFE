import styled from "styled-components";

export const UnauthorizedPage = styled.div`
  overflow: hidden;
  max-width: 100%;
  display: flex;
  justify-content: center;
  // centers in the flex direction and the default flex-direction is row
  align-content: center;
  // centers perpendicular to the flex direction
`;

export const UnauthImg = styled.img`
  height: 35%;
  width: 35%;
`;
