import React from "react";
import ReactRoundedImage from "react-rounded-image";
import { Maindiv } from "./AvatarElements";
function AvatarElement(props) {

 const myPic = props.imageName;
  return (
    <Maindiv>
      <ReactRoundedImage
        roundedColor="#0070ad"
        //image={MyPhoto}
       image ={myPic}
        roundedSize="10"
        imageWidth="100"
        imageHeight="100"
      />  

    </Maindiv>
  );
}

export default AvatarElement;
