import styled from "styled-components";

export const Maindiv = styled.div`
  //display: "flex"
  background-color: #fff;
  margin-top: 2%;
  margin-left: 10%;
 // width: 170vh;
  position:relative;
`;
