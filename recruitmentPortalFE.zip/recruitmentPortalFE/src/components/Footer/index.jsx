import React, { useEffect, useState } from "react";

import {
  FooterCont,
  Row,
  Column,
  FooterLink,
  Heading,
  TermsAndService,
  SocialMediaDiv,
  RowLogo,
  LogoImg,
  TwitterLogo,
  InstagramLogo,
  FacebookLogo,
  LinkedInLogo,
} from "./FooterElements";

import Logo from "../../assets/NavBar_Logo.svg";

const Footer = () => {
  const [date, setDate] = useState();

  const getYear = () => setDate(new Date().getFullYear());

  useEffect(() => {
    getYear();
  }, []);

  return (
    <FooterCont>
      <RowLogo>
        <LogoImg src={Logo} alt="A Logo image for the MAP II portal" />
        <span>MAPII</span>
      </RowLogo>

      <Column>
        <Heading>ABOUT US</Heading>
        <FooterLink href="#">Aim</FooterLink>
        <FooterLink href="#">Vision</FooterLink>
        <FooterLink href="#">Testimonials</FooterLink>
      </Column>
      <Column>
        <Heading>SERVICES</Heading>
        <FooterLink href="#">Writing</FooterLink>
        <FooterLink href="#">Internship</FooterLink>
        <FooterLink href="#">Coding</FooterLink>
        <FooterLink href="#">Teaching</FooterLink>
      </Column>
      <Column>
        <Heading>PRIVACY POLICY</Heading>
        <FooterLink href="#">Terms of use</FooterLink>
        <FooterLink href="#">Social media policy</FooterLink>
        <FooterLink href="#">Social media house Rules</FooterLink>
        <FooterLink href="#">Legal information</FooterLink>
        <FooterLink href="#">Transparency statement</FooterLink>
        <FooterLink href="#">Cookies</FooterLink>
      </Column>
      <Column>
        <Heading>IN ASSOCIATION WITH</Heading>
        <FooterLink href="#">Capgemini Engineering</FooterLink>
        <FooterLink href="#">Cagemini Invest</FooterLink>
        <FooterLink href="#">Sogeti Part of Capgemini</FooterLink>
      </Column>

      <Row>
        <SocialMediaDiv>
          <FooterLink href="#">
            <TwitterLogo fontSize="large" />
          </FooterLink>

          <FooterLink href="#">
            <InstagramLogo fontSize="large" />
          </FooterLink>

          <FooterLink href="#">
            <FacebookLogo fontSize="large" />
          </FooterLink>

          <FooterLink href="#">
            <LinkedInLogo fontSize="large" />
          </FooterLink>
        </SocialMediaDiv>
      </Row>

      <Row>
        <TermsAndService>
          <h2>All rights reserved by Capgemini. Copyright {date}</h2>
        </TermsAndService>
      </Row>
    </FooterCont>
  );
};
export default Footer;
