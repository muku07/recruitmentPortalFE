import styled from "styled-components";

import TwitterIcon from "@mui/icons-material/Twitter";
import InstagramIcon from "@mui/icons-material/Instagram";
import FacebookOutlinedIcon from "@mui/icons-material/FacebookOutlined";
import LinkedInIcon from "@mui/icons-material/LinkedIn";

export const FooterCont = styled.footer`
  display: grid;
  grid-template-columns: 25% 25% 25% 25%;
  background: var(--bg-primary);
  padding: 0.5rem;
  margin-left: 4.25rem;

  @media (max-width: 768px) {
    grid-template-columns: 50% 50%;
  }
  @media (max-width: 425px) {
    grid-template-columns: 100%;
  }
`;

export const RowLogo = styled.div`
  grid-column: 1/-1;
  margin: auto;

  span {
    font-family: "Ubuntu";
    font-style: normal;
    font-weight: 400;
    font-size: 32px;
    line-height: 37px;
    letter-spacing: -0.04em;
    color: #0070ad;
  }
`;

export const LogoImg = styled.img``;

export const Column = styled.div`
  display: flex;
  flex-direction: column;
  text-align: center;
`;

export const Row = styled.div`
  grid-column: 1/-1;
`;

export const Heading = styled.p`
  font-size: 1.125rem;
  font-weight: 500;
  color: var(--accent);
  font-weight: bold;
  text-align: "center";
`;

export const FooterLink = styled.a`
  color: var(--text);
  font-size: 0.875rem;
  font-weight: 400;

  line-height: 26px;
  text-decoration: none;
`;

export const TermsAndService = styled.div`
  margin: auto;

  h2 {
    font-size: 1rem;
    text-align: center;
    color: var(--text);
  }
`;

export const SocialMediaImg = styled.img`
  width: 30px;
`;

export const SocialMediaDiv = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 1.8rem;
`;

export const TwitterLogo = styled(TwitterIcon)`
  color: var(--accent);
`;

export const InstagramLogo = styled(InstagramIcon)`
  color: var(--accent);
`;

export const FacebookLogo = styled(FacebookOutlinedIcon)`
  color: var(--accent);
`;

export const LinkedInLogo = styled(LinkedInIcon)`
  color: var(--accent);
`;
