//CSS
import { Link } from "react-router-dom";
import styled, { keyframes } from "styled-components";

export const NavLi = styled.li`
  width: 100%;

  &:last-child {
    margin-top: auto;
    & > button {
      width: 11rem;
      margin: 0 auto 1rem 1rem !important;
      padding: 0 !important;
      transition: all 0.15s ease-in-out;
      border-radius: 0.3rem;
      height: 2.25rem;
      & > span {
        margin-right: 0;
        & * {
          transition: all 0.25s linear;
        }
      }
      & > h2 {
        margin: auto;
        color: var(--bg-primary);
      }
    }
  }
`;

export const NavButton = styled(Link)`
  display: flex;
  align-items: center;
  vertical-align: middle;
  height: 3rem;
  text-decoration: none;
  width: 14.25rem;
  margin: 0.25rem 1rem;
  padding-right: 1rem;
  transition: all 0.15s ease-in-out, border-top-left-radius 0.25s ease-in-out,
    border-bottom-left-radius 0.25s ease-in-out;

  &:hover {
    box-shadow: 0 0 0 0.1rem var(--disabled);
    background-color: var(--bg-secondary);
    border-top-left-radius: 15px;
    border-bottom-left-radius: 15px;
    padding-left: 0.5rem;
    margin-left: 0.5rem; // These two(^) are hacky, but positions background well..
  }
`;

export const NavCont = styled.nav`
  position: fixed;
  overflow: hidden;
  height: 100vh;
  width: 4.25rem;
  background: var(--bg-primary);
  z-index: 100;
  transition: width 0.5s ease-in-out;
  border-top-right-radius: 0.5rem;
  border-bottom-right-radius: 0.5rem;
  box-shadow: 0 0.1rem 0.5rem 0 rgba(0, 0, 0, 0.25);

  &:hover {
    width: 13rem;

    & > div:first-of-type {
      transform: translateX(1.5rem);
    }

    & * > li:last-of-type {
      & > button {
        background: var(--accent);
        &:hover {
          box-shadow: 0 0 0.25rem 0.05rem rgba(0, 0, 0, 0.5);
          transform: scale(103%);
        }
        & > span * {
          color: var(--bg-primary);
        }
      }
    }
  }

  & > div:first-of-type {
    display: flex;
    width: 14.25rem;
    height: 4rem;
    margin: 0 0.125rem auto;
    transition: transform 0.5s linear;

    & > img {
      width: 4rem;
      height: 4rem;
      padding: 0.5rem;
    }

    & > p {
      margin: auto 0rem;
      color: #0070ad; //not var() as matching colour on logo
      font-size: 2rem;
    }
  }
`;

export const NavUL = styled.ul`
  list-style: none;
  padding: 0;
  margin: -4rem 0 0;
  display: flex;
  flex-direction: column;
  justify-content: center;
  height: 100%;

  & > li:first-of-type {
    margin-top: auto;
  }
`;

export const NavButtonH2 = styled.h2`
  font-size: 1.25rem;
  font-weight: 400;
  text-align: start;
  text-decoration: none;
  color: var(--text);
  margin-bottom: 0;
`;

const iconKeyFrames = keyframes`
  0% {opacity: 0.75}  100% {opacity: 1}
`;

export const IconSpan = styled.span`
  width: 2.25rem;
  min-width: 2.25rem;
  height: 2.25rem;
  min-height: 2.25rem;
  margin: 0 1rem 0 0;
  padding: 0.25rem;
  color: var(--accent);

  & > * {
    animation: 0.5s ${iconKeyFrames} linear;
  }
`;

//For styling the Azure auth in the sidebar
export const SignInOutButton = styled.button`
  display: flex;
  align-items: center;
  vertical-align: middle;
  height: 3rem;
  max-height: 3rem;
  text-decoration: none;
  width: 16rem;
  margin-left: 1rem;
  margin-bottom: 1rem;
  background: none;
  border: none;

  &:hover {
    transition-property: border-top-left-radius border-bottom-left-radius
      background-color;
    transition-duration: 0.5s;
    background-color: var(--bg-secondary);
    border-top-left-radius: 15px;
    border-bottom-left-radius: 15px;
    padding-left: 0.5rem;
    margin-left: 0.5rem; // These two(^) are hacky, but positions background well..
  }

  ${NavButtonH2} {
    display: grid;
    align-items: center;
    max-width: 59%;
    max-height: 3rem;
  }
`;

//For the name of logged in user to show
export const NavButtonH3 = styled.p`
  font-size: 0.8rem;
  margin: 0 0 0 0.25rem;
`;
