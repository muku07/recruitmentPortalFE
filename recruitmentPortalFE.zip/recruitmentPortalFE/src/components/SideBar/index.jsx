import {
  Home,
  HomeOutlined,
  Groups,
  GroupsOutlined,
  Dashboard,
  DashboardOutlined,
  Psychology,
  PsychologyOutlined,
  Rocket,
  RocketOutlined,
  StickyNote2,
  StickyNote2Outlined,
  Sms,
  SmsOutlined,
  ExitToAppRounded
} from "@mui/icons-material";
import LaptopChromebookIcon from '@mui/icons-material/LaptopChromebook';
import Logo from "../../assets/NavBar_Logo.svg";
import {
  AuthenticatedTemplate,
  useIsAuthenticated,
  useMsal,
} from "@azure/msal-react";
import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import PropTypes from "prop-types";
import {
  NavCont,
  NavUL,
  NavLi,
  NavButton,
  IconSpan,
  NavButtonH2,
  SignInOutButton,
  NavButtonH3,
} from "./SideBarElements";

function SideBar() {
  const [loginName, setLoginName] = useState("");
  const { instance, accounts } = useMsal();
  const isAuthenticated = useIsAuthenticated();

  const ROLE = sessionStorage.getItem("role");

  useEffect(() => {
    if (isAuthenticated) {
      setLoginName(accounts[0].idTokenClaims.name);
    }
  }, []);

  NavItem.propTypes = {
    route: PropTypes.string.isRequired,
    icon: PropTypes.element.isRequired,
    iconSelected: PropTypes.element.isRequired,
    text: PropTypes.string.isRequired,
  };

  function NavItem({ route, icon, iconSelected, text }) {
    const selected = useLocation().pathname === route;
    const textStyle = selected
      ? {
          color: "var(--accent)",
          fontWeight: 700,
          transition: "fontWeight 0.25s linear",
        }
      : null;
    return (
      <NavLi>
        <NavButton to={route}>
          <IconSpan>
            {selected
              ? React.cloneElement(iconSelected, {
                  sx: { color: "var(--accent)", width: "100%", height: "100%" },
                })
              : React.cloneElement(icon, {
                  sx: {
                    color: "var(--text)",
                    width: "100%",
                    height: "100%",
                  },
                })}
            {/* Unsure the implications of cloneElement */}
          </IconSpan>
          <NavButtonH2 style={textStyle}>{text}</NavButtonH2>
        </NavButton>
      </NavLi>
    );
  }

  //HTML Code
  return (
    <NavCont>
      <div>
        <img src={Logo} alt="A Logo image for the MAP II portal" />
        <p>MAPII</p>
      </div>
      <NavUL>
        <NavItem
          route="/home"
          icon={<HomeOutlined />}
          iconSelected={<Home />}
          text="Home"
        />
        <NavItem
          route="/employee-profiles"
          icon={<GroupsOutlined />}
          iconSelected={<Groups />}
          text="Employee Profiles"
        />
        <NavItem
          route="/dashboard"
          icon={<DashboardOutlined />}
          iconSelected={<Dashboard />}
          text="Dashboard"
        />
        <NavItem
          route="/learning-development"
          icon={<PsychologyOutlined style={{ transform: "scaleX(-1)" }} />}
          iconSelected={<Psychology style={{ transform: "scaleX(-1)" }} />}
          text="Learning and Development"
        />
        <NavItem
          route="/accelerators"
          icon={<RocketOutlined />}
          iconSelected={<Rocket />}
          text="Accelerators"
        />
        <NavItem
          route="/blogs"
          icon={<StickyNote2Outlined />}
          iconSelected={<StickyNote2 />}
          text="Blogs"
        />
        <NavItem
          route="/testimonials"
          icon={<SmsOutlined />}
          iconSelected={<Sms />}
          text="Testimonials"
        />
        <NavItem
          route="/recruitment"
          icon={<LaptopChromebookIcon />}
          iconSelected={<LaptopChromebookIcon />}
          text="Recruitment"
        />
      
        <AuthenticatedTemplate>
          <NavLi>
            <SignInOutButton
              onClick={() =>
                instance
                  .logoutRedirect({ postLogoutRedirectUri: "/" })
                  .then(sessionStorage.clear)
              }
            >
              <IconSpan>
                <ExitToAppRounded
                  sx={{
                    height: "100%",
                    width: "100%",
                    color: "var(--accent)",
                    // background: "var(--accent)",
                    borderRadius: "0.2rem",
                    padding: "0.1rem",
                  }}
                />
              </IconSpan>
              <NavButtonH2>
                Sign out
                {/* <NavButtonH3>{loginName}</NavButtonH3> */}
              </NavButtonH2>
            </SignInOutButton>
          </NavLi>
        </AuthenticatedTemplate>
      </NavUL>
    </NavCont>
  );
}

export default SideBar;
