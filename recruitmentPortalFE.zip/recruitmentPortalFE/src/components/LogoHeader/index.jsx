import {
  AuthenticatedTemplate,
  UnauthenticatedTemplate,
} from "@azure/msal-react";

import { HeaderCont, LogoLink, LogoImg } from "./LogoHeaderElements";
import Logo from "../../assets/Logo.svg";

function LogoHeader() {
  return (
    <HeaderCont>
      <UnauthenticatedTemplate>
        <LogoLink to="/">
          <LogoImg src={Logo} />
        </LogoLink>
      </UnauthenticatedTemplate>

      <AuthenticatedTemplate>
        <LogoLink to="/home">
          <LogoImg src={Logo} />
        </LogoLink>
      </AuthenticatedTemplate>
    </HeaderCont>
  );
}

export default LogoHeader;
