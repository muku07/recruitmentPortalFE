import styled from "styled-components";

export const NavBar = styled.div`
  width: 100px;
  margin: 15px auto;
  border-bottom: 200px;
`;

export const PaginationList = styled.ul`
  list-style: none;
  padding: 0px 20px 30px;
  background-color: #fff;
`;

export const PageItem = styled.li`
  display: inline-block;
  flex-direction: column;
  padding: 10px 0px;
`;

export const PageLink = styled.button`
  border: none;
  background: white;
  color: #003857;
  font-size: 25px;
  text-align: center;
  margin-right: 5px;
  border-bottom: 1px solid grey;
  cursor: pointer;
`;
