import Stack from "@mui/material/Stack";
import { StyledChip } from "./Elements";

function AccelAppliedFilters({ filters }) {
  return (
    <Stack direction="row" flexWrap="wrap" marginBottom="-0.3rem">
      {filters?.map((filt, i) => (
        <StyledChip
          key={i}
          label={filt}
          size="small"
          sx={{ margin: " auto 0.3rem 0.3rem 0" }}
        />
      ))}
    </Stack>
  );
}

export default AccelAppliedFilters;
