import { styled } from "@mui/material/styles";
import Chip from "@mui/material/Chip";

export const StyledChip = styled(Chip)`
  margin-bottom: 10px;
  color: var(--accent);
  border: 2px solid;
  background-color: #fff;
`;
