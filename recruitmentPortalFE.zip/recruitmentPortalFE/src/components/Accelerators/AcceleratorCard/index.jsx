import PropTypes from "prop-types";
import Typography from "@mui/material/Typography";
import AccelAppliedFilters from "../AccelAppliedFilters";
import {
  StyledCard,
  StyledCardMedia,
  StyledCardContent,
  StyledButton,
  StyledCardActions,
} from "./AcceleratorCardElements";
import { Chip } from "@mui/material";
import { useMsal } from "@azure/msal-react";

const renderButtons = (AcceleratorStatus, AcceleratorAuthor, account) => {
  switch (AcceleratorStatus) {
    case AcceleratorReviewStatus.REJECTED:
      return (
        <>
          <StyledButton>Edit</StyledButton>
          <StyledButton>Discard</StyledButton>
        </>
      );
    case AcceleratorReviewStatus.DRAFT:
      return (
        <>
          <StyledButton>Edit</StyledButton>
          <StyledButton
            variant="contained"
            color="success"
            size="small"
            disableElevation
          >
            Publish
          </StyledButton>
        </>
      );
    case AcceleratorReviewStatus.PENDING:
      // is user owner(discard or revert to draft) or verifier (read, approve, reject)?
      return sessionStorage.getItem("role") == "ROLE_ADMIN" &&
        AcceleratorAuthor.indexOf(account.name) > -1 ? (
        <>
          <StyledButton color="warning">Discard</StyledButton>
          <StyledButton
            variant="contained"
            color="primary"
            size="small"
            disableElevation
          >
            Revert to draft
          </StyledButton>
        </>
      ) : (
        <>
          <StyledButton sx={{ margin: "auto !important", width: "100%" }}>
            View project details
          </StyledButton>
          <StyledButton color="warning">Reject</StyledButton>
          <StyledButton variant="contained" color="success" disableElevation>
            Approve
          </StyledButton>
        </>
      );
    default:
      return (
        <StyledButton sx={{ margin: "auto !important" }}>
          View project details
        </StyledButton>
      );
  }
};

const renderStatusChip = (status) => {
  let chipColour = "";

  switch (status) {
    case "rejected":
      chipColour = "warning";
      break;
    case "draft":
      chipColour = "success";
      break;
    case "pending":
      chipColour = "warning";
      break;
    default:
      chipColour = "primary";
      break;
  }
  status = status.charAt(0).toUpperCase() + status.slice(1);
  return (
    <Chip
      label={status}
      size="small"
      color={chipColour}
      sx={{
        position: "absolute",
        margin: "0.5rem",
        top: 0,
        right: 0,
        width: "35%",
        fontSize: "0.65rem",
      }}
    />
  );
};

const AcceleratorReviewStatus = {
  REJECTED: "rejected",
  DRAFT: "draft",
  PUBLISHED: "published",
  PENDING: "pending",
};

AcceleratorCard.propTypes = {
  expandFirst: PropTypes.bool,
  Accelerator: PropTypes.shape({
    id: PropTypes.number.isRequired,
    status: PropTypes.oneOf([
      AcceleratorReviewStatus.REJECTED,
      AcceleratorReviewStatus.DRAFT,
      AcceleratorReviewStatus.PUBLISHED,
      AcceleratorReviewStatus.PENDING,
    ]).isRequired,
    title: PropTypes.string.isRequired,
    image: PropTypes.string,
    desc: PropTypes.string.isRequired,
    author: PropTypes.string.isRequired, // should be changed to object once backend spec complete?
    publishDate: PropTypes.string,
    body: PropTypes.string.isRequired,
  }),
  hideStatusChip: PropTypes.bool,
};

export default function AcceleratorCard({
  expandFirst,
  Accelerator,
  hideStatusChip = false,
}) {
  const { instance, accounts } = useMsal();
  return (
    <StyledCard>
      <StyledCardMedia
        sx={{
          background:
            "linear-gradient(89.89deg, #68a2d5 -4.44%, #df58ae 73.36%)",
          // "linear-gradient(89.89deg, #61ff71 -4.44%, #8960ff 73.36%)",
        }}
      />
      {hideStatusChip ? null : renderStatusChip(Accelerator.status)}
      <StyledCardContent>
        <Typography variant="h5">{Accelerator.title}</Typography>
        {expandFirst ? (
          <Typography variant="subtitle">
            Created: {Accelerator.publishDate}
          </Typography>
        ) : (
          <Typography variant="subtitle">
            Created: {Accelerator.publishDate}
          </Typography>
        )}

        <AccelAppliedFilters
          filters={Accelerator.usedLangs}
          sx={{ flexGrow: 5 }}
        />
      </StyledCardContent>
      <StyledCardActions>
        {renderButtons(Accelerator.status, Accelerator.author, accounts[0])}
      </StyledCardActions>
    </StyledCard>
  );
}
