import { styled } from "@mui/material/styles";
import Card from "@mui/material/Card";
import CardMedia from "@mui/material/CardMedia";
import CardContent from "@mui/material/CardContent";
import CardActions from "@mui/material/CardActions";
import Button from "@mui/material/Button";

export const StyledCard = styled(Card)`
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  position: relative;
`;

export const StyledCardMedia = styled(CardMedia)`
  max-height: 12rem;
  min-height: 12rem; // no idea why you can't just set height..
  width: 100%;
  object-fit: cover;
  overflow: hidden;
`;

export const StyledCardContent = styled(CardContent)`
  padding: 0.75rem !important;
  display: flex;
  flex-direction: column;
  height: inherit;

  & > :last-child {
    flex-grow: 5;
    margin-top: auto;
  }
`;

export const StyledButton = styled(Button)`
  font-size: 0.75rem;
  line-height: 0.75rem;
  vertical-align: middle;
  margin: 0 !important;
  padding: 0.4rem 10% 0.3rem;
  max-width: 85%;
  text-transform: capitalize;
  font-weight: 600;
  &.MuiButton-containedPrimary {
    padding: 0.4rem 0.4rem 0.3rem;
  }
`;

export const StyledCardActions = styled(CardActions)`
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  justify-content: space-evenly;
  align-content: center;
  align-items: flex-start;
`;
