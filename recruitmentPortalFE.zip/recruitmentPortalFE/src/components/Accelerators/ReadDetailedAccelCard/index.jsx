import React from "react";

import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import { MediaBackground } from "./ReadDetailedAcceleratorCardElements";
import AccelAppliedFilters from "../AccelAppliedFilters";

function ReadDetailedAcceleratorCard({ acceleratorData }) {
  return (
    <Card sx={{ maxWidth: 870, margin: "auto", flexWrap: "wrap" }}>
      {/* <CardMedia
        component="img"
        height="140"
        image="/static/images/cards/contemplative-reptile.jpg"
        alt="green iguana"
      /> */}

      <MediaBackground />
      <CardContent>
        {acceleratorData?.map((accelerator, i) => (
          <div key={i}>
            <Typography gutterBottom variant="h5" component="div">
              {accelerator.title}
            </Typography>

            <Typography gutterBottom variant="subtitle1" component="div">
              {accelerator.Author}
            </Typography>

            <AccelAppliedFilters filters={accelerator.filter} />

            <Typography
              variant="body1"
              color="text.secondary"
              fontWeight="bold"
            >
              {accelerator.subheading}
            </Typography>

            <br />

            <Typography variant="body2" color="text.secondary">
              {accelerator.para1}
            </Typography>

            <br />

            <Typography variant="body2" color="text.secondary">
              {accelerator.para2}
            </Typography>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

export default ReadDetailedAcceleratorCard;
