import { styled } from "@mui/material/styles";

export const MediaBackground = styled("div")`
  width: 870px;
  height: 228px;
  background: linear-gradient(89.89deg, #61ff71 -4.44%, #8960ff 73.36%);
  backdrop-filter: blur(4px);
  /* Note: backdrop-filter has minimal browser support */
  border-radius: 7px 7px 0px 0px;
`;
