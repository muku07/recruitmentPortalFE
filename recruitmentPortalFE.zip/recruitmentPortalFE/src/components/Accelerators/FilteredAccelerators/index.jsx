import AcceleratorCard from "../AcceleratorCard";

export default function FilteredAccelerators({
  allAccelerators,
  searchBy,
  searchQuery,
  hideStatusChip,
  expandFirst = false,
}) {
  const filteredAccelerators = filterAccelerators(
    allAccelerators,
    searchBy,
    searchQuery
  );
  try {
    return filteredAccelerators.map((Accelerator, index) =>
      expandFirst && index == 0 ? (
        <AcceleratorCard
          expandFirst={expandFirst}
          Accelerator={Accelerator}
          hideStatusChip={hideStatusChip}
          key={Accelerator.id}
        />
      ) : (
        <AcceleratorCard
          key={Accelerator.id}
          Accelerator={Accelerator}
          hideStatusChip={hideStatusChip}
        />
      )
    );
  } catch (e) {
    if (e instanceof TypeError) return <p>{filteredAccelerators}</p>;
  }
}

const filterAccelerators = (allAccelerators, searchBy, searchQuery) => {
  // If length of allAccelerators isn't 0: filter the Accelerators based upon the filterBy const;
  let filteredAccelerators =
    allAccelerators && allAccelerators.length > 0
      ? allAccelerators.filter((Accelerator) => {
          if (
            Accelerator[searchBy]
              ?.toLowerCase()
              .includes(searchQuery.toLowerCase())
          )
            return Accelerator;
        })
      : allAccelerators;

  return filteredAccelerators && filteredAccelerators.length > 0
    ? filteredAccelerators
    : "No results found";
};
