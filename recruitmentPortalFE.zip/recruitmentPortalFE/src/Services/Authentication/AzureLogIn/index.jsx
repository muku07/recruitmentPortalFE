import React from "react";
import { useMsal } from "@azure/msal-react";

import { loginRequest } from "../../../Services/Authentication/authConfig"

function AzureLogin() {
  const { instance } = useMsal();

  instance.loginRedirect(loginRequest);

  return <div>Loading...</div>;
}

export default AzureLogin;
