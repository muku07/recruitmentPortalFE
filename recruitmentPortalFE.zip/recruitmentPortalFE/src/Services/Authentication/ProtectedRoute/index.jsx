import { useIsAuthenticated } from "@azure/msal-react";
import { Navigate, Outlet, useLocation } from "react-router-dom";

import UnauthenticatedScreen from "../../../components/UnauthenticatedScreen"

const ProtectedRoute = ({ allowedRoles }) => {
  const isAuthenticated = useIsAuthenticated();
  const ROLE = sessionStorage.getItem("role");
  const location = useLocation();

  const hasRole = [ROLE];




    return (
     isAuthenticated && (hasRole.find(role => allowedRoles?.includes(role)))  ?
         <Outlet />
        : isAuthenticated 
        ? <UnauthenticatedScreen state={{ from: location }} replace />
        : <Navigate to="/" state={{ from: location }} replace />
        

    );
 

};
export default ProtectedRoute;
