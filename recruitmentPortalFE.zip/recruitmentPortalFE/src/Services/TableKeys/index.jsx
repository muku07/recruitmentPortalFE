export const Designation =
    [{
        designation_id: 1,
        designation_name: "Software Engineer"
    },
    {
        designation_id: 2,
        designation_name: "Associate Consultant",
    },
    {
        designation_id: 3,
        designation_name: "Consultant",
    },
    {
        designation_id: 4,
        designation_name: "Senior Consultant",
    },
    {
        designation_id: 5,
        designation_name: "Manager",
    },
    {
        designation_id: 6,
        designation_name: "Senior Manager",
    },
    {
        designation_id: 7,
        designation_name: "Portfolio Manager",
    },
    {
        designation_id: 8,
        designation_name: "Director",
    },
    {
        designation_id: 9,
        designation_name: "Senior Director",
    }
];



export const Role = 
[{
    role_id: 1,
    user_role: "ROLE_USER"
},
{
    role_id: 2,
    user_role: "ROLE_ADMIN"
},
{
    role_id: 3,
    user_role: "ROLE_SUPER_USER"
},
{
    role_id: 4,
    user_role: "ROLE_SUPER_VISOR"
}];

export const ReportsTo = 
[
    {
        report_id: 1,
        reports_name: "Ehtasham"
    },
    {
        report_id: 2,
        reports_name: "Rahul"
    },
    {
        report_id: 3,
        reports_name: "Pooja"
    },
    {
        report_id: 4,
        reports_name: "Manoj"
    },
]

