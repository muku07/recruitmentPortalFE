import { useState, useEffect } from "react";
import axios from "axios";

//Self-explanatory - you will only need the endpoint in your API calls
const BASE_URL = "https://mapii-portal-profile-service.azurewebsites.net";

const TOKEN = sessionStorage.getItem("bearerToken");

const config = {
  headers: {
    Accept: "application/json",
    "Content-Type": "application/json",
    Authorization: `Bearer ${TOKEN}`,
  },
};

//This works in a way that you only import the " import { ProfilesApi } from "../../../Services/API/Utilities/ProfilesApi"; " into your index
//You then have create a const to call it, for example, for a getter, use " const apiGet = apiProvider.GetApi("30f7fdbf-0690-403c-8e93-c34aab34c60b"); "
//For getting, use effect calling " apiGet("endpoint", {setter}); "

//There will be a get, post, put, delete that you import a single import and call any of its methods

//Param string endpoint
//Param setData
const GetProfilesApi = async (endpoint, item, setData) => {
  // setLoading(true);
  try {
    const result = await axios.post(`${BASE_URL}/${endpoint}`, item);
    setData(result.data);
  } catch (err) {
    //   setError(err.message || "Unexpected Error!");
    console.log(err);
  } finally {
    //   setLoading(false);
  }
};

//@Params int userId
//@Params setData
export const GetOneProfileApi = (userId) => {
  const [profileData, setProfileData] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let unmounted = false;
    const controller = new AbortController();

    setLoading(true);

    axios
      .get(`${BASE_URL}/profile/${userId}`, {
        signal: controller.signal,
      })
      .then((res) => {
        if (!unmounted) {
          setProfileData(res.data);
          setLoading(false);
        }
      })
      .catch((err) => {
        console.log("Profiles API:" + err);
        setError(err);
      });

    return function () {
      unmounted = true;
      controller.abort();
    };
  }, []);

  return {
    profileData,
    error,
    loading,
  };
};

//@Params string endpoint
//@Params object JSON item
//@Params setData
const PatchApi = async (endpoint, item, setData) => {
  // setLoading(true);
  try {
    const result = await axios.patch(`${BASE_URL}/${endpoint}`, item, config);
    setData(result.data);
  } catch (err) {
    // setError(err.message || "Unexpected Error!");
    console.log(err);
  } finally {
    // setLoading(false);
  }
};

//@Params string endpoint
//@Params object JSON item
//@Params setData
const DeleteProfileApi = async (endpoint, item, setData) => {
  try {
    await fetch(`${BASE_URL}/${endpoint}`, {
      method: "DELETE",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${TOKEN}`,
      },
      body: JSON.stringify(item),
    })
      .then((response) => response.json())
      .then((response) => {
        setData(response.result);
        console.log(response.response);
      });
  } catch (err) {
    console.log(err);
  }
};

export const ProfilesApi = {
  GetProfilesApi,
  PatchApi,
  DeleteProfileApi,
};
