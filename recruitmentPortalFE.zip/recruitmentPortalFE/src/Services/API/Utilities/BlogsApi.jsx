import { useState, useEffect } from "react";
import axios from "axios";

//Self-explanatory - you will only need the endpoint in your API calls
const BASE_URL = "https://mapii-blog-service.azurewebsites.net";

const TOKEN = sessionStorage.getItem("bearerToken");

const config = {
  headers: {
    Accept: "application/json",
    "Content-Type": "application/json",
    Authorization: `Bearer ${TOKEN}`,
  },
};

export const useGetAllBlogs = () => {
  const [data, setData] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let unmounted = false;
    const controller = new AbortController();

    setLoading(true);
    try {
      axios
        .get(`${BASE_URL}/blogs`, {
          signal: controller.signal,
        })
        .then((res) => {
          if (!unmounted) {
            setData(res.data);
            setLoading(false);
          }
        })
        .catch((err) => {
          console.log("API blog GetAll call:" + err);
        });
    } catch (err) {
      if (axios.isCancel(err)) {
        console.log(err.message);
      }
      setError(err.message || "Unexpected Error!");
    }

    return function () {
      unmounted = true;
      controller.abort();
    };
  }, []);

  return {
    data,
    error,
    loading,
    setData,
  };
};

export const useGetOneBlog = (endpoint) => {
  const [data, setData] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let unmounted = false;
    const controller = new AbortController();

    setLoading(true);
    try {
      axios
        .get(`${BASE_URL}/blogs/${endpoint}`, {
          signal: controller.signal,
        })
        .then((res) => {
          if (!unmounted) {
            setData(res.data);
            setLoading(false);
          }
        })
        .catch((err) => {
          console.log("API blog GetOne call:" + err);
        });
    } catch (err) {
      if (axios.isCancel(err)) {
        console.log(err.message);
      }
      setError(err.message || "Unexpected Error!");
    }

    return function () {
      unmounted = true;
      controller.abort();
    };
  }, []);

  return {
    data,
    error,
    loading,
  };
};

export const GetBlogImage = (blogId) => {
  const [data, setData] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let unmounted = false;
    const controller = new AbortController();

    setLoading(true);
    try {
      axios
        .get(
          `${BASE_URL}/blogs/image?blogId=${blogId}`,
          { responseType: "blob" },
          {
            signal: controller.signal,
          }
        )
        .then((res) => {
          if (!unmounted) {
            setData(URL.createObjectURL(res.data));
            setLoading(false);
          }
        })
        .catch((err) => {
          console.log("API blog BlogImage call:" + err);
          setData(null);
        });
    } catch (err) {
      if (axios.isCancel(err)) {
        console.log(err.message);
      }
      setError(err.message || "Unexpected Error!");
      console.log("API blog BlogImage call:" + err);
    }

    return function () {
      unmounted = true;
      controller.abort();
    };
  }, []);

  return {
    data,
    error,
    loading,
  };
};

export const useGetTags = () => {
  const [tags, setTags] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let unmounted = false;
    const controller = new AbortController();

    axios
      .get(`${BASE_URL}/blogs/tags`, {
        signal: controller.signal,
      })
      .then((res) => {
        if (!unmounted) {
          setTags(res.data.tags);
          setLoading(false);
        }
      })
      .catch((err) => {
        if (axios.isCancel(err)) {
          console.log(err.message);
        }
        console.log("API tags call:" + err.message);
        setError(err.message || "Unexpected Error!");
      });

    return function () {
      unmounted = true;
      controller.abort();
    };
  }, []);

  return [tags, error, loading];
};
