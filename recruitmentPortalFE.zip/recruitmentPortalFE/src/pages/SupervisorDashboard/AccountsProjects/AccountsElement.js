import styled from "styled-components";
import { MdClose } from "react-icons/md";

export const AccountsPage = styled.div`
  height: auto;
  display: flex;
  justify-content: center;
  // centers in the flex direction and the default flex-direction is row
  align-content: center;
  // centers perpendicular to the flex direction
`;

export const HeaderContainer = styled.div`
  position: absolute;
  top: 20%;
`;

export const Title = styled.h1`
  color: #0070ad;
  text-align: center;
  font-size: 2.5rem;
  font-family: "Ubuntu";
`;

export const AddNewButtonContainer = styled.div`
  position: absolute;
  top: 30%;
  left: 75%;
`;

export const NewAccountButton = styled.button`
  height: 50px;
  width: auto;
  padding: 10px;
  background: #ffffff;
  border-radius: 10px;
  border-color: #1ecbe1;
  box-shadow: -4px 4px 6px rgba(0, 120, 173, 0.5);
  cursor: pointer;
  font-weight: bold;
  font-size: 20px;

  &:hover {
    background-color: #abcdef;
  }
`;

//Container that houses and sets position and grid of tiles
export const AccountTileWrappers = styled.div`
  display: grid;
  grid-template-columns: 2fr 2fr 2fr;
  grid-column-gap: 75px;
  grid-row-gap: 50px;
  position: absolute;
  top: 40%;
  left: 8%;
  padding: 20px;
  height: auto;
  width: auto;
  margin: 30px auto;

  background: #fff;
  text-align: center;
`;

export const AccountTile = styled.button`
  background-color: white;
  height: 20vh;
  width: 49vh;
  margin-left: 8%;
  margin-right: -5%;
  margin-bottom: 3%;
  border: 2px solid #abcdef;
  font-size: 16px;
  border-radius: 12px;
  cursor: pointer;

  &:hover {
    background: transparent;
    transform: scale(1.1);
    transition: all 0.2s ease-in-out;
  }
`;

export const InnerHeader = styled.h2`
  text-decoration: none;
  color: #000000;
  font-family: "Ubuntu";
  font-size: 3.4vh;
  font-weight: 100;
  padding-left: 1%;
  padding-right: 1%;
  padding-bottom: 1%;
  margin-left: 3%;
  text-align: floor;
`;

export const ButtonImageContainer = styled.img`
  height: 75%;
  width: 100%;
  grid-column: ${(i) => i - 1}% 4;
  grid-row: ${(i) => i} / 4;
  background: #ececec;
  border-radius: 6px;
`;

//Modal styling from this point onwards

export const ModalBackground = styled.div`
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  position: absolute;
  top: 0%;
  display: flex;
  justify-content: center;
  align-items: center;
`;

//The inner bit that houses the main content
export const ModalWrapper = styled.div`
  width: 800px;
  height: 400px;
  box-shadow: 0 5px 16px rgba(0, 0, 0, 0.2);
  background: white;
  display: flex;
  justify-content: center;
  position: relative;
  z-index: 10;
  border-radius: 10px;
`;

export const ModalContent = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  color: #12abdb;
  text-align: center;
  font-family: "Ubuntu";

  h1 {
    color: #0070ad;
  }

  p {
    margin-bottom: 1rem;
  }

  button {
    padding: 10px;
    background: #0070ad;
    color: #fff;
    border: none;
    border-radius: 10px;
    border-color: #1ecbe1;
    box-shadow: -4px 4px 6px rgba(0, 120, 173, 0.5);
    cursor: pointer;
    font-weight: bold;
    font-size: 20px;
  }
`;

export const CloseModalButton = styled(MdClose)`
  cursor: pointer;
  position: absolute;
  top: 20px;
  right: 20px;
  width: 32px;
  height: 32px;
`;

export const AccountForm = styled.form``;

export const InputTextName = styled.input`
  font-size: 18px;
  padding: 10px;
  margin: 10px;
  background: papayawhip;
  border: 1px solid #0070ad;
  border-radius: 5px;

  ::placeholder {
    color: palevioletred;
  }
`;

export const InputTextDesc = styled.input`
  font-size: 18px;
  padding: 10px;
  margin: 10px;
  background: papayawhip;
  border: 1px solid #0070ad;
  border-radius: 5px;

  ::placeholder {
    color: palevioletred;
  }
`;

export const RadioButtonContainer = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  grid-column-gap: 10px;
  grid-row-gap: 10px;
  padding: 20px;
  height: auto;
  width: auto;
`;

export const RadioItem = styled.div`
  display: flex;
  align-items: center;
  height: 48px;
  position: relative;
  border: 1.5px solid #0070ad;
  box-sizing: border-box;
  border-radius: 10px;
  margin-bottom: 10px;
`;

export const RadioButtonLabel = styled.label`
  position: absolute;
  top: 25%;
  left: 4px;
  width: 24px;
  height: 24px;
  border-radius: 50%;
  background: white;
  border: 1px solid #ccc;
`;

export const Radiobutton = styled.input`
  opacity: 0;
  z-index: 1;
  cursor: pointer;
  width: 25px;
  height: 25px;
  margin-right: 10px;

  &:hover ~ ${RadioButtonLabel} {
    background: #ccc;
    &::after {
      font-family: "Ubuntu";
      display: block;
      color: white;
      width: 12px;
      height: 12px;
      margin: 4px;
    }
  }
  &:checked + ${RadioItem} {
    background: #c8e7f9;
    border: 2px solid yellowgreen;
  }
  &:checked + ${RadioButtonLabel} {
    background: #c8e7f9;
    border: 1px solid #c8e7f9;
    &::after {
      font-family: "Ubuntu";
      display: block;
      color: white;
      width: 12px;
      height: 12px;
      margin: 4px;
    }
  }
`;

export const FormError = styled.div`
  p {
    color: red;
  }
`;
