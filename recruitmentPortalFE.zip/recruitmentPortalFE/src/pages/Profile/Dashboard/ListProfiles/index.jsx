import React, { useState, useRef, useEffect, useCallback } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import Button from "@mui/material/Button";
import Input from "@mui/material/Input";
import InputAdornment from "@mui/material/InputAdornment";
import SearchIcon from "@mui/icons-material/Search";
import { ListProfilesCont, ProfileButtonCont } from "./ListProfilesElements";

function createData(name, calories, fat, carbs, protein) {
  return { name, calories, fat, carbs, protein };
}

const rows = [
  createData("Frozen yoghurt", 159, 6.0, 24, 4.0),
  createData("Ice cream sandwich", 237, 9.0, 37, 4.3),
  createData("Eclair", 262, 16.0, 24, 6.0),
  createData("Cupcake", 305, 3.7, 67, 4.3),
  createData("Gingerbread", 356, 16.0, 49, 3.9),
];

export default function BasicTable() {
  const navigate = useNavigate();

  const [searchQuery, setSearchQuery] = useState("");

  //*****Pagination*****\\
  const [posts, setPosts] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [postsPerPage, setPostsPerPage] = useState(10);

  useEffect(() => {
    const fetchPosts = async () => {
      const res = await axios.post(
        "https://mapii-portal-profile-service.azurewebsites.net/searchProfiles",
        { activateFlag: true }
      );
      setPosts(res.data);
    };

    fetchPosts();
  }, []);

  const indexOfLastPost = currentPage * postsPerPage;
  const indexOfFirstPost = indexOfLastPost - postsPerPage;
  const currentPosts = posts.slice(indexOfFirstPost, indexOfLastPost);

  //Change page
  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  function ViewProfile(id) {
    navigate("/view-profile", { state: { id: id } });
  }

  function EditProfile(emp) {
    navigate("/edit-user-profile", {
      state: { id: emp.userId },
    });
  }

  function myProfile() {
    navigate("/view-profile", { state: { id: storedId } });
  }

  const [isAdmin, setIsAdmin] = useState(false);
  const [storedId, setStoredId] = useState(0);
  useEffect(() => {
    let auth = sessionStorage.getItem("role");
    let azureId = sessionStorage.getItem("id");

    setStoredId(parseInt(azureId));
    // console.log(storedUsername);

    if (auth === "ROLE_ADMIN") {
      setIsAdmin(true);
    }
  }, []);

  return (
    <ListProfilesCont>
      {/* <Autocomplete
        freeSolo
        placeholder="Search Employees"
        disableClearable
        onChange={(e) => setSearchQuery(e.target.value)}
      /> */}

      <ProfileButtonCont>
        <Button
          style={{ margin: "0 10px" }}
          variant="contained"
          onClick={() => myProfile()}
        >
          My Profile
        </Button>

        <Input
          style={{
            marginLeft: 20,
          }}
          type="search"
          placeholder="Search"
          onChange={(e) => setSearchQuery(e.target.value)}
          endAdornment={
            <InputAdornment
              style={{
                cursor: "pointer",
              }}
              position="start"
            >
              <SearchIcon />
            </InputAdornment>
          }
        />
      </ProfileButtonCont>
      <TableContainer component={Paper}>
        <Table sx={{ minWidth: 650 }} aria-label="simple table">
          <TableHead>
            <TableRow>
              <TableCell align="center">Employee Name</TableCell>
              <TableCell align="center">Designation</TableCell>
              <TableCell align="center">Email Address</TableCell>
              <TableCell align="center">Skills</TableCell>
              <TableCell align="center">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {currentPosts
              ?.filter((post) => {
                if (searchQuery === "") {
                  // console.log(post);
                  return post;
                } else if (
                  post.firstName
                    .toLowerCase()
                    .includes(searchQuery.toLowerCase()) ||
                  post.lastName
                    .toLowerCase()
                    .includes(searchQuery.toLowerCase())
                  // ||
                  // post.skills
                  //   .toLowerCase()
                  //   .includes(searchQuery.toLowerCase())
                ) {
                  // console.log(post);
                  return post;
                }
                return null;
              })
              .map((employee, i) => (
                <TableRow
                  key={employee.userId}
                  sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                >
                  <TableCell component="th" scope="row">
                    {employee.firstName + " " + employee.lastName}
                  </TableCell>
                  <TableCell align="right">
                    {employee.designationName}
                  </TableCell>
                  <TableCell align="right">{employee.emailId}</TableCell>
                  <TableCell align="right">{employee.skills}</TableCell>
                  <TableCell align="right">
                    <Button
                      variant="contained"
                      disableElevation
                      onClick={() => ViewProfile(employee.userId)}
                    >
                      View
                    </Button>
                    {(isAdmin || storedId === employee.userId) && (
                      <Button
                        variant="outlined"
                        onClick={() => EditProfile(employee)}
                      >
                        Edit
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
          </TableBody>
        </Table>
      </TableContainer>
    </ListProfilesCont>
  );
}
