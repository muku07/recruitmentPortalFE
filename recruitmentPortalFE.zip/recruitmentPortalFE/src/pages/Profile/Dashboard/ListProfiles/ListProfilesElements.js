import styled from 'styled-components';

export const ListProfilesCont = styled('div')`
  width: '100%';
  padding: 30;
`;

export const ProfileButtonCont = styled('div')`
  margin: 20px 0;
`;
