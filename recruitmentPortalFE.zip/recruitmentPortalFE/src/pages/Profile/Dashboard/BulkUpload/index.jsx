import React, { memo, useState, useCallback, useEffect } from "react";
import axios from "axios";
import Card from "@mui/material/Card";
import Stepper from "@mui/material/Stepper";
import Step from "@mui/material/Step";
import StepLabel from "@mui/material/StepLabel";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import DragDrop from "./DragDrop";
import ImportFailed from "./ImportFailed";

import InfoIcon from "@mui/icons-material/Info";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";

const steps = ["Upload file", "Import employee"];

function BulkUpload({}) {
  const [activeStep, setActiveStep] = useState(0);
  const [isValid, setIsValid] = useState(false);
  const [isError, setIsError] = useState(false);
  const [isFailedResponse, setIsFailedResponse] = useState(false);
  const [successReport, setSuccessReport] = useState({
    uploaded: 200,
    added: 195,
    over: 3,
  });

  const handleIsError = useCallback((newState) => {
    setIsError(newState);
  });

  const handleFileDrop = useCallback((file) => {
    console.log("HANFLER");
    setActiveStep((prev) => prev + 1);
    const url = "http://localhost:8080/user-bulk-import";
    const formData = new FormData();
    formData.append("file", file);
    formData.append("fileName", file.name);
    const config = {
      headers: {
        "content-type": "multipart/form-data",
      },
    };
    axios
      .post(url, formData, config)
      .then((response) => {
        console.log(response.data);
        setIsValid(true);
        setIsFailedResponse(false);
      })
      .catch((e) => {
        console.log(e);
        setIsFailedResponse(true);
        setIsError(true);
      });
    setIsValid(true);
  });

  const handleNext = () => {
    if (activeStep == steps.length - 1) {
      alert("upload success/fail");
      return;
    }
    setActiveStep((prev) => prev + 1);
    setIsError(false);
  };

  return (
    <Card
      sx={{
        padding: "2rem",
        display: "grid",
        justifyItems: "center",
        gridGap: "0.75rem",
      }}
    >
      <Stepper
        activeStep={activeStep}
        sx={{ width: "60%", marginBottom: "1rem" }}
      >
        {steps.map((label, index) => {
          return (
            <Step key={label} completed={false}>
              <StepLabel error={activeStep === index && isError}>
                {label}
              </StepLabel>
            </Step>
          );
        })}
      </Stepper>

      {activeStep === 0 ? (
        <>
          <Typography variant="subtitle2">
            Ensure you're using the Candidate Template file
          </Typography>
          <Typography
            variant="subtitle2"
            sx={{ color: "var(--accent)", lineHeight: "0.875rem" }}
            onClick={() => alert("MORE INFO")}
          >
            <InfoIcon />
            Click here for more information
          </Typography>

          <DragDrop handlerFunc={handleFileDrop} setError={handleIsError} />

          <Typography variant="subtitle2">Don't have the template?</Typography>
          <Typography
            variant="subtitle2"
            sx={{ color: "var(--accent)" }}
            onClick={() => alert("DOWNLOAD")}
          >
            Download here
          </Typography>
          <Button
            onClick={handleNext}
            disabled={!isValid}
            variant="contained"
            disableElevation
            sx={{
              marginLeft: "auto",
              padding: "0.25rem 4rem",
            }}
          >
            Next
          </Button>
        </>
      ) : (
        <>
          {isFailedResponse ? (
            <ImportFailed />
          ) : (
            <>
              <Typography variant="h4">File Imported Successfully</Typography>
              <CheckCircleIcon
                sx={{
                  color: "var(--status-ok)",
                  height: "3rem",
                  width: "3rem",
                }}
              />
              <Typography variant="h6">Summary</Typography>
              <div
                style={{
                  display: "grid",
                  gridTemplate: "repeat(3, 1fr) / 90% 10%",
                }}
              >
                <Typography
                  variant="subtitle1"
                  sx={{ color: "var(--disabled)" }}
                >
                  Uploaded Records
                </Typography>
                {successReport.uploaded}
                <Typography sx={{ color: "var(--disabled)" }}>
                  Added Records
                </Typography>
                {successReport.added}
                <Typography sx={{ color: "var(--disabled)" }}>
                  Overode Records
                </Typography>
                {successReport.over}
              </div>
            </>
          )}
          <Button
            onClick={handleNext}
            disabled={!isValid}
            variant="contained"
            disableElevation
            sx={{
              marginLeft: "auto",
              padding: "0.25rem 4rem",
            }}
          >
            {isFailedResponse ? "Try again" : "Finish"}
          </Button>
        </>
      )}
    </Card>
  );
}

// export default memo(BulkUpload); PROFILE FIRST
export default BulkUpload;
