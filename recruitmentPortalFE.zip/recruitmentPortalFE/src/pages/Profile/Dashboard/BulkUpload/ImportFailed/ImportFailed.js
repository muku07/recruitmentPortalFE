import CancelIcon from "@mui/icons-material/Cancel";
import styles from "styled-components";
import { styled } from "@mui/material/styles";
export const ContentWrapper = styles.div`
  margin-top: auto;
  margin-bottom: auto;
  margin-left: auto;
  margin-right: auto;
  margin-top: 5%;
  text-align: center;
  font-size: 25px;
`;

export const HeaderImportFailed = styles.h1`
  font-size: 35px;
`;

export const CancelIconDiv = styled(CancelIcon)`
  margin-top: 2%;
  margin-bottom: 2%;
  color: red;
  font-size: 124px;
`;

export const ReasonFailure = styles.p`
  font-weight: 500;
`;

export const SeeFailureDetails = styles.p`
  color: #2f57ba;

  font-weight: 500;

  :hover{
    cursor: pointer;
  }
`;
