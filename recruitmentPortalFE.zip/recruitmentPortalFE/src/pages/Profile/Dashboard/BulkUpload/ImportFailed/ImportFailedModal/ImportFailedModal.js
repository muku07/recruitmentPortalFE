import Box from "@mui/material/Box";
import TableContainer from "@mui/material/TableContainer";
import styles from "styled-components";
import { styled } from "@mui/material/styles";

export const ContentWrapper = styles.div`
  margin-top: auto;
  margin-bottom: auto;
  margin-left: auto;
  margin-right: auto;
  margin-top: 5%;
  text-align: center;
  font-size: 25px;
`;

export const BoxStyled = styled(Box)`
  margin-top: 10%;
  margin-bottom: 50%;
  margin-left: 20%;
  margin-right: auto;
  margin-top: 5%;
  text-align: center;
  font-size: 25px;
  box-shadow: 1px 1px 10px #888888;
  background-color: white;
  max-width: 60%;
  max-height: 60%;
  min-height: 70%;
  transform: "translate(-50%, -50%)";
  border-radius: 5px;
  overflow-y: scroll;
  scroll-behavior: smooth;
  &::-webkit-scrollbar-track {
    /* background-color: rgb(137, 121, 169); */
    max-width: 1vw;
    border-radius: 1vw;
  }
  &::-webkit-scrollbar {
    /* background-color: rgb(137, 121, 169); */
    max-width: 1vw;
    border-radius: 1vw;
  }
  &::-webkit-scrollbar-thumb {
    background: rgb(105, 100, 100);
    border-radius: 1vw;
  }
`;

export const TableContainerStyle = styled(TableContainer)`
  margin-left: auto;
  margin-right: auto;
  max-width: 70%;
`;

export const HeaderH1 = styles.h1`
  text-align:left;
  margin-left:10px;
  margin-top:10px;
  font-size: 25px;
  font-weight: 500;
`;

export const ReasonFailureRed = styles.div`
  color:red;
  margin-left:20%;
  padding:10px;
  font-weight: bold;
`;
export const ReasonFailureRowNum = styles.div`
  color:grey;
  font-weight: bold;
`;

export const TableCellToTextLeft = styles.div`
  margin-left:10px;
  font-size: 15px;
  font-weight: bold;
`;
export const TableCellToTextRight = styles.div`
  text-align:left;
  margin-left:20%;
  font-weight: bold;
  font-size: 15px;
`;
