import ImportFailed from "..";
import {
  render,
  fireEvent,
  screen,
  shallow,
  getByTestId,
} from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import React from "react";

let component;

beforeEach(() => {
  component = render(<ImportFailed />);
});

test("Testing that the fail page renders", () => {
  render(<ImportFailed />);
});

test("File Import Failed text is on screen", async () => {
  const headerElement = component.getByTestId("headerImportFailed");
  expect(headerElement.textContent).toBe("File Import Failed");
});

test("Reason for import failure should be on screen", () => {
  const headerElement = component.getAllByTestId("reasonFailure")[0];
  expect(headerElement.textContent).toBe("Reason for import failure");
});

test("Testing that 'See the import failure details' button is rendered", () => {
  const headerElement = component.getAllByTestId("seeFailureDetails")[0];
  expect(headerElement.textContent).toBe("See the import failure details");
});

test("Testing that 'See the import failure details' button is clicked", () => {
  expect(
    fireEvent.click(component.getAllByTestId("seeFailureDetails")[0])
  ).toBeTruthy();
});

test("'See the import failure details' to be on screen", () => {
  expect(
    fireEvent.click(component.getAllByTestId("seeFailureDetails")[0])
  ).toBeTruthy();
  const headerElement = component.getAllByTestId("seeFailureDetails")[0];
  expect(headerElement.textContent).toBe("See the import failure details");
});
