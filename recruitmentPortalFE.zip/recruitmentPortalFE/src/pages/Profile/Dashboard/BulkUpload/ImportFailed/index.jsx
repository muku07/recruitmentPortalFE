import * as React from "react";
import { useState } from "react";

import {
  ContentWrapper,
  HeaderImportFailed,
  CancelIconDiv,
  ReasonFailure,
  SeeFailureDetails,
} from "./ImportFailed";

import ImportFailedModal from "./ImportFailedModal/index";
// import CancelIcon from "@mui/icons-material/Cancel";

const reasonForFailure = [
  { reason: "something bad happned" },
  { reason: "something really bad happned" },
  { reason: "something did happen" },
  { reason: "bad stuff happens" },
  { reason: "the happning" },
  { reason: "something happned" },
  { reason: "bad happned" },
  { reason: "something something something dark side" },
  { reason: "something bad happned" },
  { reason: "something really bad happned" },
  { reason: "something did happen" },
  { reason: "bad stuff happens" },
  { reason: "the happning" },
  { reason: "something happned" },
  { reason: "bad happned" },
  { reason: "something something something dark side" },
  { reason: "something bad happned" },
  { reason: "something really bad happned" },
  { reason: "something did happen" },
  { reason: "bad stuff happens" },
  { reason: "the happning" },
  { reason: "something happned" },
  { reason: "bad happned" },
  { reason: "something something something dark side" },
];

function ImportFailed() {
  //   const [isShown, setIsShown] = useState(true);

  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);

  return (
    <ContentWrapper>
      <HeaderImportFailed  data-testid="headerImportFailed">File Import Failed</HeaderImportFailed>
      <CancelIconDiv />
      <ReasonFailure data-testid="reasonFailure">Reason for import failure</ReasonFailure>
      <SeeFailureDetails data-testid="seeFailureDetails" onClick={handleOpen}>
        See the import failure details
      </SeeFailureDetails>
      <ImportFailedModal
        reasonForFailure={reasonForFailure}
        open={open}
        setOpen={setOpen}
      />
    </ContentWrapper>
  );
}
export default ImportFailed;
