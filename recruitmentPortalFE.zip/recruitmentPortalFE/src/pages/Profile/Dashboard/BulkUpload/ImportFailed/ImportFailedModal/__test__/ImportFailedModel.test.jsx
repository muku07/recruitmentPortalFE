import ImportFailedModal from "..";
import { render, fireEvent, screen, shallow } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import React from "react";


let component;
beforeEach(() => {
  component = render(<ImportFailedModal />);
});
// const Wrapper = () => {
//   return (
//     <ImportFailedModel />
//   );

test("Testing that ImportFailedModel page renders", () => {
  render(<ImportFailedModal />);
});

test("modal should show as 'Import failure details' on its header", () => {
  render(<ImportFailedModal open={true}/>);
   const headerElement = component.getByTestId("headerH1");
  expect(headerElement.textContent).toBe('Import failure details');
});


test("modal should show as 'Reason for failure' on table", () => {
  render(<ImportFailedModal open={true}/>);
   const headerElement = component.getByTestId("tableCellToTextRight");
  expect(headerElement.textContent).toBe('Reason for failure');
});

test("modal should show as 'Rows' on table", () => {
  render(<ImportFailedModal open={true}/>);
   const headerElement = component.getByTestId("tableCellToTextLeft");
  expect(headerElement.textContent).toBe('Rows');
});


