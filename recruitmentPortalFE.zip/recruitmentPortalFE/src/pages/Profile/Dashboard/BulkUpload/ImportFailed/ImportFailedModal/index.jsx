import * as React from "react";

import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";
import ReportProblemSharpIcon from "@mui/icons-material/ReportProblemSharp";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import AttachFileIcon from "@mui/icons-material/AttachFile";
import {
  ContentWrapper,
  BoxStyled,
  HeaderH1,
  ReasonFailureRed,
  TableContainerStyle,
  ReasonFailureRowNum,
  TableCellToTextLeft,
  TableCellToTextRight
} from "./ImportFailedModal";
import { TableView } from "@mui/icons-material";
function ImportFailedModal({ reasonForFailure, open, setOpen }) {

  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  return (
    <ContentWrapper>
     
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <BoxStyled>
          <HeaderH1 data-testid="headerH1">Import failure details</HeaderH1>

          <Typography sx={{ mt: 2 }}>
            <TableContainerStyle>
              <Table aria-label="simple table">
                <TableHead>
                  <TableRow>
                    <TableCell>
                      <TableCellToTextLeft data-testid="tableCellToTextLeft">Rows</TableCellToTextLeft>
                    </TableCell>

                    <TableCell align="right">
                      <TableCellToTextRight data-testid="tableCellToTextRight">Reason for failure</TableCellToTextRight>
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {reasonForFailure?.map((row, index) => (
                    <TableRow key={index}>
                      <TableCell component="th" scope="row">
                     
                        <ReasonFailureRowNum>
                        <AttachFileIcon />&emsp;Row {index + 1}
                        </ReasonFailureRowNum>
                      </TableCell>
                      <TableCell>
                        <ReasonFailureRed>
                          <ReportProblemSharpIcon />
                          &emsp;
                          {row.reason}
                        </ReasonFailureRed>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainerStyle>
          </Typography>
        </BoxStyled>
      </Modal>
    </ContentWrapper>
  );
}
export default ImportFailedModal;
