import React, { memo, useState, useCallback, useEffect } from "react";
import AddCircleIcon from "@mui/icons-material/AddCircle";
import Chip from "@mui/material/Chip";
import Snackbar from "@mui/material/Snackbar";
import MuiAlert from "@mui/material/Alert";
import FileUploadRoundedIcon from "@mui/icons-material/FileUploadRounded";
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";
import Typography from "@mui/material/Typography";
import { DragContainer } from "./BulkUploadElements";
import { useDropzone } from "react-dropzone";
import { read, utils } from "xlsx";

function DragDrop({ handlerFunc, setError }) {
  const onDropAccepted = useCallback((acceptedFiles) => {
    setFiles(acceptedFiles[0]);
    setSnackIsOpen(true);
    setError(false);
    setErrors([]);

    errors.length == 0 && handlerFunc(acceptedFiles[0]);
  }, []);

  const onDropRejected = () => {
    setFiles(fileRejections[0]?.file);
    setError(true);
    setSnackIsOpen(true);
  };

  const handleDelete = useCallback((name) => {
    console.log("deleting " + name);
    setFiles([]);
    setErrors([]);
    setError(false);
    setSnackIsOpen(false);
  }, []);

  const validator = (file) => {
    const expectedHeaders = [
      "User ID",
      "First Name",
      "Last Name",
      "GGID",
      "Address",
      "Designation ID",
      "Contact number",
      "Reports to",
      "Email",
      "Capability Unit ID",
      "Role ID",
    ];
    if (file && file.kind && file.type) return; // its of DataTransferItem type
    const error = [];
    // its of File type
    if (file && file.path != "") {
      if (file.type === "") {
        error.push({
          code: "incorrect-file-type",
          message: "The file type must be: .csv, .xlsx, .xls",
        });
        setErrors([...error]);
        setError(true);
        return error;
      }

      (async () => {
        const reader = new FileReader();
        reader.onload = (e) => {
          const data = new Uint8Array(e.target.result);
          const wb = read(data, { type: "array", blankrows: true });

          if (wb.Strings.length == 0) {
            error.push({ code: "empty-file", message: "File is empty" });
            setError(true);
            setErrors([...error]);
            return error;
          }
          const sheet = wb.Sheets[wb.SheetNames[0]];
          const firstSheet = sheet["!ref"];
          const range = utils.decode_range(firstSheet);
          const missingHeaders = [];
          const blankCells = [];

          // range.{s,e} = {starting cell, end cell}
          for (let C = range.s.c; C <= range.e.c; ++C) {
            for (let R = range.s.r; R <= range.e.r; ++R) {
              var cell = sheet[utils.encode_cell({ c: C, r: R })];
              let value = cell && cell.t && utils.format_cell(cell);
              if (R == 0) {
                // should we lowercase & strip spaces?
                if (!value.endsWith(expectedHeaders[C])) {
                  missingHeaders.push(expectedHeaders[C]);
                }
              }
              if (typeof value === "undefined") {
                blankCells.push("" + utils.encode_cell({ c: C, r: R }));
              }
            }
          }
          missingHeaders.length > 0 &&
            error.push({
              code: "incorrect-headers",
              message: `The file has misspelt or is missing the following headers: ${missingHeaders.join(
                ", "
              )}`,
            });

          blankCells.length > 0 &&
            error.push({
              code: "blank-cells",
              message: `The following cells are blank: ${blankCells.join(
                ", "
              )}`,
            });

          if (range.e.r < 1) {
            error.push({
              code: "not-populated",
              message: "The file contains no records",
            });
          }

          if (range.e.c > expectedHeaders.length) {
            error.push({
              code: "data-out-bounds",
              message: "Data out of bounds, none should be past column K",
            });
          }

          if (error.length > 0) {
            setError(true);
            setErrors([...error]);
            return error;
          }
        };
        reader.readAsArrayBuffer(file);
      })();
    }
    return null;
  };

  const [files, setFiles] = useState([]);
  const [errors, setErrors] = useState([]);
  const [snackIsOpen, setSnackIsOpen] = useState(false);

  const {
    acceptedFiles,
    fileRejections,
    getRootProps,
    getInputProps,
    isDragActive,
    isDragReject,
  } = useDropzone({
    onDropAccepted,
    onDropRejected,
    maxFiles: 1,
    validator,
    accept: {
      "text/csv": [".csv"],
      "application/vnd.ms-excel": [".xls"],
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": [
        ".xlsx",
      ],
    },
  });

  useEffect(() => setFiles(acceptedFiles), [acceptedFiles]);

  return (
    <>
      <DragContainer
        {...getRootProps({ isDragReject, isDragActive })}
        component="div"
        variant="outlined"
      >
        <input {...getInputProps()} multiple={false} />

        {files.length > 0 ? ( // this doesn't need to be done as 1 file only, can't figure out a way to implement conditional rendering; open to suggestions
          files.map((file) => (
            <Chip
              label={
                <>
                  <b>{file.path}</b>
                  <span> ({formatFileSize(file.size * 100)})</span>
                </>
              }
              key={file.path}
              variant="outlined"
              color={"primary"}
              deleteIcon={<CloseRoundedIcon />}
              onDelete={() => handleDelete(file.name)}
              sx={{
                backgroundColor: "var(--bg-primary)",
                border: "0.15rem solid",
              }}
            />
          ))
        ) : (
          <Typography
            variant="subtitle1"
            sx={{ display: "flex", alignItems: "center", height: "100%" }}
          >
            {isDragActive ? (
              isDragReject ? (
                <CloseRoundedIcon sx={{ height: "60%", width: "100%" }} />
              ) : (
                <FileUploadRoundedIcon
                  sx={{
                    height: "60%",
                    width: "100%",
                  }}
                />
              )
            ) : (
              <>
                Drag file here or click to browse
                <AddCircleIcon sx={{ margin: "0.2rem" }} />
              </>
            )}
          </Typography>
        )}
      </DragContainer>
      {errors.map((e) => (
        <Typography
          variant="subtitle2"
          key={e.code}
          sx={{
            color: "var(--status-error)",
            width: "70%",
          }}
        >
          {e.message}
        </Typography>
      ))}

      <Snackbar
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
        open={snackIsOpen}
        onClose={() => setSnackIsOpen(false)}
      >
        <MuiAlert
          elevation={6}
          variant="filled"
          severity={errors.length > 0 ? "error" : "success"}
          sx={{
            backgroundColor:
              errors.length > 0 ? "var(--status-error)" : "var(--status-ok)",
          }}
          onClose={() => setSnackIsOpen(false)}
        >
          {errors.length > 0
            ? "File upload failed"
            : "File uploaded successfully"}
        </MuiAlert>
      </Snackbar>
    </>
  );
}

// https://www.codexworld.com/how-to/convert-file-size-bytes-kb-mb-gb-javascript/
function formatFileSize(bytes, decimalPoint) {
  if (bytes == 0) return "0 Bytes";
  var k = 1000,
    dm = decimalPoint || 2,
    sizes = ["Bytes", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"],
    i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + " " + sizes[i];
}

export default memo(DragDrop);
