import Button from "@mui/material/Button";
import { styled } from "@mui/material/styles";

export const getColor = (props) => {
  if (props.isDragReject) return "#e45649";
  if (props.isDragActive) return "#79a7ae";
};

export const DragContainer = styled(Button)`
  width: 70%;
  aspect-ratio: 1/0.15;
  overflow: hidden;
  text-transform: none;
  border-radius: 1rem;
  flex-direction: column;
  justify-content: space-evenly;
  background-color: ${(props) => getColor(props) + "1e"};
  border: 0.25rem ${(props) => getColor(props)} dotted;
  transition: border 0.25s ease-in-out, background-color 0.25s ease-in-out;
  :hover {
    border: 0.25rem var(--accent) dotted !important;
  }
`;
