import React from 'react';
import ExitProfile from '..';
import { render, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';

let component;

beforeEach(() => {
  component = render(<ExitProfile />);
});

test('Testing that the page renders', () => {
  render(<ExitProfile />);
});

test('Testing that the header renders correctly with text', () => {
  const headerElement = component.getByTestId('header');

  expect(headerElement.textContent).toBe('Leavers Profiles');
});

test('Testing the search bar will be empty with placeholder and search icon in corner', () => {
  const searchBarElement = component.getByTestId('searchBar');

  expect(searchBarElement.textContent).toBe('');
  expect(searchBarElement.getAttribute('placeholder')).toBe(
    'Employee first name or last name'
  );
});

test('Testing the searchbar will store the text', () => {
  const searchBar = component.getByTestId('searchBar');

  fireEvent.change(searchBar, {
    target: {
      value: 'Test',
    },
  });

  expect(searchBar.value).toBe('Test');
});

test('Testing that the table is created with the correct header titles', () => {
  const tableElement = component.getByTestId('tableElement');
  const tableHead = component.getByTestId('tableHead');

  expect(tableElement).toBeInTheDocument();
  expect(tableHead.textContent).toBe(
    "Employee IDFirst NameLast NameReports ToExit DateCommentsLeaver's UnitAction"
  );
});

test('Testing that the calendar component is rendered', () => {
  const calendar = component.getByTestId('calendar');

  expect(calendar).toBeInTheDocument();
});

test('Testing that the calendar component can store dates', () => {
  const calendar = component.getByTestId('calendar');

  fireEvent.change(calendar, {
    target: {
      value: '2022-07-15',
    },
  });

  expect(calendar.value).toBe('2022-07-15');
});

test('Testing that submit button is rendered', () => {
  const submit = component.getByTestId('submit');

  expect(submit).toBeInTheDocument();
});

test('Testing that submit button has content', () => {
  const submit = component.getByTestId('submit');

  expect(submit.textContent).toBe('Submit');
});

// Components that need testing:
// - Calendar - done
// - Submit Button - done
