import React, { useState, useRef, useEffect } from "react";
import { Form } from "react-bootstrap";
import {
  ExitProfilesPage,
  BackButtonContainer,
  MainContentContainer,
  MainTitle,
  MainTitleContainer,
  SearchFormContainer,
  BackButton,
  SearchInput,
  TopButtonContainer,
  ExitTable,
  ExitTableBody,
  ExitTableBodyTR,
  ExitTableD,
  ExitTableDCal,
  CalendarPopupButtonContainer,
  ExitTableH,
  ExitTableHead,
  ExitTableHeadTR,
  ActionButton,
  ExitCheckbox,
  ModalBackground,
  ModalWrapper,
  ModalContent,
  EntryError,
  CalendarPopupButton,
  ConfirmError,
  DateContainer,
  PaginationContainer,
  ExitSelected,
  Dates,
} from "./ExitProfileElements";
import "./ExitProfileStyling.css";
import axios from "axios";
import { ProfilesApi } from "../../../../Services/API/Utilities/ProfilesAPI";
import { apiProvider } from "../../../../Services/API/Utilities/Provider";
import "react-calendar/dist/Calendar.css";
import Pagination from "../../../../components/Pagination";
import { DataGrid } from "@mui/x-data-grid";

function ExitProfile() {
  const [profile, setProfile] = useState([]);
  //First name and lastName is stored here to be run through filter
  const [searchQuery, setSearchQuery] = useState("");
  const [showModal, setShowModal] = useState(false);
  //For the checkbox states and storing selected rows
  const [isChecked, setIsChecked] = useState([]);
  //For holding and showing where fields are not filled
  const [error, setError] = useState("");
  const [submit, setSubmit] = useState([0]);
  const [date, setDate] = useState(new Date());
  const [exitDate, setexitDate] = useState("");

  const BASE_URL = "https://mapii-portal-profile-service.azurewebsites.net";
  const TOKEN =
    "eyJlbWFpbCI6ImFAei5jb20iLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhQHouY29tIiwiYXV0aG9yaXRpZXMiOlsiUk9MRV9BRE1JTiJdLCJleHQiOnsiZ2dJRCI6IjEwMSIsImVtYWlsIjoiYUB6LmNvbSJ9LCJpc3MiOiJNQVBJSSIsImlhdCI6MTY1NjM0ODc4MiwiZXhwIjoxNjU2MzUwNTgyfQ.yXl1qbCrVmZe1GKTcJkhqOvOEaTaffBWILewN-Eru0pV4HZPiVwq3kM7sWWYyDvB3ej3UtBjyGHYTZHYC8u_pA";
  const config = {
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      Authorization: `bearer ${TOKEN}`,
    },
  };

  const GetProfilesApi = async (endpoint, setData) => {
    // setLoading(true);
    let item = { activateFlag: "true" };

    console.log(item);

    try {
      const result = await axios.post(`${BASE_URL}/${endpoint}`, item, config);
      setData(result.data);
    } catch (err) {
      //   setError(err.message || "Unexpected Error!");
      console.log(err);
    } finally {
      //   setLoading(false);
    }
  };

  useEffect(() => {
    GetProfilesApi("searchProfiles", setProfile);
    getUnitApi.request();
    getReportsToApi.request();

    setTimeout(() => {
      GetProfilesApi("searchProfiles", setProfile);
    }, 2000);
  }, []);

  //.....................functions to handle checkboxes - select all and single

  const handleSelectAll = () => {
    const checkboxes = document.querySelectorAll("input[type = 'checkbox']");
    if (document.getElementById("selectAll").checked) {
      setIsChecked(profile.map((emp) => emp));
      checkboxes.forEach(function (checkbox) {
        checkbox.checked = true;
      });
    } else {
      checkboxes.forEach(function (checkbox) {
        setIsChecked([]);
        checkbox.checked = false;
      });
    }
  };

  const handleSelectOne = (emp) => {
    if (document.getElementById(emp.userId).checked) {
      setIsChecked([...isChecked, emp]);
    } else {
      if (!document.getElementById(emp.userId).checked) {
        setIsChecked(isChecked.filter((item) => item.userId !== emp.userId));
      }
    }
  };

  //Outside function general console log to track when any checkbox is clicked and placed in array
  console.log("Inside the checked array", isChecked);

  // --------------------------- function to handle Reports To and Assign Role of each row
  function handleChangeExitDate(e, i) {
    console.log("index: " + i);
    console.log("property name: " + e.target.name);
    let newArr = [...profile];
    newArr[i].exitDate = e.target.value;
    setProfile(newArr);
  }

  const DeleteApi = (endpoint, item, setData) => {
    // setLoading(true);
    try {
      console.log(item);
      const result = axios.delete(
        `https://mapii-portal-profile-service.azurewebsites.net/${endpoint}`,
        item,
        config
      );
      setData(result.data);
    } catch (err) {
      // setError(err.message || "Unexpected Error!");
      console.log(err);
    }
  };

  //---------------------------- function to handle submits of single and in the confirmation modal
  function HandleDeleteOneProfile(emp) {
    if (emp.exitDate === "") {
      setError(
        `You must provide the Exit Date for profile: ` +
          emp.userId +
          " , " +
          emp.firstName +
          " , " +
          emp.lastName
      );
      return;
    }
    setError("");

    const itemLogs = {};
    let item = [
      {
        profileId: emp.userId,
        profileExitId: emp.profileExitId,
        exitDate: exitDate,
      },
    ];
    itemLogs["deleteProfiles"] = item;
    console.log("To be sent to backend: ", itemLogs);
    ProfilesApi.DeleteProfileApi("profile", itemLogs, setSubmit).then(() => {
      window.location.reload(false);
    });
    console.log(submit);
  }

  function HandleDeleteProfiles() {
    for (let i = 0; i < isChecked.length; i++) {
      let emp = isChecked[i];
      if (emp[i].exitDate === "") {
        setError(
          `You must provide the Exit Date for profile: ` +
            emp.userId +
            " , " +
            emp.firstName +
            " , " +
            emp.lastName
        );
        return;
      }
      setError("");
    }
    const itemLogs = {}; //Creating an object array
    let tempArr = []; //Creating a temp array for the loop to store each element for array

    for (let i = 0; i < isChecked.length; i++) {
      let item = {
        profileId: isChecked[i].userId,
        profileExitId: isChecked[i].profileExitId,
        exitDate: isChecked[i].exitDate,
      };
      tempArr.push(item);
      itemLogs["activeProfiles"] = tempArr;
    }
    console.log("To be sent to backend: ", itemLogs);
    ProfilesApi.DeleteProfileApi("profile", itemLogs, setSubmit);

    setShowModal((prev) => !prev);
  }

  console.log(profile);

  const CalendarModal = ({ showModal, setShowModal }) => {
    const modalRef = useRef();

    const closeModal = (e) => {
      if (modalRef.current === e.target) {
        setShowModal(false);
      }
    };

    return (
      <>
        {showModal ? (
          <ModalBackground ref={modalRef} onClick={closeModal}>
            <ModalWrapper showModal={showModal}>
              <ModalContent>
                {error && <ConfirmError>{error}</ConfirmError>}
              </ModalContent>
            </ModalWrapper>
          </ModalBackground>
        ) : null}
      </>
    );
  };

  const openModal = () => {
    setShowModal((prev) => !prev);
  };

  //*****Pagination*****\\
  const [posts, setPosts] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [postsPerPage, setPostsPerPage] = useState(5);

  useEffect(() => {
    const fetchPosts = async () => {
      const res = await axios.post(
        "https://mapii-portal-profile-service.azurewebsites.net/searchProfiles",
        { activateFlag: true }
      );
      setPosts(res.data);
    };

    fetchPosts();
  }, []);

  const getReportsToApi = apiProvider.GetAllApi("reportsto");
  const getUnitApi = apiProvider.GetAllApi("capabilityUnits");

  const convertReport = (emp) => {
    for (let i = 0, l = getReportsToApi.data.length; i < l; i++) {
      if (getReportsToApi.data[i].id === parseInt(emp)) {
        return getReportsToApi.data[i].name;
      }
    }
  };

  const convertUnit = (emp) => {
    for (let i = 0, l = getUnitApi.data.length; i < l; i++) {
      if (getUnitApi.data[i].capabilityUnitId === parseInt(emp)) {
        return getUnitApi.data[i].capabilityUnitName;
      }
    }
  };

  console.log(posts);
  //Get current posts
  const indexOfLastPost = currentPage * postsPerPage;
  const indexOfFirstPost = indexOfLastPost - postsPerPage;
  const currentPosts = posts.slice(indexOfFirstPost, indexOfLastPost);

  //Change page
  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  const columns = [
    { field: "empName", headerName: "Employee Name", width: 130 },
    { field: "designation", headerName: "Designation", width: 130 },
    { field: "exitDate", headerName: "Exit Date", width: 90 },
    { field: "email", headerName: "Email", width: 150 },
    { field: "comments", headerName: "Comments", width: 100 },
    { field: "actions", headerName: "Actions", width: 70 },
  ];

  const rows = [
    { id: 1, lastName: "Snow", firstName: "Jon", age: 35 },
    { id: 2, lastName: "Lannister", firstName: "Cersei", age: 42 },
    { id: 3, lastName: "Lannister", firstName: "Jaime", age: 45 },
    { id: 4, lastName: "Stark", firstName: "Arya", age: 16 },
    { id: 5, lastName: "Targaryen", firstName: "Daenerys", age: null },
    { id: 6, lastName: "Melisandre", firstName: null, age: 150 },
    { id: 7, lastName: "Clifford", firstName: "Ferrara", age: 44 },
    { id: 8, lastName: "Frances", firstName: "Rossini", age: 36 },
    { id: 9, lastName: "Roxie", firstName: "Harvey", age: 65 },
  ];

  // [{field: "Employee Name"}, {field: "Designation"}, {field: "Exit Date"}, {field: "Email"}, {field: "Comments"}, {field: "Actions"}]
  return (
    <ExitProfilesPage>
      <MainTitleContainer>
        <MainTitle data-testid="header">Leaver's Profile</MainTitle>
      </MainTitleContainer>

      <DataGrid
        rows={rows}
        columns={columns}
        pageSize={5}
        rowsPerPageOptions={[5]}
        checkboxSelection
      />
    </ExitProfilesPage>
  );
}

export default ExitProfile;

{
  /* <>
      <ExitProfilesPage>
        <MainTitleContainer>
          <MainTitle data-testid="header">Leaver's Profile</MainTitle>
        </MainTitleContainer>
  
        <SearchFormContainer>
          <SearchInput
            data-testid="searchBar"
            type="search"
            value={searchQuery}
            placeholder="Employee first name or last name"
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </SearchFormContainer>

        {error && !showModal && (
          <EntryError>
            <p>{error}</p>
          </EntryError>
        )}
        <MainContentContainer>
          <ExitTable data-testid="tableElement">
            <ExitTableHead data-testid="tableHead">
              <ExitTableHeadTR>
                <ExitTableH>
                  <ExitCheckbox
                    data-testid="selectAll"
                    type="checkbox"
                    name="selectAll"
                    id="selectAll"
                    onChange={(e) => handleSelectAll(e)}
                  ></ExitCheckbox>
                </ExitTableH>
                <ExitTableH>
                  <p>Profile Id</p>
                </ExitTableH>
                <ExitTableH>
                  <p>First Name</p>
                </ExitTableH>
                <ExitTableH>
                  <p>Last Name</p>
                </ExitTableH>
                <ExitTableH>
                  <p>Exit Date</p>
                </ExitTableH>
                <ExitTableH>
                  <p>Reports To</p>
                </ExitTableH>
                <ExitTableH>
                  <p>Leaver's Unit</p>
                </ExitTableH>
                <ExitTableH>
                  <p>Action</p>
                </ExitTableH>
              </ExitTableHeadTR>
            </ExitTableHead>
            <ExitTableBody data-testid="tableBody">
              {currentPosts
                .filter((emp) => {
                  if (searchQuery === "") {
                    return emp;
                  } else if (
                    emp.firstName
                      .toLowerCase()
                      .includes(searchQuery.toLowerCase())
                    
                  ) {
                    return emp;
                  } else if (
                    emp.lastName
                      .toLowerCase()
                      .includes(searchQuery.toLowerCase())
                  ) {
                    return emp;
                  }
                  return null;
                })
                .map((emp, i) => (
                  <ExitTableBodyTR key={i} data-testid="tableBodyRow">
                    <ExitTableD>
                      <ExitCheckbox
                        data-testid={emp.userId}
                        type="checkbox"
                        id={emp.userId}
                        onChange={() => handleSelectOne(emp)}
                      ></ExitCheckbox>
                    </ExitTableD>
                    <ExitTableD>
                      <p>{emp.userId}</p>
                    </ExitTableD>
                    <ExitTableD>
                      <p>{emp.firstName}</p>
                    </ExitTableD>
                    <ExitTableD>
                      <p>{emp.lastName}</p>
                    </ExitTableD>
                    <ExitTableD>
            
                      <Dates>
                        <div className="date1">
                          <div className="row">
                            <div className="col-md-4">
                              <Form.Group controlId="exitDate">
                                <Form.Control
                                  data-testid="calendar"
                                  type="date"
                                  name="exit"
                                  onChange={(e) => {
                                    setexitDate(e.target.value);
                                    console.log(e.target.value);
                                    console.log(typeof e.target.value);
                                  }}
                                />
                              </Form.Group>
                            </div>
                          </div>
                        </div>
                      </Dates>
                    </ExitTableD>
                    <ExitTableD>
                      <p>{convertReport(emp.reportsTo)}</p>
                    </ExitTableD>
                    <ExitTableD>
                      <p>{convertUnit(emp.capabilityUnitId)}</p>
                    </ExitTableD>
                    <ExitTableD>
                      <ActionButton
                        data-testid="submit"
                        onClick={() => HandleDeleteOneProfile(emp)}
                      >
                        Submit
                      </ActionButton>
                    </ExitTableD>
                  </ExitTableBodyTR>
                ))}
            </ExitTableBody>
          </ExitTable>
          <PaginationContainer>
            <Pagination
              postsPerPage={postsPerPage}
              totalPosts={profile.length}
              paginate={paginate}
            />
          </PaginationContainer>
        </MainContentContainer>
        <CalendarModal showModal={showModal} setShowModal={setShowModal} />
      </ExitProfilesPage>
    </> */
}
