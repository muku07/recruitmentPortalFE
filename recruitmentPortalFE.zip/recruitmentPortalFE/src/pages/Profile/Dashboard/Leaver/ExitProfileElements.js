import styled from 'styled-components';
import SearchIcon from "../../../../assets/SearchIcon.svg";
import { MdClose } from 'react-icons/md';

export const ExitProfilesPage = styled.div`
  height: 190vh;
  overflow: hidden;
  max-width: 100%;
  width: auto;
  background: #fff;
  display: flex;
  justify-content: center;
  // centers in the flex direction and the default flex-direction is row
  align-content: center;
  // centers perpendicular to the flex direction
`;

//This holds and positions the header
export const MainTitleContainer = styled.div`
  position: absolute;
  top: 8%;
  padding: 10px;
  height: 50vh;
  width: auto;
`;

//The header to style the text – font-family already stated in acc.css
export const MainTitle = styled.h1`
  text-align: center;
  color: #0070ad;
  font-size: 50px;
  font-weight: 600;
  padding: 50px 0px 50px 0px;
`;

export const BackButtonContainer = styled.div`
  margin-left: -1000px;
  margin-top: 145px;
  height: 30px;
`;

export const BackButton = styled.a`
  height: 40px;
  width: 150px;
  padding: 10px 15px;
  background: #ececec;
  border-radius: 4px;
  background-color: #0070ad;
  font-size: 14px;
  color: white;
  border: none;
  cursor: pointer;
`;
export const SearchFormContainer = styled.div`
  position: absolute;
  left: 50%;
  top: 29%;
  transform: translateX(-50%);
  height: 50vh;
  width: auto;
  margin: 10px 0;
  overflow: hidden;
`;

//If you was to have a search container this goes inside the form container - styling of the input
export const SearchInput = styled.input`
  width: 500px;
  border: 1.5px solid #0070ad;
  border-radius: 5px;
  display: block;
  padding: 9px 4px 9px 9px;
  font-size: 14px;
  color: #272936;
  background: transparent url(${SearchIcon}) no-repeat 455px center;
  ::placeholder {
    color: #bbb;
  }
  &:focus {
    box-shadow: 0 0 3px 0 #12abdb;
    border-color: #12abdb;
    outline: none;
  }

  @media screen and (min-width: 2560px) {
  }
`;

export const TopButtonContainer = styled.div`
  position: absolute;
  left: 46%;
  top: 28.5%;
  height: 50vh;
  width: auto;
`;

export const ExitSelected = styled.button`
  padding: 10px 15px 10px 15px;
  position: relative;
  border-radius: 4px;
  border: none;
  background: #003857;
  color: white;
  font-size: 18px;
  text-align: center;
  cursor: pointer;
  opacity: ${({ opacitybtn }) => (opacitybtn ? '0.3' : '1')};
`;

export const MainContentContainer = styled.div`
  display: flex;
  flex-direction: column;
  position: absolute;
  left: 16%;
  right: 16%;
  top: 38%;
  //Needs to change accordingly
  height: 100px;
  min-width: 300px;
  min-height: 400px;
`;

export const ReportsToInput = styled.select`
  border: none;
  height: 35px;
  font-size: 16px;

  option {
    color: black;
    background: white;
    display: flex;
    white-space: pre;
  }
`;

export const LeaversUnitInput = styled(ReportsToInput)``;

export const ActionButton = styled(ExitSelected)``;

export const ExitCheckbox = styled.input``;

//For the whole table
export const ExitTable = styled.table`
  width: 100%;
  border-collapse: collapse;
  text-align: center;
  border-radius: 2px;
`;

//For the table head
export const ExitTableHead = styled.thead`
  position: sticky;
  z-index: 3;
`;

//Table head row
export const ExitTableHeadTR = styled.tr`
  background: #0070ad;
`;

//Header for a cell
export const ExitTableH = styled.th`
  padding: 8px;
  border: 2px solid;

  font-weight: 600;
  font-size: 18px;
  color: #12abdb;

  p {
    color: black;
  }
`;

//The body of the table
export const ExitTableBody = styled.tbody`
  height: 70px;
`;

//Table body table rows
export const ExitTableBodyTR = styled.tr``;

//This is for the standard cells
export const ExitTableD = styled.td`
  padding: 8px;
  border: 2px solid;
  color: #12abdb;
  max-width: 200px;

  p {
    color: black;
  }
`;

export const CalendarPopupButtonContainer = styled.div``;

//Confirmation modal styling
export const ModalBackground = styled.div`
  position: fixed;
  object-position: 50%;
  z-index: 3;
  padding-top: 100px;
  left: 0;
  top: 100;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0);
`;

export const CalendarModalBackground = styled.div`
  position: fixed;
  z-index: 7;
  padding-top: 100px;
  left: 0;
  top: 0;
  width: 500px;
  height: 500px;
  overflow: auto;
  background-color: rgb(100, 0, 0);
  background-color: rgba(0, 0, 0, 0);
`;

export const ModalWrapper = styled.div`
  width: 70%;
  height: auto;
  left: 15%;
  box-shadow: 0 5px 16px rgba(0, 0, 0, 0.2);
  background: #12abdb;
  position: sticky;
  z-index: 15;
  border-radius: 10px;
`;

export const ModalContent = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  position: sticky;
`;

export const EntryError = styled.div`
  position: absolute;
  top: 55%;
  p {
    color: red;
    font-weight: bold;
  }
`;

export const ConfirmError = styled.div`
  color: red;
  font-weight: bold;
`;

export const CalendarPopupCont = styled.div`
  display: flex;
  align-items: center;
  position: fixed;
  height: 7vh;
  z-index: 10;
  z-index: 900px;
`;

export const CalendarPopupButton = styled.button`
  width: 110px;
  height: 10px;
  padding: 16px 32px;
  border-radius: 4px;
  border: none;
  background: white;
  color: #1895d9;
  font-size: 13px;
  margin-top: -30px;
  cursor: pointer;
  z-index: 900px;
`;

export const TableContainer = styled.div``;

export const PaginationContainer = styled.div`
  position: relative;
  bottom: 15px;
`;

export const Dates = styled.div`
  position: relative;
  box-sizing: content-box;
  min-width: 500px;
  width: 100%;
  left: 20px;
`;
