import React from "react";
import ListProfiles from "..";
import { render, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import { BrowserRouter as Router } from "react-router-dom";

let component;

beforeEach(() => {
  component = render(
    <Router>
      <ListProfiles />
    </Router>
  );
});

test("Testing that the page renders", () => {
  render(
    <Router>
      <ListProfiles />
    </Router>
  );
});

test("Testing that profile header renders", () => {
  const headerElement = component.getByTestId("header");

  expect(headerElement.textContent).toBe("Profiles");
});

test("Test profile button renders", () => {
  const profileButton = component.getByTestId("profileButton");

  expect(profileButton.toBeInTheDocument);
});

test("Testing the search bar will be empty with placeholder and search icon in corner", () => {
  const searchBarElement = component.getByTestId("searchBar");

  expect(searchBarElement.textContent).toBe("");
  expect(searchBarElement.getAttribute("placeholder")).toBe("Search Employees");
  expect(searchBarElement).toHaveStyle(
    "background: transparent url(SearchIcon.svg) no-repeat 455px center"
  );
});

test("Testing the searchbar will store the text", () => {
  const searchBar = component.getByTestId("searchBar");

  fireEvent.change(searchBar, {
    target: {
      value: "Test",
    },
  });

  expect(searchBar.value).toBe("Test");
});

test("Testing that the table is created with the header titles", () => {
  const tableElement = component.getByTestId("tableElement");
  const tableHead = component.getByTestId("tableHead");

  expect(tableElement).toBeInTheDocument();
  expect(tableHead.textContent).toBe(
    "Employee NameDesignationEmailCommentsActions"
  );
});
