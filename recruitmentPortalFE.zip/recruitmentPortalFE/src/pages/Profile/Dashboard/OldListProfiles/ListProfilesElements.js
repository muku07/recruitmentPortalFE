import { hover } from "@testing-library/user-event/dist/hover";
import { MdClose } from "react-icons/md";
import SearchIcon from "../../../../assets/SearchIcon.svg";
import styled from "styled-components";

export const ListProfilesPage = styled.div`
  height: 300vh;
  overflow: hidden;
  max-width: 100%;
  width: auto;
  background: #fff;
  display: flex;
  justify-content: center;
  // centers in the flex direction and the default flex-direction is row
  align-content: center;
  // centers perpendicular to the flex direction
`;

//This holds and positions the header
export const MainTitleContainer = styled.div`
  position: absolute;
  top: 5%;
  padding: 10px;
  height: 10vh;
  width: auto;
`;

//The header to style the text – font-family already stated in acc.css
export const MainTitle = styled.h1`
  text-align: center;
  color: #0070ad;
  font-size: 50px;
  font-weight: 600;
  padding: 50px 0px 50px 0px;
`;

export const SideButtonDiv = styled.div`
  position: absolute;
  left: 70%;
  top: 30%;
  height: 50vh;
  width: auto;
  overflow: hidden;
`;

export const SearchFormContainer = styled.div`
  position: absolute;
  left: 18%;
  top: 30%;
  height: 50vh;
  width: auto;
  overflow: hidden;
`;

//If you was to have a search container this goes inside the form container - styling of the input
export const SearchInput = styled.input`
  width: 500px;
  border: 1.5px solid #0070ad;
  border-radius: 5px;
  display: block;
  padding: 9px 4px 9px 9px;
  font-size: 14px;
  color: #272936;
  background: transparent url(${SearchIcon}) no-repeat 455px center;
  ::placeholder {
    color: #bbb;
  }
  &:focus {
    box-shadow: 0 0 3px 0 #12abdb;
    border-color: #12abdb;
    outline: none;
  }
`;

export const ActionButton = styled.button`
  padding: 10px 15px 10px 15px;
  border-radius: 4px;
  border: none;
  background: #003857;
  color: white;
  font-size: 18px;
  text-align: center;
  margin-left: 5px;
  margin-right: 5px;
  margin-top: 5px;
  margin-right: 5px;
  cursor: pointer;
`;

export const ProfileButton = styled.button`
  padding: 10px 15px 10px 15px;
  margin-left: 100%;
  border-radius: 4px;
  border: none;
  background: #003857;
  color: white;
  font-size: 18px;
  /* text-align: center; */
  margin-left: 5px;
  margin-right: 5px;
  margin-top: 5px;
  margin-right: 5px;
  cursor: pointer;
`;

export const MainContentContainer = styled.div`
  display: flex;
  flex-direction: column;
  position: absolute;
  left: 9%;
  right: 9%;
  top: 43%;
  //Needs to change accordingly
  height: 100px;
  min-width: 300px;
  min-height: 400px;
`;

export const ReportsToInput = styled.select`
  border: none;
  height: 35px;
  font-size: 16px;

  option {
    color: black;
    background: white;
    display: flex;
    white-space: pre;
  }
`;

export const AssignRoleInput = styled(ReportsToInput)``;

// export const ActionButton = styled(ActivateAll)`
//   margin-left: 5px;
//   margin-right: 5px;
// `;

export const ContentTable = styled.table`
  width: 100%;
`;

//For the whole table
export const STable = styled.table`
  width: 100%;
  border-collapse: collapse;
  text-align: center;
  border-radius: 2px;
`;

//For the table head
export const STHead = styled.thead`
  position: sticky;
  z-index: 3;
`;

//Table head row
export const STHeadTR = styled.tr`
  /* background: #0070ad; */
`;

//Header for a cell
export const STH = styled.th`
  padding: 8px;
  border: 2px solid;

  font-weight: 600;
  font-size: 18px;
  color: #12abdb;

  p {
    color: black;
  }
`;

export const PaginationContainer = styled.div`
  position: relative;
  bottom: 15px;
`;

//The body of the table
export const STBody = styled.tbody``;

//Table body table rows
export const STBodyTR = styled.tr``;

//This is for the standard cells
export const STD = styled.td`
  padding: 8px;
  /* border-inline: 2px clear; */
  border-top: 2px solid;
  border-bottom: 2px solid;
  color: #12abdb;

  p {
    color: black;
  }
`;
