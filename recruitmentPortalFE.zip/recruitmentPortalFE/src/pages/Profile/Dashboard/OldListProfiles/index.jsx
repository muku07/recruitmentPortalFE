import React, { useState, useRef, useEffect, useCallback } from 'react';
import Pagination from '../../../../components/Pagination';
import axios from 'axios';
// import { SectionList, FlatList, StyleSheet, Text, View } from "react-native";
import {
  ActivateAll,
  ListProfilesPage,
  MainContentContainer,
  MainTitle,
  MainTitleContainer,
  SearchFormContainer,
  SearchInput,
  STable,
  STBody,
  STBodyTR,
  STD,
  STH,
  STHead,
  STHeadTR,
  ActionButton,
  ReportsToInput,
  AssignRoleInput,
  ProfileButton,
  SideButtonDiv,
  PaginationContainer,
  //   EngineersHeading,
  //   ListProfilesPage,
  //   ProfileButtonNext,
  //   ProfileCont,
  //   ProfileItem,
  //   ProfileButtonPrev,
  //   ProfileScrollCont,
  //   ProfileName,
  //   TitleName,
  //   ProfileDisplayItem,
} from './ListProfilesElements';
import { BsArrowLeftCircle, BsArrowRightCircle } from 'react-icons/bs';
import AvatarElement from '../../../../components/Avatar';
import { calculateNewValue } from '@testing-library/user-event/dist/utils';
import { useNavigate } from 'react-router-dom';
// import FilterPopup from "../../../SupervisorDashboard/Popups/FilterPopup";

function OldListProfiles() {
  const navigate = useNavigate();

  const [searchQuery, setSearchQuery] = useState('');

  //*****Pagination*****\\
  const [posts, setPosts] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [postsPerPage, setPostsPerPage] = useState(10);

  useEffect(() => {
    const fetchPosts = async () => {
      const res = await axios.post(
        'https://capg-mapii-portal-uks-mapiipowerbackendapp.azurewebsites.net/searchProfiles',
        { activateFlag: true }
      );
      setPosts(res.data);
    };

    fetchPosts();
  }, []);

  console.log(posts);
  // console.log(posts[0].skills);
  //Get current posts
  const indexOfLastPost = currentPage * postsPerPage;
  const indexOfFirstPost = indexOfLastPost - postsPerPage;
  const currentPosts = posts.slice(indexOfFirstPost, indexOfLastPost);

  //Change page
  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  function ViewProfile(id) {
    navigate('/view-profile', { state: { id: id } });
  }

  function EditProfile(emp) {
    navigate('/edit-user-profile', {
      state: { id: emp.userId },
    });
  }

  function manageProfile() {
    navigate('/supervisor/manage');
  }

  function myProfile() {
    navigate('/view-profile', { state: { id: storedId } });
  }

  const [isAdmin, setIsAdmin] = useState(false);
  const [storedId, setStoredId] = useState(0);
  useEffect(() => {
    let auth = sessionStorage.getItem('role');
    let azureId = sessionStorage.getItem('id');

    setStoredId(parseInt(azureId));
    // console.log(storedUsername);

    if (auth === 'ROLE_ADMIN') {
      setIsAdmin(true);
    }
  }, []);

  return (
    <>
      <ListProfilesPage>
        <MainTitleContainer>
          <MainTitle data-testid="header">Profiles</MainTitle>
        </MainTitleContainer>
        <SideButtonDiv>
          <ProfileButton
            data-testid="profileButton"
            onClick={() => myProfile()}
          >
            My Profile
          </ProfileButton>

          {isAdmin && (
            <ProfileButton onClick={() => manageProfile()}>
              Manage Profiles
            </ProfileButton>
          )}
        </SideButtonDiv>
        <SearchFormContainer>
          <SearchInput
            data-testid="searchBar"
            type="search"
            placeholder="Search Employees"
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </SearchFormContainer>

        <MainContentContainer>
          <STable data-testid="tableElement">
            <STHead data-testid="tableHead">
              <STHeadTR>
                <STH>
                  <p>Employee Name</p>
                </STH>
                <STH>
                  <p>Designation</p>
                </STH>
                <STH>
                  <p>Email</p>
                </STH>
                <STH>
                  <p>Skills</p>
                </STH>
                <STH>
                  <p>Actions</p>
                </STH>
              </STHeadTR>
            </STHead>
            {/* <Posts posts={currentPosts} loadling={loading} /> */}
            <STBody>
              {currentPosts
                ?.filter((post) => {
                  if (searchQuery === '') {
                    // console.log(post);
                    return post;
                  } else if (
                    post.firstName
                      .toLowerCase()
                      .includes(searchQuery.toLowerCase()) ||
                    post.lastName
                      .toLowerCase()
                      .includes(searchQuery.toLowerCase())
                    // ||
                    // post.skills
                    //   .toLowerCase()
                    //   .includes(searchQuery.toLowerCase())
                  ) {
                    // console.log(post);
                    return post;
                  }
                  return null;
                })

                .map((emp) => (
                  <STBodyTR key={emp.userId}>
                    <STD>
                      <p>{emp.firstName + ' ' + emp.lastName}</p>
                    </STD>
                    <STD>
                      <p>{emp.designationName}</p>
                    </STD>
                    <STD>
                      <p>{emp.emailId}</p>
                    </STD>
                    <STD>
                      <p>{emp.skills}</p>
                    </STD>
                    <STD>
                      <ActionButton onClick={() => ViewProfile(emp.userId)}>
                        View
                      </ActionButton>
                      {(isAdmin || storedId === emp.userId) && (
                        <ActionButton onClick={() => EditProfile(emp)}>
                          Edit
                        </ActionButton>
                      )}
                    </STD>
                  </STBodyTR>
                ))}
            </STBody>
          </STable>
          <PaginationContainer>
            <Pagination
              postsPerPage={postsPerPage}
              totalPosts={posts.length}
              paginate={paginate}
            />
          </PaginationContainer>
        </MainContentContainer>
      </ListProfilesPage>
    </>
  );
}

export default OldListProfiles;
