import styled from "styled-components";

export const RegisterUserDiv = styled.div`
  overflow: hidden;
  margin: auto;
`;

export const MainTitleContainer = styled.div`
  padding: 10px;
`;

export const MainTitle = styled.h1`
  text-align: center;
  color: #0070ad;
  font-size: 45px;
  font-weight: 600;
  padding: 30px 0px;
`;

export const FormDiv = styled.div`
  display: grid;
  align-items: center;
  justify-content: center;
  height: auto;

  margin-bottom: 20px;
`;

export const ModalForm = styled.form`
  background: #fff;
  width: 50vw;
  padding: 50px 75px 50px 75px;
  border: #12abdb;
  border-radius: 10px;
  padding-bottom: 50px;
  box-shadow: 0 5px 16px rgba(0, 0, 0, 0.2);
`;

export const RegisterUserForm = styled.div`
  position: relative;
  height: 20px;
  width: 50%;
  margin: 0 10px 50px 10px;
`;

export const RegisterUserLabel = styled.label`
  display: flex;
  position: absolute;
  left: 10px;
  top: 10px;
  color: #7f7f7f;
  font-size: 14px;
  padding-left: 5px;
  cursor: text;
  transition: top 200ms ease-in, left 200ms ease-in, font-size 200ms ease-in;
  background-color: white;
  &:hover {
    border-color: #12abdb;
  }
`;

export const RegisterUserInput = styled.input`
  position: absolute;
  width: 100%;
  height: 100%;
  border: 1.5px solid #0070ad;
  border-radius: 5px;
  font-family: inherit;
  font-size: 14px;
  color: #272936;
  padding: 17px;
  background: none;
  ::-webkit-inner-spin-button,
  ::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }
  &:hover {
    border-color: #12abdb;
  }
  &:focus {
    box-shadow: 0 0 1px 0 #12abdb;
    border-color: #12abdb;
    outline: none;
  }

  &:focus
    ~ ${RegisterUserLabel},
    :not(:placeholder-shown):not(:focus)
    ~ ${RegisterUserLabel} {
    top: -6px;
    font-size: 10px;
    left: 7px;
    color: black;
  }
`;

export const RegisterUserSpan = styled.span`
  width: 90%;
  border: 1.5px solid white;
  border-radius: 5px;
  display: block;
  padding: 9px 4px 100px 9px;
  margin: 10px 0px 20px 0px;
  font-size: 14px;
  color: #272936;
  background-color: white;
  ::placeholder {
    color: #bbb;
  }
  &:focus {
    box-shadow: 0 0 3px 0 #0070ad;
    border-color: #0070ad;
    outline: none;
  }
`;

export const ModalSubmitButton = styled.button`
  margin-top: 30px;
  padding: 10px 15px;
  background: #ececec;
  border-radius: 4px;
  color: #003857;
  font-size: 14px;
  font-family: inherit;
  outline: none;
  border: none;
  cursor: pointer;
  &:hover {
    background-color: #12abdb;
    transform: scale(1.1);
  }
`;

export const FormRow = styled.div`
  display: flex;
  margin: 0 -10px;
`;

export const SubmitWrapper = styled.div`
  display: flex;
  text-align: center;
  justify-content: center;
`;

export const DropDownSelect = styled.select`
  width: 100%;
  border: 1.5px solid #0070ad;
  border-radius: 5px;
  font-family: inherit;
  font-size: 14px;
  color: #7f7f7f;
  padding: 9px;

  /* background: none;
  margin: 0 10px 30px 10px; */

  option {
    background: white;
    display: flex;
    white-space: pre;
    color: #272936;
  }

  &:hover {
    border-color: #12abdb;
  }
  &:focus {
    box-shadow: 0 0 1px 0 #12abdb;
    border-color: #12abdb;
    outline: none;
  }
`;

export const DropDownLabelText = styled.label`
  display: flex;
  position: absolute;
  left: 10px;
  top: 10px;
  color: #7f7f7f;
  font-size: 14px;
  padding-left: 5px;
  cursor: text;
  transition: top 200ms ease-in, left 200ms ease-in, font-size 200ms ease-in;
  background-color: white;
  top: -6px;
  font-size: 10px;
  left: 7px;
  color: black;
`;

export const ProfileWrapper = styled.div`
  position: relative;
  width: 100%;
  margin: 0 10px 20px 10px;
`;

export const SummaryBox = styled.textarea`
  width: 100%;
  height: 120px;
  max-height: 200px;
  padding: 10px 12px;
  border-radius: 5px;
  border: 1.5px solid #0070ad;
  font-family: inherit;
  font-size: 14px;
  color: #272936;
  outline: none;
  resize: none;
  &:hover {
    border-color: #12abdb;
  }
  &:focus {
    box-shadow: 0 0 1px 0 #12abdb;
    border-color: #12abdb;
    outline: none;
  }
  &:focus
    ~ ${RegisterUserLabel},
    :not(:placeholder-shown):not(:focus)
    ~ ${RegisterUserLabel} {
    top: -6px;
    font-size: 10px;
    left: 7px;
    color: black;
  }
`;
