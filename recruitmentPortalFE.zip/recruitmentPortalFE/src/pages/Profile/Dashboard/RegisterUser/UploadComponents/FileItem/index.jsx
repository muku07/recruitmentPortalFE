import {
    IconWrapper,
    FileName,
    FileIcon,
    FileSpinner,
    FileTrash,
    ActionsDiv,
} from './FileItemElement';


export default function FileItem({file, deleteFile}) {

return (
    
    <IconWrapper key={file.name}>

        <FileIcon />
        <FileName>{file.name}</FileName>

        <ActionsDiv>

            {!file.isUploading && 
                <FileSpinner /> }
        
            {file.isUploading && 
                <FileTrash onClick={() => deleteFile(file.name)} /> }

        </ActionsDiv>       

    </IconWrapper>

);


 }