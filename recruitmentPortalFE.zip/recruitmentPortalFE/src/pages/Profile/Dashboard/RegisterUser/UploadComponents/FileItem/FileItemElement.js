import styled from "styled-components";
import {MdInsertDriveFile} from "react-icons/md";
import {FaSpinner, FaTrash} from "react-icons/fa";

export const IconWrapper = styled.li`
    list-style: none;
    margin: 10px 0px 10px 0px;
    background-color: rgba(18, 171, 219, 0.5);
    border-radius: 5px;
    display: flex;
    align-items: center;
    padding: 10px 20px 10px 20px ;
`;

export const FileName = styled.p`
    font-size: 12px;
    font-family: inherit;
    flex: 1;
    text-align: left;
`;

export const FileIcon = styled(MdInsertDriveFile)`
    color: #ececec;
    &:first-child{
        font-size: 20px;
        margin-right: 10px;
    }
`;

export const FileSpinner = styled(FaSpinner)`
    font-size: 15px;
    color: #ececec;
    animation: spin-animation 1s infinite;
    @keyframes spin-animation {
        0% {
            transform: rotate(0deg);
        }
        100% {
            transform: rotate(359deg);
        }
    }
`;

export const FileTrash = styled(FaTrash)`
    color: #ececec;
    font-size: 17px;
`;

export const ActionsDiv = styled.div`
    justify-self: flex-end;
    cursor: pointer;
`;