import image from "../../../../assets/bro.svg";
import {
  Box,
  Button,
  Card,
  FormControl,
  Grid,
  IconButton,
  InputBase,
  InputLabel,
  MenuItem,
  Paper,
  Select,
  Tabs,
  Tab,
} from "@mui/material";
import { KeyboardArrowDown, Search } from "@mui/icons-material";
import { Component } from "react";
import TabContext from "@mui/lab/TabContext";
import {
  StyledTab,
  StyledTabList,
  ViewTabPanel,
} from "../ProfileDashboardElements";
import React from "react";

const TabViewStatus = {
  DETAILS: "Details",
  CONTACT: "Contact",
};

export default class RegisterUser extends Component {
  constructor(props) {
    super(props);
    this.state = {
      searchText: "",
      selectedRole: "",
      selectedProfileInformationType: TabViewStatus.DETAILS,
      profile: {
        name: "Argyle Cooper",

        position: "Software Engineer",

        details: {
          grade: "A",

          capabilityUnit: "Capability Unit",

          cgid: "123456789",

          reportsTo: "Max Petts",

          location: "London",
        },

        roles: [
          "Software Engineer",

          "Associate consultant",

          "Consultant",

          "Senior Consultant",

          "Manager",
        ],
      },
      // profile: undefined,
    };
  }

  handleSearchChange = (value) => {
    this.setState({ searchText: value });
  };

  handleRoleChange = (role) => {
    this.setState({ selectedRole: role });
  };

  handleProfileInformationType = (profileInformationType) => {
    this.setState({ selectedProfileInformationType: profileInformationType });
  };

  handleSubmit = () => {};

  /*Shannon to do: make api to active directory with my value - search bar get endpoint will go here */
  render() {
    return (
      <RegisterUserView
        searchText={this.state.searchText}
        profile={this.state.profile}
        onSearchChange={this.handleSearchChange}
        onRoleChange={this.handleRoleChange}
        onhandleProfileInformationTypeChange={this.handleProfileInformationType}
        selectedProfileInformationType={
          this.state.selectedProfileInformationType
        }
      />
    );
  }
}

function ProfileView(props) {
  return (
    <Card variant="outlined" sx={{ elevation: 3, textAlign: "center" }}>
      <Grid item xs={12} md={8} lg={6} sx={{ margin: "auto", padding: 3 }}>
        <img
          style={{
            width: "100%",
            background: "var(--bg-secondary)",
            margin: "auto",
            overflow: "hidden",
            display: "block",
            width: "10rem",
            aspectRatio: "1/1",
            borderRadius: 100,
            border: "2px black",
          }}
          src={props.profile.profilePicture}
          alt={" "}
        ></img>
        <strong> {props.profile.name}</strong>
        <p style={{ color: "var(--accent)" }}>{props.profile.position}</p>

        <TabContext value={props.selectedProfileInformationType}>
          <StyledTabList
            onChange={(_, value) =>
              props.onhandleProfileInformationTypeChange(value)
            }
            aria-label="Blog view tabs"
            variant="fullWidth"
          >
            <StyledTab
              sx={{ fontFamily: "Ubuntu", textTransform: "capitalize" }}
              label="Details"
              value={TabViewStatus.DETAILS}
            />
            <StyledTab
              sx={{ fontFamily: "Ubuntu", textTransform: "capitalize" }}
              label="Contact"
              value={TabViewStatus.CONTACT}
            />
          </StyledTabList>

          <ViewTabPanel value={TabViewStatus.DETAILS} sx={{ margin: "1rem 0" }}>
            <Grid sx={{ margin: "1rem 0" }}>
              <FormControl variant="standard" fullWidth>
                <InputLabel
                  sx={{ fontFamily: "Ubuntu", paddingLeft: "1rem" }}
                  id="role-select-label"
                >
                  Role
                </InputLabel>
                <Select
                  labelId="role-select-label"
                  id="role-select"
                  value={props.selectedRole}
                  onChange={(value) => props.onRoleChange(value)}
                  sx={{
                    elevation: 3,
                    fontFamily: "Ubuntu",
                    border: "1px solid lightgrey",
                    borderRadius: "3px",
                  }}
                  IconComponent={() => <KeyboardArrowDown color="primary" />}
                >
                  {props.profile.roles.map((roles) => (
                    <MenuItem sx={{ fontFamily: "Ubuntu" }}>{roles}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid container item sx={{ textAlign: "left" }} xs={12}>
              <Grid xs={6} md={5}>
                <strong>Grade:</strong>
              </Grid>
              <Grid xs={6} md={7}>
                <p style={{ color: "var(--accent)" }}>
                  {props.profile.details.grade}
                </p>
              </Grid>

              <Grid container item xs={6} md={5}>
                <strong>Capability Unit:</strong>
              </Grid>
              <Grid xs={6} md={7}>
                <p style={{ color: "var(--accent)" }}>
                  {props.profile.details.capabilityUnit}
                </p>
              </Grid>

              <Grid container item xs={6} md={5}>
                <strong>CGID:</strong>
              </Grid>
              <Grid xs={6} md={7}>
                <p style={{ color: "var(--accent)" }}>
                  {props.profile.details.cgid}
                </p>
              </Grid>

              <Grid container item xs={6} md={5}>
                <strong>Reports To:</strong>
              </Grid>
              <Grid xs={6} md={7}>
                <p style={{ color: "var(--accent)" }}>
                  {props.profile.details.reportsTo}
                </p>
              </Grid>

              <Grid container item xs={6} md={5}>
                <strong>Location:</strong>
              </Grid>
              <Grid xs={6} md={7}>
                <p style={{ color: "var(--accent)" }}>
                  {props.profile.details.location}
                </p>
              </Grid>
            </Grid>
          </ViewTabPanel>
          <ViewTabPanel value={TabViewStatus.CONTACT}>
            <p>contact</p>
          </ViewTabPanel>
        </TabContext>
      </Grid>
    </Card>
  );
}

function RegisterUserView(props) {
  return (
    <Grid id={"test"} container rowSpacing={4} direction="column">
      {props.profile !== undefined && (
        <Grid item sx={{ marginLeft: "auto" }}>
          <Button
            sx={{
              color: "var(--accent)",
              textTransform: "capitalize",
              fontFamily: "Ubuntu",
              padding: "0.3rem 2.5rem",
            }}
          >
            Cancel
          </Button>
          <Button
            variant="contained"
            size="medium"
            sx={{
              backgroundColor: "var(--accent)",
              textTransform: "capitalize",
              fontFamily: "Ubuntu",
              padding: "0.3rem 2.5rem",
            }}
            disableElevation
          >
            Register
          </Button>
        </Grid>
      )}
      <Grid item xs={12}>
        <SearchBar value={props.searchText} onChange={props.onSearchChange} />
      </Grid>
      <Grid item xs={12}>
        {props.profile ? <ProfileView {...props} /> : <SearchCard />}
      </Grid>
    </Grid>
  );
}

function SearchCard() {
  return (
    <Card
      variant="outlined"
      sx={{ elevation: 3, textAlign: "center", padding: "2% 5% 2% 5%" }}
    >
      <img src={image} style={{ padding: "2% 10% 2% 10%" }}></img>
      <p>Search for users to register a new profile for them</p>
    </Card>
  );
}

function SearchBar(props) {
  return (
    <Paper
      component="form"
      sx={{
        p: "2px 4px",
        display: "flex",
        alignItems: "center",
        width: "100%",
        elevation: 3,
      }}
    >
      <InputBase
        onChange={(e) => props.onChange(e.target.value)}
        sx={{ ml: 1, flex: 1, fontFamily: "Ubuntu" }}
        placeholder="Search user by name / e-mail"
        value={props.value}
      />
      <IconButton
        type="button"
        sx={{ p: "10px", color: "var(--accent)" }}
        aria-label="search"
      >
        <Search />
      </IconButton>
    </Paper>
  );
}
