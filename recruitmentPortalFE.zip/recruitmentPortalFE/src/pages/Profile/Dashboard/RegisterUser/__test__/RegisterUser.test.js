import React from "react";
import RegisterUser from "../../RegisterUser/index";
import render from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";

beforeEach(() => {
    const component = render(<RegisterUser />);
})

test("header renders with correct text", () => {
    // const component = render(<RegisterUser />);
    const headerEl = component.getByTestId("header");

    expect(headerEl.textContent).toBe("Add New Employee");
})