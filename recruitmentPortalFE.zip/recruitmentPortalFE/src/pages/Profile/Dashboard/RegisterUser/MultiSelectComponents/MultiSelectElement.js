import styled from 'styled-components';

export const MultiSelectOptions = styled.ul`
    display: none;
    position: absolute;
    box-sizing: border-box;
    left: 0;
    width: 100%;
    list-style: none;
    padding-left: 0px;
    border: solid 1px #eee;
    border-bottom-left-radius: 5px;
    border-bottom-right-radius: 5px;
    padding: 5px 0px;
    z-index: 10;
    background-color: white;
    font-family: inherit;
    font-size: 12px;
`;

export const MultiSelectDiv = styled.div`
    font-family: inherit;
    position: relative;
    width: 50%;
    height: 20px;
    margin: 0 10px 50px 10px;

    &:hover ${MultiSelectOptions}{
            display: block;
        }
`;

export const HeaderDiv = styled.div`
    font-family: inherit;
    font-size: 14px;
    color: #7f7f7f;
`;

export const SelectedDiv = styled.div`

    display: flex;
    justify-content: space-between;
    align-items: center;
    width: 100%;
    height: 100%;
    border: 1.5px solid #0070ad;
    border-radius: 5px;
    padding: 17px;
    background: none;
    &:hover{
        border-color: #12abdb;
    }
`;



export const MultiSelectList = styled.li`
    display: flex;
    align-items: center;
    padding: 6px 10px;
    cursor: pointer;

    &:hover{
        background-color: #eee;
    }
    
    &-checkbox{
        margin-right: 6px;
    }
`;

export const MultiSelectCheckbox = styled.input`


`;

export const MultiSelectSpan = styled.span`

`;


///////////////////////////////



export const RegisterUserLabel = styled.label`
    display: flex;
    position: absolute;
    left: 10px;
    top: 10px;
    color: #7f7f7f;
    font-size: 14px;
    padding-left: 5px;
    cursor: text;
    transition: 
        top 200ms ease-in,
        left 200ms ease-in,
        font-size 200ms ease-in;
    background-color: white;
    &:hover{
        border-color: #12abdb;
    }
`;


export const RegisterUserInput = styled.input`
    position: absolute;
    width: 100%;
    height: 100%;
    border: 1.5px solid #0070ad;
    border-radius: 5px;
    font-family: inherit;
    font-size: 14px;
    color: #272936;
    padding: 17px;
    background: none;
    &:hover{
        border-color: #12abdb;
    }
    &:focus{
        box-shadow: 0 0 1px 0 #12abdb;
        border-color: #12abdb;
        outline: none;
    }

    &:focus ~ ${RegisterUserLabel}, :not(:placeholder-shown):not(:focus) ~${RegisterUserLabel} {
        top: -6px;
        font-size: 10px;
        left: 7px;
        color: black;
    }
`;
