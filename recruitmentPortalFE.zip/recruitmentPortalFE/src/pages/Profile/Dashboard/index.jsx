import React, { useState } from "react";
import TabContext from "@mui/lab/TabContext";

import {
  ProfileContent,
  StyledTab,
  StyledTabList,
  TitleContainer,
  ViewTabPanel,
} from "./ProfileDashboardElements";

import ListProfiles from "./ListProfiles";
import RegisterUser from "./RegisterUser";
import BulkUpload from "./BulkUpload";

function ProfileDashboard() {
  const TabViewStatus = {
    LIST: "List",
    REGISTER: "Register",
    BULK: "Bulk_Upload",
    LEAVER: "Leaver_Profiles",
  };

  const [view, setView] = useState(TabViewStatus.LIST);

  return (
    <>
      <main>
        <ProfileContent>
          <TitleContainer>
            <span>Employee profiles</span>
          </TitleContainer>
          <TabContext value={view}>
            <StyledTabList
              onChange={(_, value) => setView(value)}
              aria-label="Blog view tabs"
              variant="fullWidth"
              centered
            >
              <StyledTab label="List of Profiles" value={TabViewStatus.LIST} />
              <StyledTab
                label="Register Profiles"
                value={TabViewStatus.REGISTER}
              />
              <StyledTab label="Bulk Upload" value={TabViewStatus.BULK} />
              <StyledTab label="Leaver Profiles" value={TabViewStatus.LEAVER} />
            </StyledTabList>

            <ViewTabPanel value={TabViewStatus.LIST}>
              <ListProfiles />
            </ViewTabPanel>

            <ViewTabPanel value={TabViewStatus.REGISTER}>
              <RegisterUser />
            </ViewTabPanel>

            <ViewTabPanel value={TabViewStatus.BULK}>
              <BulkUpload />
            </ViewTabPanel>

            <ViewTabPanel value={TabViewStatus.LEAVER}>
              Leaver content
            </ViewTabPanel>
          </TabContext>
        </ProfileContent>
      </main>
    </>
  );
}

export default ProfileDashboard;
