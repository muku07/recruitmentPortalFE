import React from "react";
import {
  DropdownWrapper,
  StyledSelect,
  StyledOption,
  StyledLabel,
} from "./GradeIdElement";

export function Dropdown(props) {
  return (
    <DropdownWrapper action={props.action} onChange={props.onChange}>
      <StyledLabel htmlFor="services">{props.formLabel}</StyledLabel>
      <StyledSelect id="services" name="services">
        {props.children}
      </StyledSelect>
    </DropdownWrapper>
  );
}

export function Option(props) {
  return <StyledOption selected={props.selected}>{props.value}</StyledOption>;
}



// import React, { useState } from "react";
// import {
//   DropdownBtn,
//   DropdownMainCont,
//   DropdownItem,
//   DropdownSpan,
//   DropdownContentEmployee,
// } from "./GradeIdElement";

// import { BsCaretDown } from "react-icons/bs";

// function DropdownUnit({ selected, setSelected }) {
//   const [isActive, setIsActive] = useState(false);
//   const options = ["A", "B", "C", "D", "E"];
//   return (
//     <>
//       <DropdownMainCont>

//         <DropdownBtn onClick={(e) => setIsActive(!isActive)}>
//           Select Grade ID
//           <BsCaretDown style={{ marginLeft: "200px", lineHeight: "-100px" } }/>
//           <DropdownSpan></DropdownSpan>
//         </DropdownBtn>

//         {isActive && (
//           <DropdownContentEmployee>
//             {options.map((option) => (
//               <DropdownItem 
//               onClick={(e) => {
//                   setSelected(option);
//                   setIsActive(false);
//               }}>
//                 {option}
//               </DropdownItem>
//             ))}
//           </DropdownContentEmployee>
//         )}
   
//       </DropdownMainCont>

//     </>
//   );
// }
// export default DropdownUnit;



