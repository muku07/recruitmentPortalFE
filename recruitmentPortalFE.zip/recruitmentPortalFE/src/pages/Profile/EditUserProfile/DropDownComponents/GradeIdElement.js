import styled from "styled-components";

export const DropdownWrapper = styled.div`
  /* display: flex;
  flex-flow: column;
  justify-content: flex-start; */
  position: relative;
  height: 20px;
  width: 50%;
  margin: 0 10px 50px 10px;
`;

export const StyledSelect = styled.select`
  /* max-width: 50%;
  height: 100%;
  padding: 0.5rem;
  margin-bottom: 1rem; */
  position: absolute;
  width: 100%;
  height: 100%;
  border: 1.5px solid #0070ad;
  border-radius: 5px;
  font-family: inherit;
  font-size: 14px;
  color: #272936;
  padding: 17px;
  background: none;
  &:hover {
    border-color: #12abdb;
  }
  &:focus {
    box-shadow: 0 0 1px 0 #12abdb;
    border-color: #12abdb;
    outline: none;
  }
`;

export const StyledOption = styled.option`
  color: ${(props) => (props.selected ? "lightgrey" : "black")};
`;

export const StyledLabel = styled.label`
  /* margin-bottom: 1rem; */
  display: flex;
  position: absolute;
  left: 10px;
  top: 10px;
  color: #7f7f7f;
  font-size: 14px;
  padding-left: 5px;
  cursor: text;
  transition: top 200ms ease-in, left 200ms ease-in, font-size 200ms ease-in;
  background-color: white;
  &:hover {
    border-color: #12abdb;
  }
`;
