import { MdAddCircle } from "react-icons/md";
import { useState, useEffect } from "react";
import {
  FileCard,
  FileInput,
  InputFile,
  ImageI,
  FileButton,
  FileTag,
} from "./CVUploadElement";
import axios from "axios";
import FileItem from "./FileItem";
import { useForm, isRequired, isSame } from "./validation";
import { apiProvider } from "../../../../Services/API/Utilities/Provider";

export default function UploadComponent(
  { files, setFiles, removeFile },
  onSignup
) {
  const initialState = { resume: "" };
  const validations = [
    ({ resume }) => isRequired(resume) || { resume: "Resume is required" },
  ];
  const { values, isValid, errors, changeHandler, submitHandler } = useForm(
    initialState,
    validations,
    onSignup
  );

  const uploadHandler = (event) => {
    const file = event.target.files[0];
    file.isUploading = true;
    setFiles([...files, file]);

    //upload file
    const formData = new FormData();
    formData.append(file.name, file, file.name);

    // axios.post('http://localhost:8080/upload', formData)
    // .then((res) => {
    //     file.isUploading = false;
    //     setFiles([...files, file]);
    //     // setTimeout(() => {
    //     //     console.log('file uploaded')
    //     //     return formData.status(200).json({ result: true, msg: 'file uploaded'}, 3000);
    //     // });
    // })
    // .catch((err) => {
    //     //inform user error
    //     console.error(err);
    //     removeFile(file.name);
    // })
  };

  // const handleSubmit = (event) => {
  //     event.preventDefault();
  //     setFormErrors(validate(formValues));
  //     setIsSubmit(true);
  // };

  // useEffect(() => {
  //     console.log(formErrors);
  //     if(Object.keys(formErrors).length === 0 && isSubmit) {
  //         console.log(formValues);
  //     }
  // }, [formErrors]);
  // const validate = (values) => {
  //     const errors = {}

  //     if (values.uploadedFile !== ".doc" || values.uploadedFile !== ".ppt" || values.uploadedFile !== ".pdf"){
  //         errors.uploadedFile = "file type not supported";
  //     }
  //     return errors;
  // };

  const deleteFileHandler = (_name) => {
    axios
      .delete(`http://localhost:8080/upload?name=${_name}`)
      .then((res) => removeFile(_name))
      .catch((err) => console.error(err));
  };

  return (
    <>
      <FileCard>
        <FileInput onSubmit={submitHandler}>
          <InputFile
            id="file-upload"
            type="file"
            name="resume"
            accept=".doc,.docx,application/pdf,.pdf,.ppt,.pptx"
            value={values.resume}
            onChange={uploadHandler}
          />

          <FileButton htmlFor="file-upload" disabled={isValid}>
            <ImageI>
              <MdAddCircle />
            </ImageI>
            Upload CV
          </FileButton>
        </FileInput>

        <FileTag>Supported files:</FileTag>
        <FileTag>PPT, PDF, DOC</FileTag>

        <ul>
          {files &&
            files.map((f) => (
              <FileItem key={f.name} file={f} deleteFile={deleteFileHandler} />
            ))}
        </ul>
      </FileCard>
    </>
  );
}
