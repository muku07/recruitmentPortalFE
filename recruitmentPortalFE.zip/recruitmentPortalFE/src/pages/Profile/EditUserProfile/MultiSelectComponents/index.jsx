import { MdKeyboardArrowDown } from 'react-icons/md'
import {
    MultiSelectDiv,
    SelectedDiv,
    MultiSelectOptions,
    MultiSelectList,
    MultiSelectCheckbox,
    MultiSelectSpan,
    HeaderDiv,
}
from './MultiSelectElement';

export default function MultiSelectDropdown ({ options, selected, toggleOption}) {



    return (

        <MultiSelectDiv>

            <SelectedDiv>
                <HeaderDiv>Skill Set </HeaderDiv>
                <HeaderDiv>{selected.length} selected </HeaderDiv>
                <MdKeyboardArrowDown style={{fontSize: '16px', color: '#7f7f7f'}} />
            </SelectedDiv>

            <MultiSelectOptions>
                {options.map(option => {
                    const isSelected = selected.includes(option.id);

                    return (
                
                        <MultiSelectList onClick={() => toggleOption({ id: option.id })}>
                            <MultiSelectCheckbox type="checkbox" checked={isSelected} ></MultiSelectCheckbox>
                            <MultiSelectSpan>{option.title}</MultiSelectSpan>
                        </MultiSelectList>

                    )

                })}

            </MultiSelectOptions>

        </MultiSelectDiv>

    );

}

{/* <RegisterUserForm>
<RegisterUserInput
    type="number"
    autoComplete="off"
    placeholder=" "
    onChange={(e) => e.target.value}
    id="cgid"
/>
<RegisterUserLabel htmlFor="cgid">CGID</RegisterUserLabel>
</RegisterUserForm> */}