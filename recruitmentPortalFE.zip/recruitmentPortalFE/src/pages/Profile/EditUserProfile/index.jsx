import { useState, useRef, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import {
  MainTitle,
  RegisterUserDiv,
  MainTitleContainer,
  FormDiv,
  ModalForm,
  RegisterUserForm,
  RegisterUserInput,
  RegisterUserLabel,
  FormRow,
  SaveButton,
  SaveButtonText,
  CancelButton,
  CancelButtonText,
  RegisterUserSummaryInput,
  RegisterUserSummaryForm,
  DropDownSelect,
  DropDownLabelText,
} from "./EditUserProfileElements";

import { Dropdown, Option } from "./DropDownComponents";
import UploadComponent from "./UploadComponents";
import MultiSelectDropdown from "./MultiSelectComponents";
import { useLocation } from "react-router-dom";

export default function EditUserProfile() {
  const { state } = useLocation();
  let userId = state.id;

  const [isAdmin, setIsAdmin] = useState(false);
  const [storedId, setStoredId] = useState("");
  useEffect(() => {
    let auth = sessionStorage.getItem("role");
    let azureId = sessionStorage.getItem("id");

    setStoredId(azureId);
    // console.log(storedUsername);
    console.log(auth);

    if (auth === "ROLE_ADMIN") {
      setIsAdmin(true);
    }
  }, []);

  const navigate = useNavigate();

  const [selected, setSelected] = useState([]);
  const [files, setFiles] = useState([{ name: "myFile.pdf" }]);

  const removeFile = (filename) => {
    setFiles(files.filter((file) => file.name !== filename));
  };
  // console.log(files);

  const multiSelectData = [
    { id: 1, title: "Java" },
    { id: 2, title: ".NET" },
    { id: 3, title: "DevOps" },
    { id: 4, title: "Project Management" },
    { id: 5, title: "Azure" },
    { id: 6, title: "Kubernetes" },
  ];

  const toggleOption = ({ id }) => {
    setSelected((prevSelected) => {
      const newArray = [...prevSelected];
      if (newArray.includes(id)) {
        return newArray.filter((item) => item !== id);
      } else {
        newArray.push(id);
        return newArray;
      }
    });
  };

  function goBackToProfile() {
    navigate("/listprofiles");
  }

  // const { id } = useLocation();

  // console.log(userId, username);

  const [employeeData, setEmployeeData] = useState("");
  const [firstNameState, SetFirstNameState] = useState("");
  const [lastNameState, SetLastNameState] = useState("");
  const [CGIDState, SetCGIDState] = useState("");
  const [locationState, SetLocationState] = useState("");
  const [designationState, SetDesignationState] = useState("");
  const [gradeState, SetGradeState] = useState("");
  const [phoneState, SetPhoneState] = useState("");
  const [reportsState, SetReportsState] = useState("");
  const [emailState, SetEmailState] = useState("");
  const [capabilityState, SetCapabilityState] = useState("");
  const [profileSummaryState, SetProfileSummaryState] = useState("");
  const [skillState, SetSkillState] = useState("");
  const [CVState, SetCVState] = useState("");
  const [commentsState, SetCommentsState] = useState("");

  const [RetrievedGrades, SetRetrievedGrades] = useState([]);
  const [RetrievedReportsTo, SetRetrievedReportsTo] = useState([]);
  const [RetrievedCapabilityUnits, SetRetrievedCapabilityUnits] = useState([]);
  const [RetrievedDesignation, SetRetrievedDesignation] = useState([]);

  useEffect(() => {
    function getGrades() {
      const URL = `https://mapii-portal-profile-service.azurewebsites.net/grades`;
      axios
        .get(URL, {
          headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
          },
        })
        .then((res) => {
          console.log(res.data);
          SetRetrievedGrades(res.data);
        });
    }

    function getReportsTo() {
      const URL = `https://mapii-portal-profile-service.azurewebsites.net/reportsto`;
      axios
        .get(URL, {
          headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
          },
        })
        .then((res) => {
          console.log(res.data);
          SetRetrievedReportsTo(res.data);
        });
    }

    function getCapabilityUnits() {
      const URL = `https://mapii-portal-profile-service.azurewebsites.net/capabilityUnits`;
      axios
        .get(URL, {
          headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
          },
        })
        .then((res) => {
          console.log(res.data);
          SetRetrievedCapabilityUnits(res.data);
        });
    }

    function getDesignations() {
      const URL = `https://mapii-portal-profile-service.azurewebsites.net/designations`;
      axios
        .get(URL, {
          headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
          },
        })
        .then((res) => {
          console.log(res.data);
          SetRetrievedDesignation(res.data);
        });
    }

    getGrades();
    getReportsTo();
    getCapabilityUnits();
    getDesignations();
  }, []);

  useEffect(() => {
    function getCurrentProfile() {
      const URL = `https://mapii-portal-profile-service.azurewebsites.net/profile/${userId}`;
      axios
        .get(URL, {
          headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
          },
        })
        .then((res) => {
          console.log(res.data);
          SetFirstNameState(res.data.firstName);
          SetLastNameState(res.data.lastName);
          SetCGIDState(res.data.ggId);
          SetLocationState(res.data.address);
          SetDesignationState(res.data.designationId);
          SetGradeState(res.data.gradeId);
          SetPhoneState(res.data.contactNumber);
          SetReportsState(res.data.reportsTo);
          SetEmailState(res.data.emailId);
          SetCapabilityState(res.data.capabilityUnitId);
          SetProfileSummaryState(res.data.profiles.summary);
          SetSkillState(res.data.profiles.skillSet);
          SetCVState(res.data.profiles.resume);
          // SetCommentsState(res.data.profiles.comments) This field doesn't exist in the database no more?
        });
    }
    getCurrentProfile();
  }, []);

  function updateProfile(e) {
    e.preventDefault();

    // console.log(document.getElementById("firstName").value);

    console.log("Going to check to see if fields are filled in correctly!");
    console.log("Look at the entered fields below!");
    console.log(firstNameState);
    console.log(lastNameState);
    console.log(CGIDState);
    console.log(locationState);
    console.log(designationState);
    console.log(gradeState);
    console.log(phoneState);
    console.log(reportsState);
    console.log(emailState);
    console.log(capabilityState);
    console.log(profileSummaryState);
    console.log(skillState);

    if (
      firstNameState != "" &&
      lastNameState != "" &&
      designationState != ""
      // &&
      // CGIDState != "" &&
      // locationState != "" &&
      // gradeState != "" &&
      // phoneState != "" &&
      // reportsState != "" &&
      // emailState != "" &&
      // capabilityState != "" &&
      // profileSummaryState != "" &&
      // skillState != "" &&
      // CVState != ""
    ) {
      //comments column is no longer in the database?
      console.log("Valid inputs");
      saveData();
    } else {
      console.log("Something went wrong");
      navigate("/error");
    }
  }

  function saveData() {
    const URL = `https://mapii-portal-profile-service.azurewebsites.net/profile/${userId}`;
    console.log("Going to save data!");
    axios
      .put(
        URL,
        {
          firstName: firstNameState,
          lastName: lastNameState,
          // ggid: CGIDState,
          address: locationState,
          designationId: designationState,
          gradeId: gradeState,
          contactNumber: phoneState,
          reportsTo: reportsState,
          // emailId: emailState,
          capabilityUnitId: capabilityState,

          profiles: {
            // profileId: 1,
            summary: profileSummaryState,
            // userId: 1,
            skillSet: skillState,
            resume: CVState,
          },
        },
        {
          headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            Authorization:
              "eyJlbWFpbCI6Imp1d29uLnN1bGVtYW5AY2FwZ2VtaW5pLmNvbSIsImFsZyI6IkhTNTEyIn0.eyJzdWIiOiJqdXdvbi5zdWxlbWFuQGNhcGdlbWluaS5jb20iLCJhdXRob3JpdGllcyI6WyJST0xFX0FETUlOIl0sImV4dCI6eyJnZ0lEIjoiNCIsImVtYWlsIjoianV3b24uc3VsZW1hbkBjYXBnZW1pbmkuY29tIn0sImlhdCI6MTY1NzAzMjcxOSwiZXhwIjoxNjU3MDc1OTE5fQ.ZrSoSiT4uFJGXFDM2OJSmUTvCIoZweEH5SLB8bucOeDN-RbG436xGiIL3AKD-p6tMpMyypc9YmMxGS-I8xcJVA",
          },
        }
      )
      .then((res) => {
        console.log("It worked move to the view profile page");
        navigate("/view-profile", { state: { id: userId } });

        //Give a specific ID of the person just edited
      })
      .catch((err) => {
        console.log(err);
        navigate("/error");
      });
  }

  return (
    <>
      <RegisterUserDiv>
        <MainTitleContainer>
          <MainTitle>Edit Employee</MainTitle>
        </MainTitleContainer>

        <FormDiv>
          <ModalForm
            onSubmit={(e) => {
              updateProfile(e);
            }}
          >
            <FormRow>
              <RegisterUserForm>
                <RegisterUserInput
                  required
                  id="firstName"
                  type="text"
                  autoComplete="off"
                  placeholder="Enter First Name"
                  value={firstNameState}
                  onChange={(event) => {
                    SetFirstNameState(event.target.value);
                  }}
                />
                <RegisterUserLabel>First Name *</RegisterUserLabel>
              </RegisterUserForm>

              <RegisterUserForm>
                <RegisterUserInput
                  required
                  id="lastName"
                  type="text"
                  autoComplete="off"
                  placeholder="Enter Last Name"
                  value={lastNameState}
                  onChange={(event) => {
                    SetLastNameState(event.target.value);
                  }}
                />
                <RegisterUserLabel>Last Name *</RegisterUserLabel>
              </RegisterUserForm>
            </FormRow>

            <FormRow>
              <RegisterUserForm>
                <RegisterUserInput
                  //required
                  id="email"
                  type="text"
                  readOnly={true}
                  autoComplete="off"
                  placeholder="Enter Email"
                  value={emailState}
                  onChange={(event) => {
                    SetEmailState(event.target.value);
                  }}
                />
                <RegisterUserLabel>Email</RegisterUserLabel>
              </RegisterUserForm>

              <RegisterUserForm>
                <RegisterUserInput
                  //required
                  id="phone"
                  type="number"
                  autoComplete="off"
                  placeholder="Enter Phone Number"
                  value={phoneState}
                  onChange={(event) => {
                    SetPhoneState(event.target.value);
                  }}
                />
                <RegisterUserLabel>Phone Number</RegisterUserLabel>
              </RegisterUserForm>
            </FormRow>

            <FormRow>
              <RegisterUserForm>
                <DropDownSelect
                  onChange={(e) => SetGradeState(e.target.value)}
                  value={gradeState}
                  placeholder="Select Grade ID"
                >
                  {/* <option value="0" hidden>
                  "Select Grade ID"
                </option> */}
                  {RetrievedGrades.map((grade, i) => (
                    <option key={i} value={grade.gradeId}>
                      {""}
                      {grade.gradeName}
                    </option>
                  ))}
                </DropDownSelect>
                <DropDownLabelText>Grade</DropDownLabelText>
              </RegisterUserForm>

              <RegisterUserForm>
                <RegisterUserInput
                  //required
                  id="cgid"
                  type="number"
                  readOnly={true}
                  autoComplete="off"
                  placeholder="Enter CGID"
                  value={CGIDState}
                  onChange={(event) => {
                    SetCGIDState(event.target.value);
                  }}
                />
                <RegisterUserLabel>CGID</RegisterUserLabel>
              </RegisterUserForm>
            </FormRow>

            <FormRow>
              <RegisterUserForm>
                <DropDownSelect
                  onChange={(e) => SetDesignationState(e.target.value)}
                  value={designationState}
                  placeholder="Select Your Designation"
                  required={true}
                >
                  {RetrievedDesignation.map((designations, i) => (
                    <option key={i} value={designations.designationId}>
                      {""}
                      {designations.designationName}
                    </option>
                  ))}
                </DropDownSelect>
                <DropDownLabelText>Designation *</DropDownLabelText>
              </RegisterUserForm>

              <RegisterUserForm>
                <DropDownSelect
                  onChange={(e) => SetReportsState(e.target.value)}
                  value={reportsState}
                  placeholder="Select Who You Report To"
                >
                  {RetrievedReportsTo.map((reportsto, i) => (
                    <option key={i} value={reportsto.id}>
                      {""}
                      {reportsto.name}
                    </option>
                  ))}
                </DropDownSelect>
                <DropDownLabelText>Reports To</DropDownLabelText>
              </RegisterUserForm>
            </FormRow>

            <FormRow>
              <RegisterUserForm>
                <DropDownSelect
                  onChange={(e) => SetCapabilityState(e.target.value)}
                  value={capabilityState}
                  placeholder="Select Capability Unit"
                >
                  {/* <option value="0" hidden>
                  "Select Grade ID"
                </option> */}
                  {RetrievedCapabilityUnits.map((capability, i) => (
                    <option key={i} value={capability.capabilityUnitId}>
                      {""}
                      {capability.capabilityUnitName}
                    </option>
                  ))}
                </DropDownSelect>
                <DropDownLabelText>Capability Unit</DropDownLabelText>
              </RegisterUserForm>

              <RegisterUserForm>
                <RegisterUserInput
                  //required
                  id="city"
                  type="text"
                  autoComplete="off"
                  placeholder="Enter Base Location"
                  value={locationState}
                  onChange={(event) => {
                    SetLocationState(event.target.value);
                  }}
                />
                <RegisterUserLabel>Base Location/City</RegisterUserLabel>
              </RegisterUserForm>
            </FormRow>

            {/* <FormRow>
              <MultiSelectDropdown
                options={multiSelectData}
                selected={selected}
                toggleOption={toggleOption}
              />

              <UploadComponent
                files={files}
                setFiles={setFiles}
                removeFile={removeFile}
              />
            </FormRow> */}

            <FormRow>
              <RegisterUserSummaryForm>
                <RegisterUserSummaryInput
                  //required
                  id="skillset"
                  type="text"
                  autoComplete="off"
                  placeholder="Enter Skill Sets"
                  value={skillState}
                  onChange={(event) => {
                    SetSkillState(event.target.value);
                  }}
                />
                <RegisterUserLabel>Skill Set</RegisterUserLabel>
              </RegisterUserSummaryForm>

              <RegisterUserSummaryForm>
                <RegisterUserSummaryInput
                  //required
                  id="profilesummary"
                  type="text"
                  autoComplete="off"
                  placeholder="Enter Profile Summary"
                  value={profileSummaryState}
                  onChange={(event) => {
                    SetProfileSummaryState(event.target.value);
                  }}
                />
                <RegisterUserLabel>ProfileSummary</RegisterUserLabel>
              </RegisterUserSummaryForm>
            </FormRow>

            <SaveButton type="submit">
              <SaveButtonText>Save</SaveButtonText>
            </SaveButton>

            <CancelButton
              onClick={() => {
                goBackToProfile();
              }}
            >
              <CancelButtonText>Cancel</CancelButtonText>
            </CancelButton>
          </ModalForm>
        </FormDiv>
      </RegisterUserDiv>
    </>
  );
}
