import { styled } from "@mui/material/styles";
import Skeleton from "@mui/material/Skeleton";

export const DetailsContainer = styled("div")`
  width: 100%;
  padding: 1.2rem 4rem;
`;

export const DetailElement = styled("div")`
  display: grid;
  grid-template-columns: 0.3fr 1fr;
`;
export const DetailText = styled("h6")`
  margin-bottom: 2rem;

  span {
    color: var(--accent);
  }
`;

export const StyledSkeleton = styled(Skeleton)`
  font-size: 2rem;
`;
