import React from "react";

import {
  DetailElement,
  DetailsContainer,
  DetailText,
  StyledSkeleton,
} from "./ViewProfileDetailsElements";

function ViewProfileDetailsTab({ profileData, reportsApi, viewType, loading }) {
  const convertReport = (empId) => {
    try {
      if (empId === 0) {
        return "Not assigned";
      }
      for (let i = 0, l = reportsApi.data?.length; i < l; i++) {
        if (reportsApi.data[i].id === parseInt(empId)) {
          return reportsApi.data[i].name;
        }
      }
    } catch (error) {
      console.log(error);
      return "Problem occured";
    }
  };

  const loadData = (data) => {
    return(
      <>
    <DetailText>
      {loading ? (
        <StyledSkeleton variant="text" />
      ) : (
        <span>{data}</span>
      )}
    </DetailText>
      </>
    )
  };

  return (
    <>
      <DetailsContainer>
        {viewType === "details" ? (
          <DetailElement>
            <DetailText>Grade:</DetailText>
            {loadData(profileData?.gradeName)}

            <DetailText>capability Unit:</DetailText>
            {loadData(profileData?.capabilityUnitName)}

            <DetailText>CGID:</DetailText>
            {loadData(profileData?.ggId)}

            <DetailText>Reports to:</DetailText>
              {loadData(convertReport(profileData?.reportsTo))}

            <DetailText>Location:</DetailText>
            {loadData(profileData?.address)}
          </DetailElement>

        ) : viewType === "contact" ? (

          <DetailElement>
            <DetailText>Email:</DetailText>
            {loadData(profileData?.emailId)}

            <DetailText>Contact Number:</DetailText>
            {loadData(profileData?.contactNumber)}
          </DetailElement>

        ) : null}
      </DetailsContainer>
    </>
  );
}

export default ViewProfileDetailsTab;
