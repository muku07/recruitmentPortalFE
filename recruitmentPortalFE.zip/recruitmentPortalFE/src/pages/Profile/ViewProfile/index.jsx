import { useState } from "react";
import { useLocation } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import TabContext from "@mui/lab/TabContext";

import {
  BackArrow,
  BackButtonContainer,
  HeaderNameContainer,
  StyledAvatar,
  StyledCard,
  StyledNameHeader,
  StyledPositionHeader,
  StyledTab,
  StyledTabList,
  ViewProfileContent,
  ViewTabPanel,
} from "./ViewProfileElement";

import { GetOneProfileApi } from "../../../Services/API/Utilities/ProfilesAPI";
import { apiProvider } from "../../../Services/API/Utilities/Provider";

import ViewProfileInfoTab from "./ViewProfileInfoTab";
import ViewProfileAboutTab from "./ViewProfileAboutTab";

export default function ViewProfile() {
  const navigate = useNavigate();
  const { state } = useLocation();

  const TabViewStatus = {
    ABOUTME: "AboutMe",
    DETAILS: "details",
    RESUME: "resume",
    CONTACT: "contact",
  };

  // const [profile, setProfile] = useState();
  const [view, setView] = useState(TabViewStatus.DETAILS);

  const profile = GetOneProfileApi(state.id);
  const getReportsToApi = apiProvider.GetAllApi("reportsto");

  console.log(profile.loading);

  return (
    <>
      <main>
        <ViewProfileContent>
          <BackButtonContainer>
            <BackArrow
              fontSize="large"
              onClick={() => {
                navigate("/employee-profiles");
              }}
            />
            <span>Employee Profile</span>
          </BackButtonContainer>

          <StyledCard>
            <HeaderNameContainer>
              <StyledAvatar>
                {profile.profileData?.firstName} {profile.profileData?.lastName}
              </StyledAvatar>
              <StyledNameHeader>
                {profile?.firstName} {profile?.lastName}
              </StyledNameHeader>
              <StyledPositionHeader>
                {profile.profileData?.designationName}
              </StyledPositionHeader>
            </HeaderNameContainer>

            <TabContext value={view}>
              <StyledTabList
                onChange={(_, value) => setView(value)}
                aria-label="profile view tabs"
                variant="fullWidth"
                centered
              >
                <StyledTab label="About Me" value={TabViewStatus.ABOUTME} />
                <StyledTab label="Details" value={TabViewStatus.DETAILS} />
                <StyledTab label="Resume" value={TabViewStatus.RESUME} />
                <StyledTab label="Contact" value={TabViewStatus.CONTACT} />
              </StyledTabList>

              <ViewTabPanel value={TabViewStatus.ABOUTME}>
                <ViewProfileAboutTab
                  profileData={profile.profileData.summary}
                  loading={profile.loading}
                />
              </ViewTabPanel>

              <ViewTabPanel value={TabViewStatus.DETAILS}>
                <ViewProfileInfoTab
                  profileData={profile.profileData}
                  reportsApi={getReportsToApi}
                  viewType={view}
                  loading={profile.loading}
                />
              </ViewTabPanel>

              <ViewTabPanel value={TabViewStatus.CONTACT}>
                <ViewProfileInfoTab
                  profileData={profile.profileData}
                  reportsApi={getReportsToApi}
                  viewType={view}
                  loading={profile.loading}
                />
              </ViewTabPanel>
            </TabContext>
          </StyledCard>
        </ViewProfileContent>
      </main>
    </>
  );
}
