import React from "react";
import ViewProfile from "../index";
import { render, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";

describe("Rendering component and checking all features work and are visible", () => {
  test("The header should render with correct text", () => {
    const component = render(<ViewProfile />);
    const profileBox = component.getByTestId("profile-box");
    const headerEl = component.getByRole("heading", {
      name: /View Profile/i,
    });

    expect(profileBox).toBeVisible;
    expect(profileBox).toHaveStyle("height: 100%", "width: 100%");
    expect(headerEl).toBeVisible;
    expect(headerEl).toHaveTextContent("View Profile");
  });

  test("Testing that the Profile Boxes match the Text aligned to that Box", () => {
    const component = render(<ViewProfile />);

    const firstNameBox = component.getByText("First Name");
    const lastNameBox = component.getByText("Last Name");
    const emailBox = component.getByText("Email");
    const phoneNumberBox = component.getByText("Phone Number");
    const cgidBox = component.getByText("CGID");
    const designationBox = component.getByText("Designation");
    const reportsToBox = component.getByText("Reports To");
    const capabilityUnitsBox = component.getByText("Capability Unit");
    const locationBox = component.getByText("Base Location/City");
    const skillSetBox = component.getByText("Skill Set");
    const resumeBox = component.getByText("Resume");
    const profileSummaryBox = component.getByText("Profile Summary");

    expect(firstNameBox).toHaveTextContent("First Name");
    expect(lastNameBox).toHaveTextContent("Last Name");
    expect(emailBox).toHaveTextContent("Email");
    expect(phoneNumberBox).toHaveTextContent("Phone Number");
    expect(cgidBox).toHaveTextContent("CGID");
    expect(designationBox).toHaveTextContent("Designation");
    expect(reportsToBox).toHaveTextContent("Reports To");
    expect(capabilityUnitsBox).toHaveTextContent("Capability Unit");
    expect(locationBox).toHaveTextContent("Base Location/City");
    expect(skillSetBox).toHaveTextContent("Skill Set");
    expect(resumeBox).toHaveTextContent("Resume");
    expect(profileSummaryBox).toHaveTextContent("Profile Summary");
  });
  test("Testing that the profile boxes have values inside it", () => {
    const component = render(<ViewProfile />);

    const profileBoxContent = component.getByTestId("profile-value-box");
    const cvUploadContent = component.getByDisplayValue(Blob);
    expect(profileBoxContent.textContent).toBe("Test");
    expect(cvUploadContent.DOCUMENT_TYPE_NODE);
  });
});
