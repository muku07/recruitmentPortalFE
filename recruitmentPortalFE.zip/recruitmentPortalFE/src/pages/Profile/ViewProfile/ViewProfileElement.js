import { styled } from "@mui/material/styles";
import ExpandCircleDownIcon from "@mui/icons-material/ExpandCircleDown";
import { Card } from "@mui/material";
import Avatar from "@mui/material/Avatar";
import TabList from "@mui/lab/TabList";
import Tab from "@mui/material/Tab";
import TabPanel from "@mui/lab/TabPanel";

export const ViewProfileContent = styled("div")`
  padding: 1.5rem 0rem;
  height: auto;
  width: 870px;
  margin: auto;
`;

export const BackButtonContainer = styled("div")`
  padding: 1rem 0rem;
  display: flex;
  align-items: center;
  gap: 8px;

  span {
    text-align: center;
    font-weight: 500;
    font-size: 1.5rem;
  }
`;

export const BackArrow = styled(ExpandCircleDownIcon)`
  color: var(--accent);
  transform: rotate(90deg);
  cursor: pointer;
`;

export const StyledCard = styled(Card)`
  margin: auto;
  width: 54rem;
  margin-bottom: 40px;
`;

export const StyledNameHeader = styled("h2")``;

export const StyledPositionHeader = styled("h6")`
  color: var(--accent);
`;

export const HeaderNameContainer = styled("div")`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;

  text-align: center;

  margin-bottom: 1rem;
`;

export const StyledAvatar = styled(Avatar)`
  width: 90px;
  height: 90px;
  margin: 30px 0px;
`;

export const StyledTabList = styled(TabList)`
  min-height: 2rem;
  margin: 0.3rem 0;
`;

export const StyledTab = styled(Tab)`
  max-height: 2rem;
  &.Mui-selected {
    font-weight: 700;
  }
  & {
    max-height: 2rem;
    min-height: 2rem;
  }
`;

export const ViewTabPanel = styled(TabPanel)`
  padding: 0;

  margin-bottom: 1rem;
`;

// import styled from "styled-components";
// import { Button } from "react-bootstrap";
// export const RegisterUserDiv = styled.div`
//   height: 1400px;
//   overflow: hidden;
//   display: flex;
//   justify-content: center;
//   align-content: center;
// `;

// export const MainTitleContainer = styled.div`
//   position: absolute;
//   top: -4.5%;
//   left: 10%;
//   height: 50vh;
//   width: auto;
// `;

// export const MainTitle = styled.h1`
//   text-align: center;
//   color: #0070ad;
//   font-size: 45px;
//   font-weight: 600;
//   padding: 50px 0px 50px 0px;
// `;

// export const FormDiv = styled.div`
//   display: grid;
//   align-items: center;
//   justify-content: center;
//   height: auto;
// `;

// export const ModalForm = styled.form`
//     width: 70vw;
//     margin-top: -300px;
//     margin-left: -300px;
//     padding: 50px 75px 50px 75px;
//     border: #12abdb;
//     border-radius: 10px;
//     padding-bottom: 50px;
//     box-shadow: 0 5px 16px rgba(0, 0, 0, 0.2);
// `;

// export const RegisterUserForm = styled.div`
//     position: relative;
//     height: 20px;
//     width: 50%;
//     top: 12%;
//     margin: 0 17px 50px 10px;
// `;

// export const RegisterUserFormEmail = styled.div`
//     position: relative;
//     height: 20px;
//     width: 70%;
//     top: 12%;
//     margin: 0 17px 50px 10px;
// `;

// export const RegisterUserFormSummary = styled.div`
//     position: relative;
//     height: 100px;
//     width: 100%;
//     top: 12%;
//     margin: 0 17px 50px 10px;
// `;

// export const RegisterUserLabel = styled.label`
//     display: flex;
//     position: absolute;
//     left: 10px;
//     top: 10px;
//     color: #7f7f7f;
//     font-size: 14px;
//     padding-left: 5px;
//     cursor: text;
//     transition:
//         top 200ms ease-in,
//         left 200ms ease-in,
//         font-size 200ms ease-in;
//     background-color: white;
//     &:hover{
//         border-color: #12abdb;
//     }
// `;
// export const ManageBtn = styled(Button)`
//  height: 40px;
//   background-color: #0070ad;
//   top: 3%;
//   position: relative;
//   width:160px;
//   left: 4%;
//   border: 2px 2px solid;
//   color: #fff;

//   border-radius: 10px;

// `;

// export const EditProfileBtn = styled(Button)`
//   height: 40px;
//   background-color: #0070ad;
//   top: 3%;
//   position: relative;
//   width:160px;
//   border: 2px 2px solid;
//   color: #fff;

//   border-radius: 10px;
//   left: 40%;

// `;

// export const ProfilesBtn = styled(Button)`
//  height: 40px;
//   background-color: #0070ad;
//   top: 10%;
//   position: relative;
//   width:160px;
//   left: -11%;
//   border: 2px 2px solid;
//   color: #fff;

//   border-radius: 10px;

// `;

// export const RegisterUserInput = styled.div`
//     position: absolute;
//     width: 100%;

//     height: 100%;
//     border: 1.5px solid #0070ad;
//     border-radius: 5px;
//     font-family: inherit;
//     font-size: 14px;
//     color: #272936;
//     padding: 12px 18px 30px 22px;
//     background: none;
//     &:hover{
//         border-color: #12abdb;
//     }
//     &:focus{
//         box-shadow: 0 0 1px 0 #12abdb;
//         border-color: #12abdb;
//         outline: none;
//     }

//     &:focus ~ ${RegisterUserLabel}, :not(:placeholder-shown):not(:focus) ~${RegisterUserLabel} {
//         top: -6px;
//         font-size: 10px;
//         left: 7px;
//         color: black;
//     }
// `;

// export const RegisterUserSpan = styled.span`
//   width: 90%;
//   border: 1.5px solid white;
//   border-radius: 5px;
//   display: block;
//   padding: 9px 4px 100px 9px;
//   margin: 10px 0px 20px 0px;
//   font-size: 14px;
//   color: #272936;
//   background-color: white;
//   ::placeholder {
//     color: #bbb;
//   }
//   &:focus {
//     box-shadow: 0 0 3px 0 #0070ad;
//     border-color: #0070ad;
//     outline: none;
//   }
// `;

// export const ModalSubmitButton = styled.button`
//     margin-top: 10px;
//     padding: 10px 15px;
//     background: #ececec;
//     border-radius: 4px;
//     color: #003857;
//     font-size: 14px;
//     font-family: inherit;
//     outline: none;
//     border: none;
//     cursor: pointer;
//     &:hover{
//         background-color: #12abdb;
//         transform: scale(1.1);
//     }
// `;

// export const FormRow = styled.div`
//     display: flex;
//     margin: 0 -10px;
// `;

// export const SubmitWrapper = styled.div`
//   display: flex;
//   text-align: center;
//   justify-content: center;
// `;
