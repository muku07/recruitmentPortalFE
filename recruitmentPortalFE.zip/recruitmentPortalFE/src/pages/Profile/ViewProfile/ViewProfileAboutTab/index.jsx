import React from "react";
import Typography from "@mui/material/Typography";

import { AboutContainer, StyledSkeleton } from "./ViewProfileAboutElements";

function ViewProfileAboutTab({ profileData , loading }) {

  const loadData = (data) => {
    return(
      <>
      {loading ? (
        <StyledSkeleton variant="text" />
      ) : (
        <>{data}</>
      )}
      </>
    )
  };

  return (
    <>
      <AboutContainer>
        <Typography variant="body1" color="text.secondary" fontWeight="bold">
          {loadData(profileData)}
        </Typography>
      </AboutContainer>
    </>
  );
}

export default ViewProfileAboutTab;
