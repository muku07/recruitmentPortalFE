import { styled } from "@mui/material/styles";
import Skeleton from "@mui/material/Skeleton";

export const AboutContainer = styled("div")`
width: 100%;
padding: 1.2rem 4rem;
`
export const StyledSkeleton = styled(Skeleton)`
  font-size: 4rem;
`;

