export default function AddAccelerator() {
  return <p>Add Accelerator</p>;
}
