import { useEffect, useState } from "react";
import { useMsal } from "@azure/msal-react";
import FilteredAccelerators from "../../../components/Accelerators/FilteredAccelerators";

export default function MyAccelerators({ searchQuery }) {
  const [accelerators, setAccelerators] = useState([]);
  const { instance, accounts } = useMsal();
  // This should be an api call to fetch all blogs by username then msal stuff can be removed
  useEffect(() => {
    fetch("./mock-blog-data.json", {
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
    })
      .then((res) => {
        return res.json();
      })
      .then((json) => {
        setAccelerators(json);
      });
  }, []);
  return (
    <FilteredAccelerators
      allAccelerators={accelerators}
      searchBy="author"
      searchQuery={accounts[0].name}
    />
  );
}
