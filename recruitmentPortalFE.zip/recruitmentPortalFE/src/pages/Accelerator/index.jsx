import { useState } from "react";
import { useNavigate } from "react-router-dom";
import TabContext from "@mui/lab/TabContext";
import Button from "@mui/material/Button";

import {
  MainTitle,
  SearchBox,
  AcceleratorActionContainer,
  StyledTab,
  StyledTabList,
  AcceleratorTabPanel,
} from "./AcceleratorElements.js";
import SearchIcon from "@mui/icons-material/Search";
import FeaturedAccelerators from "./FeaturedAccelerator/index.jsx";
import MyAccelerators from "./MyAccelerators/index.jsx";

const TabViewStatus = {
  FEATURED: "featured",
};

export default function Accelerator() {
  const [view, setView] = useState(TabViewStatus.FEATURED);
  const [searchQuery, setSearchQuery] = useState("");
  const navigate = useNavigate();
  const ROLE = sessionStorage.getItem("role");

  return (
    <>
      <MainTitle>Accelerators</MainTitle>
      <TabContext value={view}>
        <StyledTabList
          onChange={(_, value) => setView(value)}
          aria-label="Accelerator view tabs"
          variant="fullWidth"
          centered
        ></StyledTabList>
        <AcceleratorActionContainer>
          <SearchBox
            placeholder="Search Accelerator"
            onChange={(e) => setSearchQuery(e.target.value)}
            endAdornment={<SearchIcon sx={{ color: "var(--disabled)" }} />}
          />
          <Button
            onClick={() => navigate("/accelerators/add")}
            variant="contained"
            disableElevation
          >
            Add Accelerator
          </Button>
        </AcceleratorActionContainer>
        <AcceleratorTabPanel value={TabViewStatus.FEATURED}>
          <FeaturedAccelerators searchQuery={searchQuery} />
        </AcceleratorTabPanel>
      </TabContext>
    </>
  );
}
