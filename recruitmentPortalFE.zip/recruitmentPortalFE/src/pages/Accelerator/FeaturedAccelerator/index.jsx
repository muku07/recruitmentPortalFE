import { useEffect, useState } from "react";
import FilteredAccelerators from "../../../components/Accelerators/FilteredAccelerators";

export default function FeaturedAccelerators({ searchQuery }) {
  const [accelerators, setAccelerators] = useState([]);
  const [doExpandFirst, setDoExpandFirst] = useState(true);

  useEffect(() => {
    fetch("./mock-accelerator-data.json", {
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
    })
      .then((res) => {
        return res.json();
      })
      .then((json) => {
        setAccelerators(json);
      });
  }, []);

  useEffect(() => {
    if (searchQuery != "") setDoExpandFirst(false);
    else setDoExpandFirst(true);
  }, [searchQuery]);

  return (
    <FilteredAccelerators
      allAccelerators={accelerators}
      searchBy="title"
      searchQuery={searchQuery}
      hideStatusChip
      expandFirst={doExpandFirst}
    />
  );
}
