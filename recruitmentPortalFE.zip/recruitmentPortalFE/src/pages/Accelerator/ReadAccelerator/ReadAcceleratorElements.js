import styled from "styled-components";

import ExpandCircleDownIcon from "@mui/icons-material/ExpandCircleDown";

export const ReadAcceleratorPage = styled.div`
  height: auto;
  width: auto;
  /* padding-top: 20px; */
  margin-bottom: 2rem;
`;

export const ReadAcceleratorContent = styled.div`
  padding: 2rem 0rem;
  height: auto;
  width: 870px;
  margin: auto;
`;

export const BackButtonContainer = styled.div`
  padding: 1rem 0rem;
  display: flex;
  align-items: center;
  gap: 8px;

  span {
    text-align: center;
    font-weight: 500;
    font-size: 1.5rem;
  }
`;

export const BackArrow = styled(ExpandCircleDownIcon)`
  color: var(--accent);
  transform: rotate(90deg);
`;
