import React from "react";
import { useParams } from "react-router-dom";

import ReadDetailedAcceleratorCard from "../../../components/Accelerators/ReadDetailedAccelCard";

import {
  ReadAcceleratorContent,
  ReadAcceleratorPage,
  BackButtonContainer,
  BackArrow,
} from "./ReadAcceleratorElements";

function ReadAccelerator() {
  const { acceleratorId } = useParams();

  //in case we want to use the Accelerator name or id coming from the url and it has dashes or special char that needs to be removed
  //   const AcceleratorName = AcceleratorId.replace(/[-]/g, " ");

  //Hard coded Accelerator content for mapping and testing the card
  const currentAccelerator = [
    {
      title: "Possible outcomes for the future",
      media: "",
      Author: "Jean - Michelle Daniels",
      filter: ["java", "Javascript", "Ecology", "Sustainability"],
      subheading:
        "React offers various extensions for entire application architectural support, such as Flux and React Native, beyond mere UI.",
      para1:
        "React offers some outstanding features that make it the most widely adopted library for frontend app development. Here is the list of those salient features. JSX is a JavaScript syntactic extension. It's a term used in React to describe how the user interface should seem. You can write HTML structures in the same file as JavaScript code by utilizing JSX.",
      para2:
        "React offers some outstanding features that make it the most widely adopted library for frontend app development. Here is the list of those salient features. JSX is a JavaScript syntactic extension. It's a term used in React to describe how the user interface should seem. You can write HTML structures in the same file as JavaScript code by utilizing JSX.",
    },
  ];

  return (
    <ReadAcceleratorPage>
      <ReadAcceleratorContent>
        <BackButtonContainer>
          <BackArrow fontSize="large" />
          <span>Accelerator Details</span>
        </BackButtonContainer>

        <ReadDetailedAcceleratorCard acceleratorData={currentAccelerator} />
      </ReadAcceleratorContent>
    </ReadAcceleratorPage>
  );
}

export default ReadAccelerator;
