import { styled } from "@mui/material/styles";
import { Card, TextField } from "@mui/material";
import InputBase from "@mui/material/InputBase";
import TabPanel from "@mui/lab/TabPanel";
import Tab from "@mui/material/Tab";
import TabList from "@mui/lab/TabList";


export const MainTitle = styled("h2")`
  margin: 1rem auto 0;
`;

export const SearchBox = styled(InputBase)`
  padding: 0 0.3rem 0 0.4rem;
  background: var(--bg-primary);
  border-radius: 0.3rem;
  width: 30%;
`;

export const AcceleratorActionContainer = styled("div")`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  margin: 0.5rem 0;
`;


export const AcceleratorTabPanel = styled(TabPanel)`
  padding: 0;
  display: grid;
  grid-gap: 1rem;
  grid-template-columns: repeat(auto-fill, minmax(15rem, 5fr));
  grid-template-rows: repeat(auto-fill, minmax(25vh, 1fr));
  justify-content: space-between;
  grid-auto-flow: row;
  margin-bottom: 1rem;
  & > .featuredFirst {
    grid-column: 1/-1;
    flex-direction: row;
    min-height: 18rem;
    max-height: 18rem;
    display: grid;
    grid-template-columns: 50% 50%;
    grid-template-rows: 3fr 1fr;

    & > img {
      max-width: 100%;
      min-width: 100%;
      max-height: 100% !important;
      min-height: 100% !important;
      grid-row: 1/-1;
    }
    & > div:first-of-type {
      text-align: right;
      padding: 2rem !important;

      & > h5 {
        font-size: 2rem;
        margin-bottom: 0.5rem;
      }

      & > div {
        display: none;
      }
    }
    & > div:nth-of-type(3) {
      margin-bottom: 2rem;
      min-width: 35%;
      justify-content: flex-end;
      padding-right: 2rem;

      & > button {
        margin: 0 !important;
        padding: 0 !important;
        justify-content: flex-end;
      }
    }
  }
`;

export const StyledTabList = styled(TabList)`
  min-height: 2rem;
  margin: 0.3rem 0;
`;

export const StyledTab = styled(Tab)`
  max-height: 2rem;
  &.Mui-selected {
    font-weight: 700;
  }
  & {
    max-height: 2rem;
    min-height: 2rem;
  }
`;