import { styled } from "@mui/material/styles";
import { Card, TextField } from "@mui/material";
import InputBase from "@mui/material/InputBase";
import TabPanel from "@mui/lab/TabPanel";
import Tab from "@mui/material/Tab";
import TabList from "@mui/lab/TabList";

export const StyledCard = styled(Card)`
  max-width: 15rem;
  margin: 1rem 0;
`;

export const MainTitle = styled("h2")`
  margin: 1rem auto 0;
`;

export const SearchBox = styled(InputBase)`
  padding: 0 0.3rem 0 0.4rem;
  background: var(--bg-primary);
  border-radius: 0.3rem;
  width: 30%;
`;

export const BlogTabPanel = styled(TabPanel)`
  padding: 0;
  display: grid;
  grid-gap: 1rem;
  grid-template-columns: repeat(auto-fill, minmax(15rem, 5fr));
  grid-template-rows: repeat(auto-fill, minmax(18rem, 1fr));
  justify-content: space-between;
  grid-auto-flow: row;
  margin-bottom: 1rem;
`;

export const StyledTabList = styled(TabList)`
  min-height: 2rem;
  margin: 0.3rem 0;
`;

export const StyledTab = styled(Tab)`
  max-height: 2rem;
  &.Mui-selected {
    font-weight: 700;
  }
  & {
    max-height: 2rem;
    min-height: 2rem;
  }
`;

export const BlogsActionContainer = styled("div")`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  margin: 0.5rem 0;
`;
