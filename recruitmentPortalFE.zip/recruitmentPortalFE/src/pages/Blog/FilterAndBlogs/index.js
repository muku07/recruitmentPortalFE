import { memo, useEffect, useState } from "react";
import BlogCard from "../../../components/Blogs/BlogCard";
import FilterSort from "../../../components/Blogs/FilterSort";

// I think these two components could be one. They're split as passing expandFirst caused x2 renders..

const FilterAndBlogsExpanded = memo(
  ({ blogs, setBlogs, searchQuery, hideStatusChip = false }) => {
    const [doExpandFirst, setDoExpandFirst] = useState(true);

    useEffect(() => {
      if (searchQuery !== "" && blogs.length > 1) setDoExpandFirst(false);
      else setDoExpandFirst(true);
    }, [searchQuery]);

    return (
      <>
        <FilterSort
          allBlogs={blogs}
          updateState={setBlogs}
          searchQuery={searchQuery}
        />
        {blogs.length > 0 ? (
          blogs.map((blog, index) => (
            <BlogCard
              key={blog.blogId}
              blog={blog}
              expandFirst={doExpandFirst && index == 0}
              hideStatusChip={hideStatusChip}
            />
          ))
        ) : (
          <h1 style={{ gridColumn: "1/-1", margin: "auto" }}>
            "No results found"
          </h1>
        )}
      </>
    );
  }
);

const FilterAndBlogs = memo(
  ({ blogs, setBlogs, searchQuery, hideStatusChip = false }) => {
    return (
      <>
        <FilterSort
          allBlogs={blogs}
          updateState={setBlogs}
          searchQuery={searchQuery}
        />
        {blogs.length > 0 ? (
          blogs.map((blog) => (
            <BlogCard
              key={blog.blogId}
              blog={blog}
              hideStatusChip={hideStatusChip}
            />
          ))
        ) : (
          <h1 style={{ gridColumn: "1/-1", margin: "auto" }}>
            No results found
          </h1>
        )}
      </>
    );
  }
);

export { FilterAndBlogsExpanded, FilterAndBlogs };
