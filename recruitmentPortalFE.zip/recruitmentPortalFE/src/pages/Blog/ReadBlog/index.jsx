import React from "react";
import { useParams, useNavigate } from "react-router-dom";

import ReadDetailedBlogCard from "../../../components/Blogs/ReadDetailedBlogCard";
import {
  ReadBlogContent,
  ReadBlogPage,
  BackButtonContainer,
  BackArrow,
} from "./ReadBlogElements";

import {
  useGetOneBlog,
  GetBlogImage,
} from "../../../Services/API/Utilities/BlogsApi";

function ReadBlog() {
  const { blogId } = useParams();
  const navigate = useNavigate();

  const currentBlog = useGetOneBlog(blogId);
  const currentBlogImage = GetBlogImage(blogId);
  //in case we want to use the blog name or id coming from the url and it has dashes or special char that needs to be removed
  //   const blogName = blogId.replace(/[-]/g, " ");

  return (
    <ReadBlogPage>
      <ReadBlogContent>
        <BackButtonContainer>
          <BackArrow
            fontSize="large"
            onClick={() => {
              navigate("/blogs");
            }}
          />
          <span>Blog Details</span>
        </BackButtonContainer>

        <ReadDetailedBlogCard
          blogData={currentBlog?.data}
          blogImage={currentBlogImage?.data}
        />
      </ReadBlogContent>
    </ReadBlogPage>
  );
}

export default ReadBlog;
