import { render } from "@testing-library/react"
import { unmountComponentAtNode } from "react-dom";
import { act } from "react-dom/test-utils";
import ReadBlog from "../index"

jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useNavigate: () => jest.fn()
}));

describe("ReadBlog", () => {

    let sut;

    beforeEach(() => {
        sut = render(<ReadBlog />)
    })

    it("should render correctly.", () =>{
        expect(sut.asFragment()).toMatchSnapshot()
     
    })
})



