export default function AddBlog() {
  return <p>Add blog</p>;
}
