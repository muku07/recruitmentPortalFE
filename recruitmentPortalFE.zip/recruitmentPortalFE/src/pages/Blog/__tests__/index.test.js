import BlogHome from "..";
import { BrowserRouter, Routes, Route, MemoryRouter } from "react-router-dom";
import { render, screen, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";

const Wrapper = () => {
  return (
    <Routes>
      <Route path="/" element={<BlogHome />} />
    </Routes>
  );
};

test("Does component render?", () => {
  //   render(<Wrapper />, { wrapper: BrowserRouter });
});

test("TEXT: title", async () => {
  render(
    <MemoryRouter initialEntries={["/"]}>
      <Wrapper />
    </MemoryRouter>
  );

  //   console.log(await screen.queryByTestId("pageTitle"));
  expect(await screen.queryByTestId("pageTitle")).toBeInTheDocument();
  //   expect(await screen.getByTestId("pageTitle")).toBe("Blogs");
});

test("TEXT: Featured tab", async () => {
  render(
    <MemoryRouter initialEntries={["/"]}>
      <Wrapper />
    </MemoryRouter>
  );

  expect(
    await screen.queryByTestId("pageTitle").nextSibling.childNodes[0]
      .childNodes[0].childNodes[0].textContent
  ).toBe("Featured blogs");
});

test("TEXT: My blogs tab", async () => {
  render(
    <MemoryRouter initialEntries={["/"]}>
      <Wrapper />
    </MemoryRouter>
  );

  expect(
    await screen.queryByTestId("pageTitle").nextSibling.childNodes[0]
      .childNodes[0].childNodes[1].textContent
  ).toBe("My blogs");
});

test("TEXT: Verify blogs tab", async () => {
  sessionStorage.setItem("role", "ROLE_ADMIN");

  render(
    <MemoryRouter initialEntries={["/"]}>
      <Wrapper />
    </MemoryRouter>
  );

  expect(
    await screen.queryByTestId("pageTitle").nextSibling.childNodes[0]
      .childNodes[0].childNodes[2].textContent
  ).toBe("Verify blog entries");
});

test("TEXT: Search", () => {
  render(
    <MemoryRouter initialEntries={["/"]}>
      <Wrapper />
    </MemoryRouter>
  );

  console.log(screen.queryByTestId("searchBlogs").childNodes[0]);

  expect(screen.queryByTestId("searchBlogs").childNodes[0]).toHaveAttribute(
    "placeholder",
    "Search blog post"
  );
});

test("TEXT: Add blog button", async () => {
  render(
    <MemoryRouter initialEntries={["/"]}>
      <Wrapper />
    </MemoryRouter>
  );
  //   console.log(await screen.queryByTestId("addBlog"));
  const tab = await screen.queryByTestId("addBlog");
  expect(tab.textContent).toBe("Add new blog");
});

