import { styled } from "@mui/material/styles";

export const BlogModPage = styled("div")`
  height: auto;
  width: auto;
  margin-bottom: 2rem;
`;

export const BlogModContent = styled("div")`
  padding: 2rem 0rem;
  height: auto;
  width: 54.375rem;
  margin: auto;
`;





