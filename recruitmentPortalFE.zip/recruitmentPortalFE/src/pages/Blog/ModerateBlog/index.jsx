import React, { useState } from "react";
import Button from "@mui/material/Button";
import ModeratorModal from "../../../components/Blogs/ModeratorModal";
import ReadDetailedBlogCard from "../../../components/Blogs/ReadDetailedBlogCard";

import {
  BlogModPage,
  BlogModContent,
} from "./BlogModeratorElements";
import {
  BackButtonContainer,
  BackArrow
} from "../ReadBlog/ReadBlogElements";

function BlogModerator() {

  //writtenBlogs array to imitate backend API to save data to uploadedBlogs useState
  //Function to GET from API and set data using setUploadedBlogs
  const blogToMod = [
    {
      title: "Living in a greener world",
      media: "",
      Author: "Bob",
      filter: ["sustainability", "green", "research"],
      subheading: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
      para1:
        "Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. " +
        "Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
      para2:
      "Condimentum mattis pellentesque id nibh tortor id aliquet lectus proin. Lectus sit amet est placerat in egestas erat imperdiet sed. Scelerisque varius morbi enim nunc. Amet cursus sit amet dictum sit. Urna nunc id cursus metus aliquam eleifend. " +
      "Hac habitasse platea dictumst quisque. Malesuada pellentesque elit eget gravida cum sociis natoque penatibus et. Id leo in vitae turpis massa sed elementum tempus."
    }
  ];

  const [isOpen, setOpen] = useState(false);

  //console.log("isOpen", isOpen);

  return (
    <BlogModPage>
    <BlogModContent>

      <BackButtonContainer>

      <BackArrow fontSize="large" />
          <span>Blog Details</span>

        <Button 
          sx={{
            borderRadius: "0.3rem",
            fontWeight: "600",
            marginLeft: "auto",
            textTransform: "none",
          }}
          variant="text"
          color="error"
          onClick={() => setOpen(true)} > 
          Reject 
        </Button>

        <ModeratorModal 
          isOpen={isOpen} 
          onClose={() => setOpen(false)}
          blogData={blogToMod} >
        </ModeratorModal>

        <Button 
          sx={{
            fontWeight: "600",
            textTransform: "none",
            marginLeft: "0.5rem",
            paddingX: "2.5rem",
            //left: "723px"
          }}
          color="success"
          disableElevation
          variant="contained" >
          Approve 
        </Button>

      </BackButtonContainer>
      
      <ReadDetailedBlogCard blogData={blogToMod} />
    </BlogModContent>
  </BlogModPage>
);
};

export default BlogModerator;






