import { useState, useCallback, useEffect, memo } from "react";
import { useNavigate } from "react-router-dom";
import TabContext from "@mui/lab/TabContext";
import Button from "@mui/material/Button";
import {
  MainTitle,
  SearchBox,
  BlogTabPanel,
  StyledTab,
  StyledTabList,
  BlogsActionContainer,
} from "./BlogElements.js";
import { FilterAndBlogs, FilterAndBlogsExpanded } from "./FilterAndBlogs";
import SearchIcon from "@mui/icons-material/Search";
import { useGetAllBlogs } from "../../Services/API/Utilities/BlogsApi";
import { useMsal } from "@azure/msal-react";

const TabViewStatus = {
  FEATURED: "featured",
  MY: "my",
  VERIFY: "verify",
};

function useFilterBlogs(data) {
  const { _, accounts } = useMsal();
  const [blogs, setBlogs] = useState(data);
  const [myBlogs, setMyBlogs] = useState([]);
  const [verifyBlogs, setVerifyBlogs] = useState([]);

  useEffect(() => {
    if (data.length > 0) {
      setBlogs(data.filter((blog) => blog.statusId == 3)); // Status code 3 should be approved
      setMyBlogs(
        data.filter((blog) =>
          blog.publishedBy
            .toLowerCase()
            .includes(accounts[0].name.toLowerCase())
        )
      );
      setVerifyBlogs(data.filter((blog) => blog.statusId == 2)); // Status code 2 should be pending
    }
  }, [data]);

  return [blogs, setBlogs, myBlogs, setMyBlogs, verifyBlogs, setVerifyBlogs];
}

function BlogHome() {
  const navigate = useNavigate();
  const ROLE = sessionStorage.getItem("role");
  const { data, loading, error } = useGetAllBlogs();
  const [blogs, setBlogs, myBlogs, setMyBlogs, verifyBlogs, setVerifyBlogs] =
    useFilterBlogs(data);
  const [view, setView] = useState(TabViewStatus.FEATURED);
  const [searchQuery, setSearchQuery] = useState("");
  const onSearchChange = useCallback(
    (evt) => setSearchQuery(evt.target.value),
    []
  );

  return (
    <>
      <MainTitle data-testid="pageTitle">Blogs</MainTitle>
      <TabContext value={view}>
        <StyledTabList
          onChange={(_, value) => setView(value)}
          aria-label="Blog view tabs"
          variant="fullWidth"
          centered
        >
          <StyledTab label="Featured blogs" value={TabViewStatus.FEATURED} />
          <StyledTab label="My blogs" value={TabViewStatus.MY} />
          {ROLE == "ROLE_ADMIN" && (
            <StyledTab
              label="Verify blog entries"
              value={TabViewStatus.VERIFY}
            />
          )}
        </StyledTabList>
        <BlogsActionContainer>
          <SearchBox
            placeholder="Search blog post"
            onChange={onSearchChange}
            data-testid="searchBlogs"
            endAdornment={<SearchIcon sx={{ color: "var(--disabled)" }} />}
          />
          <Button
            onClick={() => navigate("/blogs/add")}
            data-testid="addBlog"
            variant="contained"
            disableElevation
          >
            Add new blog
          </Button>
        </BlogsActionContainer>
        {loading || error.length > 0 ? (
          <>
            <h1 style={{ textAlign: "center", padding: "9rem" }}>Loading..</h1>
            {error && <p>{error}</p>}
          </>
        ) : (
          <>
            <BlogTabPanel value={TabViewStatus.FEATURED}>
              <FilterAndBlogsExpanded
                blogs={blogs}
                setBlogs={setBlogs}
                searchQuery={searchQuery}
                hideStatusChip
              />
            </BlogTabPanel>
            <BlogTabPanel value={TabViewStatus.MY}>
              <FilterAndBlogs
                blogs={myBlogs}
                setBlogs={setMyBlogs}
                searchQuery={searchQuery}
              />
            </BlogTabPanel>
            <BlogTabPanel value={TabViewStatus.VERIFY}>
              <FilterAndBlogs
                blogs={verifyBlogs}
                setBlogs={setVerifyBlogs}
                searchQuery={searchQuery}
                hideStatusChip
              />
            </BlogTabPanel>
          </>
        )}
      </TabContext>
    </>
  );
}

export default memo(BlogHome);
