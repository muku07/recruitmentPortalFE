// Jeff Semple 23-03-2022
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useMsal, useIsAuthenticated } from "@azure/msal-react";
import axios from "axios";

import Img from "../../assets/Logo.svg";
import { LandingPage, LandingImgCont, LandingImg } from "./LandingElements";

function Landing() {
  const { accounts } = useMsal();
  const navigate = useNavigate();

  const isAuthenticated = useIsAuthenticated();

  const tokenCollect = async () => {
    let item = { userName: accounts[0].username };

    await axios
      .post(
        `https://mapii-portal-profile-service.azurewebsites.net/login`,
        item,
        {
          headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
          },
        }
      )
      .then((res) => {
        console.log(res.data);
        sessionStorage.setItem("username", res.data.userName);
        sessionStorage.setItem("role", res.data.role);
        sessionStorage.setItem("id", res.data.userId);
        sessionStorage.setItem("bearerToken", res.data.bearerToken);
      })
      .catch(sessionStorage.setItem("role", "ROLE_VISITOR"));
  };

  useEffect(() => {
    if (isAuthenticated) {
      console.log("The event has happened!");
      tokenCollect();
      setTimeout(function () {
        navigate("/home");
      }, 4500);
    }
  }, [isAuthenticated]);

  return (
    <LandingPage>
      <LandingImgCont>
        <LandingImg src={Img} />
      </LandingImgCont>
    </LandingPage>
  );
}

export default Landing;
