// Jeff Semple 23-03-2022
import styled from 'styled-components';

export const LandingPage = styled.div`
  position: absolute;

  height: 100vh;
  width: 100%;

  overflow: hidden;
`;

export const LandingImgCont = styled.div`
  position: absolute;

  top: 50%;

  left: 50%;

  transform: translate(-50%, -50%);

  animation: bounce-in 2s ease forwards;

  @keyframes bounce-in {
    0% {
      opacity: 0;
      transform: translate(-50%, -50%) scale(0.3);
    }
    50% {
      opacity: 1;
      transform: translate(-50%, -50%) scale(1.05);
    }
    70% {
      transform: translate(-50%, -50%) scale(0.9);
    }
    100% {
      transform: translate(-50%, -50%) scale(1);
    }
  }
`;

export const LandingImg = styled.img`
  animation: fadeOut 3.5s forwards;
  @keyframes fadeOut {
    70% {
      opacity: 1;
    }
    100% {
      opacity: 0;
    }
  }
`;
