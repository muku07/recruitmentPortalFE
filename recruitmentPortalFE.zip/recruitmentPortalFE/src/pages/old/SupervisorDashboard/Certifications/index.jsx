import React from "react";
import "chart.js/auto";
import { Bar, Pie, Doughnut } from "react-chartjs-2";

import {
  CertCont,
  StatsCont,
  StatsHeader,
  OverviewFiguresCont,
  EmployeesCertifiedCont,
  EmployeesCertifiedHeader1,
  EmployeesCertifiedHeader2,
  TechnologiesCont,
  TechnologiesHeader1,
  TechnologiesHeader2,
  DepartmentsCont,
  DepartmentsHeader1,
  DepartmentsHeader2,
  OverviewGraphCont,
  OverviewGraphHeader,
  ActivitiesCont,
  ActivitiesHeader,
  ActivitiesGridCont,
  ActivityText1,
  ActivityText2,
  ActivityText3,
  ActivityText4,
  ActivityText5,
  MoreActivitiesButton,
} from "./CertificationsElements";

function Certifications() {
  return (
    <CertCont>
      <StatsCont>
        <StatsHeader>Stats Info</StatsHeader>
        <Doughnut
          data={{
            labels: ["Red", "Blue", "Yellow", "Green", "Purple", "Orange"],
            datasets: [
              {
                label: "# of votes",
                data: [12, 19, 3, 5, 2, 3],
                backgroundColor: [
                  "rgba(255, 99, 132, 0.2)",
                  "rgba(54, 162, 235, 0.2)",
                  "rgba(255, 206, 86, 0.2)",
                  "rgba(75, 192, 192, 0.2)",
                  "rgba(153, 102, 255, 0.2)",
                  "rgba(255, 159, 64, 0.2)",
                ],
                borderColor: [
                  "rgba(255, 99, 132, 1)",
                  "rgba(54, 162, 235, 1)",
                  "rgba(255, 206, 86, 1)",
                  "rgba(75, 192, 192, 1)",
                  "rgba(153, 102, 255, 1)",
                  "rgba(255, 159, 64, 1)",
                ],
                borderWidth: 1,
              },
            ],
          }}
          height={20}
          width={20}
          options={{ maintainAspectRatio: false }}
        />
      </StatsCont>
      <OverviewFiguresCont>
        <EmployeesCertifiedCont>
          <EmployeesCertifiedHeader1>
            Employees Certified
          </EmployeesCertifiedHeader1>
          <EmployeesCertifiedHeader2>568</EmployeesCertifiedHeader2>
        </EmployeesCertifiedCont>
        <TechnologiesCont>
          <TechnologiesHeader1>Technologies</TechnologiesHeader1>
          <TechnologiesHeader2>8</TechnologiesHeader2>
        </TechnologiesCont>
        <DepartmentsCont>
          <DepartmentsHeader1>Departments</DepartmentsHeader1>
          <DepartmentsHeader2>12</DepartmentsHeader2>
        </DepartmentsCont>
      </OverviewFiguresCont>
      <OverviewGraphCont>
        <OverviewGraphHeader>Overview</OverviewGraphHeader>
        <Bar
          data={{
            labels: ["Red", "Blue", "Yellow", "Green", "Purple", "Orange"],
            datasets: [
              {
                label: "# of votes",
                data: [12, 19, 3, 5, 2, 3],
                backgroundColor: [
                  "rgba(255, 99, 132, 0.2)",
                  "rgba(54, 162, 235, 0.2)",
                  "rgba(255, 206, 86, 0.2)",
                  "rgba(75, 192, 192, 0.2)",
                  "rgba(153, 102, 255, 0.2)",
                  "rgba(255, 159, 64, 0.2)",
                ],
                borderColor: [
                  "rgba(255, 99, 132, 1)",
                  "rgba(54, 162, 235, 1)",
                  "rgba(255, 206, 86, 1)",
                  "rgba(75, 192, 192, 1)",
                  "rgba(153, 102, 255, 1)",
                  "rgba(255, 159, 64, 1)",
                ],
                borderWidth: 1,
              },
            ],
          }}
          height={20}
          width={20}
          options={{ maintainAspectRatio: false }}
        />
      </OverviewGraphCont>
      <ActivitiesCont>
        <ActivitiesHeader>Activities</ActivitiesHeader>
        <ActivityText1>- Lorem Ipsum Dolor Si4t Amet</ActivityText1>
        <ActivityText2>- Consectetuer Adipiscing Elit</ActivityText2>
        <ActivityText3>- Aenean Commodo Ligula Eget Dolor</ActivityText3>
        <ActivityText4>- Aenean Massa</ActivityText4>
        <ActivityText5>- Cum Sociis Natoque Penatibus Et</ActivityText5>
        {/* <ActivitiesGridCont>
          
        </ActivitiesGridCont> */}
        <MoreActivitiesButton to="/play">
          See More Activites
        </MoreActivitiesButton>
      </ActivitiesCont>
    </CertCont>
  );
}
export default Certifications;
