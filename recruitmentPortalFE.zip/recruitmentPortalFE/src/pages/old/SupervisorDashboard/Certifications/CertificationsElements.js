import styled from "styled-components";
import { NavLink } from "react-router-dom";

export const CertCont = styled.div`
  width: 100%;
  height: 100vh;
`;
export const StatsCont = styled.div`
  position: absolute;
  top: 32.5%;
  left: 80%;
  transform: translate(-50%, -50%);
  padding: 40px;
  width: 32.5%;
  height: 35%;
  background: #fff;
  border-radius: 20px;
  border: 2px solid grey;
  box-shadow: -3px 3px 4px 0 rgba(0, 0, 0, 0.2);
`;

export const StatsHeader = styled.h1`
  position: absolute;
  top: 7.5%;
  left: 5%;
  font-size: 1.5rem;
`;

export const OverviewFiguresCont = styled.div`
  position: absolute;
  top: 25%;
  left: 35%;
  transform: translate(-50%, -50%);
  padding: 40px;
  width: 50%;
  height: 20%;
  background: #fff;
  border-radius: 20px;
  border: 2px solid grey;
  box-shadow: -3px 3px 4px 0 rgba(0, 0, 0, 0.2);
`;

export const EmployeesCertifiedCont = styled.div`
  position: absolute;
  top: 0%;
  left: 1%;
  width: 33%;
  height: 100%;
`;

export const EmployeesCertifiedHeader1 = styled.h1`
  position: absolute;
  width: 100%;
  height: 30%;
  top: 15%;
  font-size: 1.2rem;
  text-align: center;
`;

export const EmployeesCertifiedHeader2 = styled.h2`
  position: absolute;
  width: 100%;
  height: 70%;
  top: 45%;
  font-size: 2.5rem;
  text-align: center;
`;

export const TechnologiesCont = styled.div`
  position: absolute;
  top: 0%;
  left: 35%;
  width: 33%;
  height: 100%;
`;

export const TechnologiesHeader1 = styled.h1`
  position: absolute;
  width: 100%;
  height: 30%;
  top: 15%;
  font-size: 1.2rem;
  text-align: center;
`;

export const TechnologiesHeader2 = styled.h2`
  position: absolute;
  width: 100%;
  height: 70%;
  top: 45%;
  font-size: 2.5rem;
  text-align: center;
`;

export const DepartmentsCont = styled.div`
  position: absolute;
  top: 0%;
  left: 67%;
  width: 33%;
  height: 100%;
`;

export const DepartmentsHeader1 = styled.h1`
  position: absolute;
  width: 100%;
  height: 30%;
  top: 15%;
  font-size: 1.2rem;
  text-align: center;
`;

export const DepartmentsHeader2 = styled.h2`
  position: absolute;
  width: 100%;
  height: 70%;
  top: 45%;
  font-size: 2.5rem;
  text-align: center;
`;

export const OverviewGraphCont = styled.div`
  position: absolute;
  top: 67.5%;
  left: 35%;
  transform: translate(-50%, -50%);
  padding: 40px;
  width: 50%;
  height: 60%;
  background: #fff;
  border-radius: 20px;
  border: 2px solid grey;
  box-shadow: -3px 3px 4px 0 rgba(0, 0, 0, 0.2);
`;

export const OverviewGraphHeader = styled.h1`
  position: absolute;
  top: 7.5%;
  left: 5%;
  font-size: 1.5rem;
`;

export const ActivitiesCont = styled.div`
  position: absolute;
  top: 75%;
  transform: translate(-50%, -50%);
  padding: 40px;
  left: 80%;
  width: 32.5%;
  height: 45%;
  background: #fff;
  border-radius: 20px;
  border: 2px solid grey;
  box-shadow: -3px 3px 4px 0 rgba(0, 0, 0, 0.2);
`;

export const ActivitiesHeader = styled.h1`
  position: absolute;
  top: 7.5%;
  left: 10%;
  font-size: 1.5rem;
`;

export const ActivitiesGridCont = styled.div`
  position: absolute;
  top: 20%;
  width: 80%;
  height: 70%;
  padding: 40px;
  background-color: black;
  overflow-y: scroll;
  display: grid;
  grid-template-columns: 1fr 1fr 1fr, 1fr, 1fr;
  grid-template-rows: 1fr;
`;

export const ActivityText1 = styled.h2`
  position: absolute;
  top: 25%;
  font-size: 1.05rem;
  color: black;
  text-align: center;
`;

export const ActivityText2 = styled.h2`
  position: absolute;
  top: 35%;
  font-size: 1.05rem;
  color: black;
  text-align: center;
`;

export const ActivityText3 = styled.h2`
  position: absolute;
  top: 45%;
  font-size: 1.05rem;
  color: black;
  text-align: center;
`;

export const ActivityText4 = styled.h2`
  position: absolute;
  top: 55%;
  font-size: 1.05rem;
  color: black;
  text-align: center;
`;

export const ActivityText5 = styled.h2`
  position: absolute;
  top: 65%;
  font-size: 1.05rem;
  color: black;
  text-align: center;
`;

export const MoreActivitiesButton = styled(NavLink)`
  position: absolute;
  left: 10%;
  bottom: 10%;
  text-decoration: none;
  color: #1ecbe1;
  text-align: left;
  width: 80%;
  font-weight: bold;
  font-size: 1.1rem;
  cursor: pointer;
`;
