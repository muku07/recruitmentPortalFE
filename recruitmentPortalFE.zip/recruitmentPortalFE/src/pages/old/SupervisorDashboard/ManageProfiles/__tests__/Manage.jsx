import "../ManageProfilesElements";
import {
  BackGround,
  Bar,
  Card,
  CardContainer,
  CardTextContainer,
  ManageContainer,
  Number,
  PageCol1,
  PageCol2,
  PageContainer,
  PageHeader,
  PageHeader2,
  PageLink,
  PageRow,
  SubTitle,
  Title,
} from "../ManageProfilesElements";
import axios from "axios";
import { useEffect, useState } from "react";

function ManageProfiles() {
  const axios = require("axios").default;
  const [inactive, setInactive] = useState();
  useEffect(() => {
    async function getInactive() {
      const URL =
        "https://capg-mapii-portal-uks-mapiipowerbackendapp.azurewebsites.net/searchProfiles?search=activateFlag=false";
      try {
        const res = await axios.post(URL, {
          headers: {
            "Access-Control-Allow-Origin": "*",
            "Content-Type": "application/json",
          },
        });
        var arr = [{}];
        for (var i in res.data) {
          arr.push(res.data[i]);
        }
        setInactive(arr.length - 1);
        console.log(setInactive);

        console.log(arr);
        console.log(arr.length);
      } catch (err) {
        console.log(err);
      }
    }
    getInactive();
  });

  console.log("Checking inactive: ", inactive);

  return (
    <>
      <PageContainer>
        <PageRow>
          <PageCol1>
            <BackGround>
              <ManageContainer data-testid="Menu">
                <Bar href="/my-profile">
                  <p>My Profile</p>
                </Bar>
                <Bar href="/register-user">
                  <p>Register Profiles</p>
                </Bar>
                <Bar href="/supervisor/ListProfiles">
                  <p>List of Profiles</p>
                </Bar>
                <Bar href="/admin/exit-profile">
                  <p>Leaver Profile</p>
                </Bar>
              </ManageContainer>
            </BackGround>
          </PageCol1>
          <PageCol2>
            <PageHeader>Manage Profiles</PageHeader>
            <CardContainer>
              <Card>
                <Title>My Task</Title>
                <CardTextContainer>
                  <SubTitle>Newly Register</SubTitle>
                  <Number data-testid="InactiveProfiles">{inactive}</Number>
                </CardTextContainer>
                <PageLink
                  href="/superuser/activate"
                  data-testid="ActivatePageRedirect"
                >
                  See All{" "}
                </PageLink>
              </Card>
            </CardContainer>
          </PageCol2>
        </PageRow>
      </PageContainer>
    </>
  );
}

export default ManageProfiles;
