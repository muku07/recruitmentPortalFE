import React from "react";
import ManageProfiles from "./Manage";
import { fireEvent, render, screen } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import {
  ManageContainer,
  PageHeader2,
  Bar,
  Card,
  Title,
  CardTextContainer,
  SubTitle,
  Number,
  PageLink,
} from "../ManageProfilesElements";

//Test if links redirects and if the numbers appear on the page
describe("Links redirect to the pages/ Number is visible on the page", () => {
  test("See All redirects to Activate Profile", () => {
    const component = render(<ManageProfiles />);
    const seeAll = component.getByText("See All");
    fireEvent.click(seeAll);
    expect(seeAll.closest("a")).toHaveAttribute("href", "/superuser/activate");
  });

  test("Menu is visible on the page", () => {
    const component = render(<ManageProfiles />);
    const menu = component.getAllByTestId("Menu");
    expect(menu).toBeVisible;
  });

  test("My Profile redirect to My profile page", () => {
    const component = render(<ManageProfiles />);
    const myProfile = component.getByText("My Profile");
    fireEvent.click(myProfile);
    expect(myProfile.closest("a")).toHaveAttribute("href", "/my-profile");
  });
  test("Register Page redirect to page", () => {
    const component = render(<ManageProfiles />);
    const regProfile = component.getByText("Register Profiles");
    fireEvent.click(regProfile);
    expect(regProfile.closest("a")).toHaveAttribute("href", "/register-user");
  });
  test("List of Profiles redirect to page", () => {
    const component = render(<ManageProfiles />);
    const listProfile = component.getByText("List of Profiles");
    fireEvent.click(listProfile);
    expect(listProfile.closest("a")).toHaveAttribute(
      "href",
      "/supervisor/ListProfiles"
    );
  });
  test("Leaver Profile redirect to page", () => {
    const component = render(<ManageProfiles />);
    const levProfile = component.getByText("Leaver Profile");
    fireEvent.click(levProfile);
    expect(levProfile.closest("a")).toHaveAttribute(
      "href",
      "/admin/exit-profile"
    );
  });
});
