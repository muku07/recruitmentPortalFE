import styled from "styled-components";

export const PageContainer = styled.div`
  margin-left: 100px;
  height: 100%;
  /* @media only screen and (min-device-width: 768px) and (max-device-width: 1024px) and (-webkit-min-device-pixel-ratio: 1) {
    top: -10%;
  } */
  @media screen and (min-width: 2560px) {
    margin-left: 15%;
  }
`;

//Page Grid
export const PageRow = styled.div`
  :after {
    content: "";
    display: table;
    clear: both;
  }
  /* @media only screen and (min-device-width: 768px) and (max-device-width: 1024px) and (-webkit-min-device-pixel-ratio: 1) {
    top: -10%;
  } */
`;
export const PageCol1 = styled.div`
  float: left;
  width: 22%;
  padding: 10px;
  height: 360px;
  @media only screen and (min-device-width: 768px) and (max-device-width: 1024px) and (-webkit-min-device-pixel-ratio: 1) {
    float: none;
    width: 40%;
    padding: 10px;
    height: 360px;
  }
`;
export const PageCol2 = styled.div`
  width: 90%;
  height: 100%;
  @media only screen and (min-device-width: 768px) and (max-device-width: 1024px) and (-webkit-min-device-pixel-ratio: 1) {
    width: 90%;
    height: 100%;
    margin-left: 15%;
    margin-top: -55%;
  }
  @media screen and (min-width: 2560px) {
    width: 90%;
    height: 100%;
    margin-left: 15%;
    margin-top: 2%;
  }
`;

// Card Items
export const Card = styled.div`
  margin: 15px;
  background-color: #58e5ff;
  border-radius: 15px;
  box-shadow: -4px 4px 6px rgba(0, 0, 0, 0.1);
  width: 145%;
  height: 88%;
  color: #fff;
  margin-left: 132px;
`;

export const CardContainer = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  grid-gap: 6%;
  /* @media only screen and (min-device-width: 768px) and (max-device-width: 1024px) and (-webkit-min-device-pixel-ratio: 1) {

  } */
  @media only screen and (min-device-width: 768px) and (max-device-width: 1024px) and (-webkit-min-device-pixel-ratio: 1) {
    margin-left: -5%;
  }
`;

// Card Text
export const Title = styled.p`
  padding-top: 2%;
  text-align: center;
  font-family: "Ubuntu";
  color: #007ad0;
  font-weight: 600;
  font-size: 177%;
  margin: 10px 0 15px 0;
  @media screen and (min-width: 2560px) {
    font-size: 40px;
  }
`;
export const PageLink = styled.a`
  text-align: center;
  font-family: "Ubuntu";
  color: #fff;
  font-weight: 600;
  font-size: 160%;
  float: right;
  margin-top: 10%;
  margin-bottom: 5%;
  padding-right: 5%;
  :link {
    text-decoration: none;
  }
  @media screen and (min-width: 2560px) {
    font-size: 40px;
  }
`;
export const SubTitle = styled.p`
  font-family: "Ubuntu";
  color: #007ad0;
  font-weight: 600;
  font-size: 170%;
  margin: 10px 0 15px 0;
  @media screen and (min-width: 2560px) {
    font-size: 40px;
  }
`;
export const Number = styled.p`
  font-family: "Ubuntu";
  color: #007ad0;
  font-weight: 600;
  font-size: 165%;
  margin: 10px 0 15px 0;
  @media screen and (min-width: 2560px) {
    font-size: 40px;
  }
`;

export const CardTextContainer = styled.div`
  padding-top: 9.5%;
  display: grid;
  grid-template-columns: 1fr 1fr;
  grid-gap: 1%;
  align-items: center;
  text-align: center;
`;
// Manage Bar
export const ManageContainer = styled.div`
  display: grid;
  grid-template-rows: 1fr;
  grid-gap: 5%;
`;
export const BackGround = styled.div`
  margin-top: 33%;
  width: 93%;
  height: 64%;
  background-color: #007ad0;
  border-radius: 2%;
  box-shadow: -4px 4px 6px rgba(0, 0, 0, 0.1);
  padding-top: 2%;
  @media only screen and (min-device-width: 768px) and (max-device-width: 1024px) and (-webkit-min-device-pixel-ratio: 1) {
    margin-left: -10%;
    width: 200px;
    margin-top: 40%;
  }
  @media only screen and (min-device-width: 426px) and (max-device-width: 812px) and (-webkit-min-device-pixel-ratio: 3) {
    margin-left: -10%;
    width: 600px;
    margin-top: 40%;
  }
  @media screen and (min-width: 2560px) {
    margin-left: 20%;
    width: 300px;
    height: 252px;
  }
  /* @media (max-width: 426px) {
    transition: 0.3s;
    padding-top: 12%;
    width: 250px;
    left: 200px;
  } */
`;

export const Bar = styled.a`
  width: 101%;
  height: 43px;
  font-weight: 500;
  font-size: 133%;
  color: #fff;
  text-align: center;
  padding-top: 4%;
  p {
    :hover {
      background-color: #58e5ff;
      padding-top: 1%;
      padding-bottom: 1%;
      width: 99%;
      color: #007ad0;
    }
    @media screen and (min-width: 2560px) {
      font-size: 30px;
    }
  }

  :link {
    text-decoration: none;
  }
`;

// Page Header

export const PageHeader = styled.p`
  text-align: center;
  font-family: "Ubuntu";
  color: #007ad0;
  font-weight: 600;
  font-size: 167%;
  margin: 10px 0 15px 0;
  @media screen and (min-width: 2560px) {
    width: 821px;
    font-size: 47px;
  }
`;
