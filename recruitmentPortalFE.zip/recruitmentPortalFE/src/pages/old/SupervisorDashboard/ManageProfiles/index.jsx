import "./ManageProfilesElements";
import { useNavigate } from "react-router-dom";
import {
  BackGround,
  Bar,
  Card,
  CardContainer,
  CardTextContainer,
  ManageContainer,
  Number,
  PageCol1,
  PageCol2,
  PageContainer,
  PageHeader,
  PageLink,
  PageRow,
  SubTitle,
  Title,
} from "./ManageProfilesElements";
import axios from "axios";
import { useEffect, useState } from "react";

function ManageProfiles() {
  const navigate = useNavigate();
  const [isAdmin, setIsAdmin] = useState(false);
  const [storedId, setStoredId] = useState(0);
  useEffect(() => {
    let auth = sessionStorage.getItem("role");
    let azureId = sessionStorage.getItem("id");

    setStoredId(parseInt(azureId));
    // console.log(storedUsername);

    if (auth === "ROLE_ADMIN") {
      setIsAdmin(true);
    }
  }, []);

  const axios = require("axios").default;
  const [inactive, setInactive] = useState();
  useEffect(() => {
    async function getInactive() {
      const URL =
        "https://capg-mapii-portal-uks-mapiipowerbackendapp.azurewebsites.net/searchProfiles?search=activateFlag=false";
      try {
        const res = await axios.post(URL, {
          headers: {
            "Access-Control-Allow-Origin": "*",
            "Content-Type": "application/json",
          },
        });
        var arr = [{}];
        for (var i in res.data) {
          arr.push(res.data[i]);
        }
        setInactive(arr.length - 1);

        console.log(arr);
        console.log(arr.length);
      } catch (err) {
        console.log(err);
      }
    }
    getInactive();
  });

  console.log("Checking inactive: ", inactive);

  return (
    <>
      <PageContainer>
        <PageRow>
          <PageCol1>
            <BackGround>
              <ManageContainer>
                <Bar
                  onClick={() => {
                    navigate("/view-profile", { state: { id: storedId } });
                  }}
                >
                  <p>My Profile</p>
                </Bar>
                <Bar
                  onClick={() => {
                    navigate("/register-user");
                  }}
                >
                  <p>Register Profiles</p>
                </Bar>
                <Bar
                  onClick={() => {
                    navigate("/ListProfiles");
                  }}
                >
                  <p>List of Profiles</p>
                </Bar>
                <Bar
                  onClick={() => {
                    navigate("/superuser/exit-profile");
                  }}
                >
                  <p>Leaver Profiles</p>
                </Bar>
              </ManageContainer>
            </BackGround>
          </PageCol1>
          <PageCol2>
            <PageHeader>Manage Profiles</PageHeader>
            <CardContainer>
              <Card>
                <Title>My Task</Title>
                <CardTextContainer>
                  <SubTitle>Newly Register</SubTitle>
                  <Number>{inactive}</Number>
                </CardTextContainer>
                <PageLink
                  onClick={() => {
                    navigate("/superuser/activate");
                  }}
                >
                  See All{" "}
                </PageLink>
              </Card>
            </CardContainer>
          </PageCol2>
        </PageRow>
      </PageContainer>
    </>
  );
}
export default ManageProfiles;
