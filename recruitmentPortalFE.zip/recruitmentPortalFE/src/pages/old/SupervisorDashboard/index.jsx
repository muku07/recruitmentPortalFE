import React from "react";
import { useNavigate } from "react-router-dom";

import accountPlaceholder from "../../../assets/accountPlaceholder.svg";
import mapMembers from "../../../assets/mapmembers.svg";
import certifications from "../../../assets/certifications.svg";
import mapForum from "../../../assets/mappforum.svg";
import accelerators from "../../../assets/AcceleratorDashboard.svg";
import blogs from "../../../assets/BlogsDashboard.svg";
import achievements from "../../../assets/achievements.svg";

import {
  MainContentCont,
  AccountSignedInCont,
  PlaceholderImgAccountCont,
  ImgGridCont,
  MapMembersCont,
  TextDiv,
  MapMemberTextCont,
  CertificationTextCont,
  CertificationCont,
  ForumTextCont,
  ForumCont,
  AcceleratorsTextCont,
  AcceleratorsCont,
  BlogsTextCont,
  BlogsCont,
  AchievementsTextCont,
  AchievementsCont,
} from "./SupervisorDashboardElements";

function SupervisorDashboard() {
  // navigate is here because when I use link, it underlines the text
  const navigate = useNavigate();

  const ClickedMapMembers = () => {
    // alert("MAP members");
    navigate("/home");
  };
  const ClickedCertifications = () => {
    // alert("Certifications(");
    navigate("/home");
  };
  const ClickedMapForum = () => {
    // alert("Forum");
    navigate("/home");
  };
  const ClickedAccelerators = () => {
    // alert("Accelerators");
    navigate("/home");
  };
  const ClickedBlogs = () => {
    // alert("blogs")
    navigate("/home");
  };
  const ClickedAchievements = () => {
    // alert("Achievements");
    navigate("/home");
  };

  return (
    <MainContentCont>
      <AccountSignedInCont>
        <PlaceholderImgAccountCont src={accountPlaceholder} />
      </AccountSignedInCont>

      <ImgGridCont>
        <MapMemberTextCont onClick={ClickedMapMembers}>
          <MapMembersCont src={mapMembers} />
          <TextDiv>
            {/* <TextSpan> */}
            MAPII Members
            {/* </TextSpan> */}
          </TextDiv>
        </MapMemberTextCont>
        <CertificationTextCont onClick={ClickedCertifications}>
          <CertificationCont src={certifications} />
          <TextDiv>
            {/* <TextSpan> */}
            Certifications
            {/* </TextSpan> */}
          </TextDiv>
        </CertificationTextCont>
        <ForumTextCont onClick={ClickedMapForum}>
          <ForumCont src={mapForum} />
          <TextDiv>
            {/* <TextSpan> */}
            MAPII Forum
            {/* </TextSpan> */}
          </TextDiv>
        </ForumTextCont>
        <AcceleratorsTextCont onClick={ClickedAccelerators}>
          <AcceleratorsCont src={accelerators} />
          <TextDiv>
            {/* <TextSpan> */}
            Accelerators
            {/* </TextSpan> */}
          </TextDiv>
        </AcceleratorsTextCont>
        <BlogsTextCont onClick={ClickedBlogs}>
          <BlogsCont src={blogs} />
          <TextDiv>
            {/* <TextSpan> */}
            Blogs
            {/* </TextSpan> */}
          </TextDiv>
        </BlogsTextCont>
        <AchievementsTextCont onClick={ClickedAchievements}>
          <AchievementsCont src={achievements} />
          <TextDiv>
            {/* <TextSpan> */}
            Achievements
            {/* </TextSpan> */}
          </TextDiv>
        </AchievementsTextCont>
      </ImgGridCont>
    </MainContentCont>
  );
}
export default SupervisorDashboard;
