import React, { useState, useRef, useCallback, useEffect } from "react";

import {
  HeaderContainer,
  Title,
  AcceleratorPage,
  NewAcceleratorButton,
  AcceleratorTile,
  InnerHeader,
  ButtonImageContainer,
  AddNewButtonContainer,
  ModalBackground,
  ModalWrapper,
  ModalContent,
  CloseModalButton,
  InputTextName,
  AccleratorTileWrappers,
  RadioItem,
  Radiobutton,
  RadioButtonLabel,
  RadioButtonContainer,
  Acceleratorform,
  InputTextDesc,
  FormError,
} from "./AcceleratorsElements";

import { apiProvider } from "../../../../Services/API/Utilities/Provider";

function Accelerator() {
  //Data that would come from DB for accelerators stored
  // const acceleratorsDB = [
  //   {
  //     AccTitle: "CapQuiz",
  //     AccDesc: "Quiz accelerator using react and java",
  //     Pillar: "java",
  //   },
  //   {
  //     AccTitle: "MAPII Portal",
  //     AccDesc: "Portal for MAPII",
  //     Pillar: "java",
  //   },
  //   {
  //     AccTitle: "Python test",
  //     AccDesc: "Quiz accelerator using react and java",
  //     Pillar: "python",
  //   },
  //   {
  //     AccTitle: ".NET sdk",
  //     AccDesc: "Example dot net",
  //     Pillar: "dotnet",
  //   },
  //   {
  //     AccTitle: "Azure Migration",
  //     AccDesc: "Moving from github to Azure",
  //     Pillar: "devops",
  //   },
  // ];

  // const [accList, setAccList] = useState(acceleratorsDB);
  const [showModal, setShowModal] = useState(false);
  const modalRef = useRef();

  const apiGet = apiProvider.GetAllApi("0b98f93d-dc87-439f-a897-70f97223b4ce");

  useEffect(() => {
    apiGet.request();
  }, []);

  //Initial empty form state that starts and is reset to after submit - need to match the backend key names
  const initialFormState = {
    acceleratorName: "",
    description: "",
    selectPillar: "",
  };

  //State for the new accelerator form and errors from uncomplete
  const [form, setForm] = useState(initialFormState);
  const [error, setError] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(form);

    //Validation to ensure all fields are not empty
    for (let key in form) {
      if (form[key] === "") {
        setError(`You must provide the ${key}`);
        return;
      }
      setError("");
    }

    //Call to function for POST goes here
    setForm(initialFormState);
  };

  const handleInput = (e) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
    console.log(e.target.name, e.target.value);
  };

  const openModal = () => {
    setShowModal((prev) => !prev);
  };

  //Closing modal when clicking outside (modal background) of modal wrapper which houses main content
  const closeModal = (e) => {
    if (modalRef.current === e.target) {
      setShowModal(false);
    }
  };

  //Allows to clock the ESC key and close modal
  const escPress = useCallback(
    (e) => {
      if (e.key === "Escape" && showModal) {
        setShowModal(false);
      }
    },
    [setShowModal, showModal]
  );

  //Allows to clock the ESC key and close modal
  useEffect(() => {
    document.addEventListener("keydown", escPress);
    return () => document.removeEventListener("keydown", escPress);
  }, [escPress]);

  //Turned modal into a condition within the main return due to issues where the input text fields would keep rendering as both return functions in a single function
  //Alternative is to move modal in its own file and import it in

  return (
    <>
      {showModal ? (
        <AcceleratorPage>
          <HeaderContainer>
            <Title>Accelerators</Title>
          </HeaderContainer>

          <AddNewButtonContainer>
            <NewAcceleratorButton onClick={openModal}>
              Add New Accelerator
            </NewAcceleratorButton>
          </AddNewButtonContainer>

          <AccleratorTileWrappers>
            {apiGet.data?.map((accel, i) => (
              <AcceleratorTile key={i}>
                <ButtonImageContainer
                  src={require(`../../../../assets/${accel.Pillar}.svg`)}
                  i={i}
                ></ButtonImageContainer>
                <InnerHeader>Project {accel.AccTitle}</InnerHeader>
              </AcceleratorTile>
            ))}
          </AccleratorTileWrappers>

          <ModalBackground ref={modalRef} onClick={closeModal}>
            <ModalWrapper showModal={showModal}>
              <ModalContent>
                <h1>Make a new accelerator</h1>
                <p>
                  Enter the name of the accelerator and the pillar it belongs to
                </p>

                <Acceleratorform onSubmit={handleSubmit}>
                  <InputTextName
                    type="text"
                    name="acceleratorName"
                    value={form.acceleratorName}
                    onChange={(e) => handleInput(e)}
                    placeholder="Accelerator name"
                  />
                  <InputTextDesc
                    type="text"
                    name="description"
                    value={form.description}
                    onChange={handleInput}
                    placeholder="Description"
                  />
                  <RadioButtonContainer>
                    <RadioItem>
                      <Radiobutton
                        type="radio"
                        name="selectPillar"
                        value="java"
                        checked={form.selectPillar === "java"}
                        onChange={(e) => handleInput(e)}
                      />
                      <RadioButtonLabel /> Java
                    </RadioItem>

                    <RadioItem>
                      <Radiobutton
                        type="radio"
                        name="selectPillar"
                        value="dotnet"
                        checked={form.selectPillar === "dotnet"}
                        onChange={(e) => handleInput(e)}
                      />
                      <RadioButtonLabel /> .NET
                    </RadioItem>

                    <RadioItem>
                      <Radiobutton
                        type="radio"
                        name="selectPillar"
                        value="python"
                        checked={form.selectPillar === "python"}
                        onChange={(e) => handleInput(e)}
                      />
                      <RadioButtonLabel /> Python
                    </RadioItem>

                    <RadioItem>
                      <Radiobutton
                        type="radio"
                        name="selectPillar"
                        value="devops"
                        checked={form.selectPillar === "devops"}
                        onChange={(e) => handleInput(e)}
                      />
                      <RadioButtonLabel /> DevOps
                    </RadioItem>
                  </RadioButtonContainer>
                  {error && (
                    <FormError>
                      <p>{error}</p>
                    </FormError>
                  )}

                  <button>Submit now</button>
                </Acceleratorform>
              </ModalContent>

              <CloseModalButton
                aria-label="Close modal"
                onClick={() => setShowModal((prev) => !prev)}
              />
            </ModalWrapper>
          </ModalBackground>
        </AcceleratorPage>
      ) : (
        <>
          <AcceleratorPage>
            <HeaderContainer>
              <Title>Accelerators</Title>
            </HeaderContainer>

            <AddNewButtonContainer>
              <NewAcceleratorButton onClick={openModal}>
                Add New Accelerator
              </NewAcceleratorButton>
            </AddNewButtonContainer>

            <AccleratorTileWrappers>
              {apiGet.data?.map((accel, i) => (
                <AcceleratorTile key={i}>
                  <ButtonImageContainer
                    src={require(`../../../../assets/${accel.Pillar}.svg`)}
                    i={i}
                  ></ButtonImageContainer>
                  <InnerHeader>Project {accel.AccTitle}</InnerHeader>
                </AcceleratorTile>
              ))}
            </AccleratorTileWrappers>
          </AcceleratorPage>
        </>
      )}
    </>
  );
}

export default Accelerator;
