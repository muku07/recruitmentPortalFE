// Jeff Semple 28-03-2022 
import styled from 'styled-components';



//             sidebar, main container and sign-in sections
export const MainContentCont = styled.div`
display: flex;
`;
export const SidebarCont = styled.div`
z-index: 5;
`;
export const AccountSignedInCont = styled.div`
position: absolute;
right:0;
margin-right: 5%;
margin-top: 20px;
`;
export const PlaceholderImgAccountCont =styled.img`
max-width: 80%;
`;

//              image logo
export const LogoCont = styled.div`
position: absolute;
left:0;
margin-left: 150px;
margin-top: 20px;
`;
export const LogoImg = styled.img`
  max-width: 80%;

@media (max-width:1200px ){
    max-width: 50%;
}
@media (max-width:900px ){
    max-width: 50%;
}
@media (max-width:850px ){
    max-width: 50%;
}
@media (max-width:800px ){
    max-width: 50%;
}
`;

//              image & text section section
export const ImgGridCont = styled.div`
border-radius: 0px 0px 15px 15px;
position: absolute;
margin-top: 8%;
display: grid;
grid-template-columns: 70% 70% 70%;
grid-template-rows: 60% 60%;
margin-left: 10%;
@media (max-width:1300px) {
grid-template-columns: 60% 60% 50%;
grid-template-rows: 60% 60%;
}
@media (max-width:1270px) {
grid-template-columns: 57% 57% 50%;
grid-template-rows: 60% 60%;
}
@media (max-width:1250px) {
grid-template-columns: 50% 50% 55%;
grid-template-rows: 60% 60%;
}
@media (max-width:1230px ){
grid-template-columns: 40% 40% 45%;
grid-template-rows: 60% 60%;
}
// anything below =< 1200px changes column and row number to 2x3
@media (max-width:1200px ){
margin-left: 15%;
grid-template-columns: 80% 0%;
grid-template-rows: 60% 60% 60%;
}
@media (max-width:1150px ){
margin-left: 15%;
grid-template-columns: 70% 0%;
grid-template-rows: 60% 60% 60%;
}
@media (max-width:1050px ){
margin-left: 15%;
grid-template-columns: 65% 0%;
grid-template-rows: 60% 60% 60%;
}
@media (max-width:1000px ){
margin-left: 15%;
grid-template-columns: 60% 0%;
grid-template-rows: 60% 60% 60%;
}
@media (max-width:950px ){
margin-left: 15%;
grid-template-columns: 55% 0%;
grid-template-rows: 60% 60% 60%;
}
@media (max-width:950px ){
margin-left: 15%;
grid-template-columns: 55% 0%;
grid-template-rows: 60% 60% 60%;
}
@media (max-width:900px ){
margin-left: 15%;
grid-template-columns: 55% 0%;
grid-template-rows: 60% 60% 60%;
}
// anything below =< 880px changes column and row number to 1x6
@media (max-width:880px ){
margin-left: 35%;
grid-template-columns: 60% ;
grid-template-rows: 60% 60% 60% 50% 50% 0%;
}

`;
export const TextDiv = styled.div`
background-color: rgba(0, 168, 255, 0.6);

height: 54px;
border-radius: 0px 0px 10px 10px;
display:flex;
justify-content: center;
text-align: center;
font-weight: bold;
`;
export const TextSpan = styled.span`
font-weight: bold;

`;

/**             map members */
export const MapMemberTextCont = styled.div`
box-shadow: 1px 1px 10px #888888;
:hover{opacity:0.9}
width: 340px;
height: 285px;
border-radius: 0px 0px 10px 10px;
grid-row: 1 / 2;
grid-column: 1 / 3; 

@media (max-width:1230px ){

grid-row: 1 / 3;
grid-column: 1 / 2; 
}
@media (max-width:850px ){
margin-left: 15%;
grid-row: 1 / 6;
grid-column: 1 / 1; 
}
`;
export const MapMembersCont = styled.img`

  max-width: 315px;
  
`;

/**             certifications */
export const CertificationTextCont = styled.div`
box-shadow: 1px 1px 10px #888888;
:hover{opacity:0.9}
width: 340px;
height: 286px;
border-radius: 0px 0px 10px 10px;
grid-row: 1 / 2;
grid-column: 2 / 3; 

@media (max-width:1230px ){

grid-row: 1 / 3;
grid-column: 2 / 2; 
}
@media (max-width:880px ){
margin-left: 15%;
grid-row: 2 / 6;
grid-column: 1 / 1; 
}
`;
export const CertificationCont = styled.img`

  max-width: 250px;
`;

/**            mapForum */
export const ForumTextCont = styled.div`
box-shadow: 1px 1px 10px #888888;
:hover{opacity:0.9}
width: 340px;
height: 280px;
border-radius: 0px 0px 10px 10px;
grid-row: 1/ 2;
grid-column: 3 / 3; 

@media (max-width:1200px ){

grid-row: 2 / 3;
grid-column: 1 / 2; 
}
@media (max-width:880px ){
margin-left: 15%;
grid-row: 3 / 6;
grid-column: 1 / 1; 
}
`;
export const ForumCont = styled.img`
  max-width: 250px;
`;

/**            Accelerators */
export const AcceleratorsTextCont = styled.div`
box-shadow: 1px 1px 10px #888888;
:hover{opacity:0.9}
width: 340px;
height: 240px;
border-radius: 0px 0px 10px 10px;
grid-row: 2/ 2;
grid-column: 1 / 3; 

@media (max-width:1200px ){

grid-row: 2 / 3;
grid-column: 2 / 2; 
}
@media (max-width:880px ){
margin-left: 15%;
grid-row: 4 / 6;
grid-column: 1 / 1; 
}
`;
export const AcceleratorsCont = styled.img`
  max-width: 250px;
`;

/**            Blogs */
export const BlogsTextCont = styled.div`
box-shadow: 1px 1px 10px #888888;
:hover{opacity:0.9}
width: 340px;
height: 242px;
border-radius: 0px 0px 10px 10px;
grid-row: 2/ 2;
grid-column: 2 / 3;

@media (max-width:1200px ){

grid-row: 5 / 3;
grid-column: 1 / 2; 
} 
@media (max-width:880px ){
margin-left: 15%;
grid-row: 5 / 6;
grid-column: 1 / 1; 
}
`;
export const BlogsCont = styled.img`
  max-width: 250px;
`;

/**            Achievements */
export const AchievementsTextCont = styled.div`

box-shadow: 1px 1px 10px #888888;
display:flex;
flex-direction: column;
justify-content: center;


:hover{opacity:0.9}
width: 345px;
height: 230px;
border-radius: 0px 0px 10px 10px;
grid-row: 2/ 2;
grid-column: 3 / 3; 


@media (max-width:1200px ){

grid-row: 3/ 3;
grid-column: 2 / 2; 
}
@media (max-width:880px ){
margin-left: 15%;
grid-row: 6 / 6;
grid-column: 1 / 1; 
}
`;
export const AchievementsCont = styled.img`
  max-width: 250px;
`;
