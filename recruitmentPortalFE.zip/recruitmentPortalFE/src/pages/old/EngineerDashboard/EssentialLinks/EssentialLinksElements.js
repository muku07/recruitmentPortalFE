import styled from "styled-components";

import SearchIcon from "../../../../assets/SearchIcon.svg";
export const Page = styled.div`
  height: 800px;
  max-width: 100%;
  width: 100%;
`;

export const HeadingContainer = styled.div``;

export const Heading = styled.h1`
  font-style: italic;
  text-align: left;
  font-size: 2rem;
  font-weight: 600;
  height: 100%;
  color: #0070ad;
  padding: 5px 60px;
`;

export const SearchContainer = styled.div`
  // height: 100px;
  // width:220px;
  // height:36px;
  // position:relative
  // box-sizing:border
  position: absolute;
  left: 18%;
  top: 1%;
  height: 50vh;
  width: auto;
  overflow: hidden;
`;

export const SearchBox = styled.input`
  // width: 50%;
  // margin: 20px 20px 0px 50px;
  // padding 10px;
  width: 600px;
  border: 1.5px solid #0070ad;
  border-radius: 5px;
  display: block;
  padding: 9px 4px 9px 9px;
  font-size: 14px;
  color: #272936;
  background: transparent url(${SearchIcon}) no-repeat 755px center;
  ::placeholder {
    color: #bbb;
  }
  &:focus {
    box-shadow: 0 0 3px 0 #12abdb;
    border-color: #12abdb;
    outline: none;
  }
`;
export const LinkListContainer = styled.div`
  background-color: #12abdb;
  padding-right: 60px;
  padding-left: 60px;
`;

export const LinkList = styled.ul`
  margin: 2% 17% 2% 17%;
`;

export const LinkContainer = styled.li`
  position: relative;
  width: 110px;
  height: 110px;
  float: left;
  text-align: center;
  padding-top: 10px;
  cursor: pointer;
  overflow: hidden;
  font-size: 0.9em;
  margin: 4px;
  border: solid 1px rgba(0, 0, 0, 0.3);
  -moz-border-radius: 2px;
  -webkit-border-radius: 2px;
  border-radius: 2px;
  -moz-box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.3);
  -webkit-box-shadow: 0px 4px 4px rgb(0 0 0 / 30%);
  box-shadow: 0px 4px 4px rgb(0 0 0 / 30%);
  background-color: #58e5ff;
  background-image: linear-gradient(to top, #58e5ff 0px, #f0f0f0 100%);
  border-radius: 10px;
  color: #23527c;
  list-style-type: none;
  margin-right: 20px;

  &:hover > * {
    color: #ffffff;
    background: #1895d9;
    transition: 0.8s ease-in-out;
    transform: rotate(360deg);
  }

  &:hover {
    color: #ffffff;
    background: #1895d9;
  }

  & .text-iconed {
    font-size: 50px;
    padding: 2px;
    margin: 2px 20px 2px 20px;
  }
`;

export const LinkItem = styled.a`
  color: #23527c;
  text-decoration: none;
  text-align: center;
  font-size: 15px;
`;
