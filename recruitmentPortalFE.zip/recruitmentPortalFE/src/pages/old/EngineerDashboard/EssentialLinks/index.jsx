// import React from "react";
// import { AiFillPlaySquare } from "react-icons/ai";
// import { BsCheckLg } from "react-icons/bs";
// import { FaPercentage, FaRegThumbsUp, FaChild, FaCarAlt, FaUsers } from "react-icons/fa";
// import { FiSettings } from "react-icons/fi";
// import { RiMoneyDollarBoxFill } from "react-icons/ri";
// import { BsFillKeyboardFill, BsFillFileTextFill, BsFillBriefcaseFill, BsStopwatch, BsFillTelephoneFill} from "react-icons/bs";
// import { AiFillHome, AiFillStar} from "react-icons/ai";
// import { VscFiles } from "react-icons/vsc";
// import { BiDesktop, BiTable } from "react-icons/bi";
// import { MdOutlineMenuBook } from "react-icons/md";
// import { RiBookmarkLine } from "react-icons/ri";
// import { TiLightbulb } from "react-icons/ti";
// import { ImFileText2 } from "react-icons/im";
// import AOS from "aos";
// import "aos/dist/aos.css";
// import { useEffect } from "react";
// import Typed from "react-typed";

// import {
//   Page,
//   HeadingContainer,
//   LinkList,
//   LinkContainer,
//   LinkItem
// } from "./EssentialLinksElements";

// function EssentialLinks() {
//   //HTML Code#
//   useEffect(() => {
//     AOS.init({});
//   }, []);
//   return (
//     <>
//       <Page >
//         <HeadingContainer>
//         </HeadingContainer>
//         <LinkList>
//           <LinkContainer data-aos={"zoom-in"} data-aos-duration="1500">
//             <AiFillPlaySquare className="text-iconed" />
//             <LinkItem href="https://www.capgemini.com/">
//               Assets Allocation
//             </LinkItem>
//           </LinkContainer>
//           <LinkContainer data-aos={"zoom-out"} data-aos-duration="1500">
//             <BsCheckLg className="text-iconed" />
//             <LinkItem href="https://www.capgemini.com/">Authorization Matrix</LinkItem>
//           </LinkContainer>
//           <LinkContainer data-aos={"zoom-in"} data-aos-duration="1500">
//             <FaPercentage className="text-iconed" />
//             <LinkItem href="https://www.capgemini.com/">Baza 1%</LinkItem>
//           </LinkContainer>
//           <LinkContainer data-aos={"zoom-out"} data-aos-duration="1500">
//             <RiMoneyDollarBoxFill className="text-iconed" />
//             <LinkItem href="https://www.capgemini.com/">Bonus Portal</LinkItem>
//           </LinkContainer>
//           <LinkContainer data-aos={"zoom-out"} data-aos-duration="1500">
//             <FaRegThumbsUp className="text-iconed" />
//             <LinkItem href="https://www.capgemini.com/">Bounty Portal</LinkItem>
//           </LinkContainer>
//           <LinkContainer data-aos={"zoom-in"} data-aos-duration="1500">
//             <BsFillKeyboardFill className="text-iconed" />
//             <LinkItem href="https://www.capgemini.com/">BPO Intranet</LinkItem>
//           </LinkContainer>
//           <LinkContainer data-aos={"zoom-out"} data-aos-duration="1500">
//             <FiSettings className="text-iconed" />
//             <LinkItem href="https://www.capgemini.com/">BP open App Hub 2.0</LinkItem>
//           </LinkContainer>
//           <LinkContainer data-aos={"zoom-in"} data-aos-duration="1500">
//             <FaChild className="text-iconed" />
//             <LinkItem href="https://www.capgemini.com/">Business Mama</LinkItem>
//           </LinkContainer>
//           <LinkContainer data-aos={"zoom-out"} data-aos-duration="1500">
//             <AiFillHome className="text-iconed" />
//             <LinkItem href="https://www.capgemini.com/">Capgemini Welcome BPO</LinkItem>
//           </LinkContainer>
//           <LinkContainer data-aos={"zoom-in"} data-aos-duration="1500">
//             <BsFillTelephoneFill className="text-iconed" />
//             <LinkItem href="https://www.capgemini.com/">Cisco</LinkItem>
//           </LinkContainer>
//           <LinkContainer data-aos={"zoom-out"} data-aos-duration="1500">
//             <BsStopwatch className="text-iconed" />
//             <LinkItem href="https://www.capgemini.com/">Clarity</LinkItem>
//           </LinkContainer>
//           <LinkContainer data-aos={"zoom-in"} data-aos-duration="1500">
//             <RiBookmarkLine className="text-iconed" />
//             <LinkItem href="https://www.capgemini.com/">Competency Model</LinkItem>
//           </LinkContainer>
//           <LinkContainer data-aos={"zoom-out"} data-aos-duration="1500">
//             <MdOutlineMenuBook className="text-iconed" />
//             <LinkItem href="https://www.capgemini.com/">Corporate Directory</LinkItem>
//           </LinkContainer>
//           <LinkContainer data-aos={"zoom-in"} data-aos-duration="1500">
//             <BsFillBriefcaseFill className="text-iconed" />
//             <LinkItem href="https://www.capgemini.com/">Current Jobs</LinkItem>
//           </LinkContainer>
//           <LinkContainer data-aos={"zoom-out"} data-aos-duration="1500">
//             <BsFillFileTextFill className="text-iconed" />
//             <LinkItem href="https://www.capgemini.com/">Delivery Excellence</LinkItem>
//           </LinkContainer>
//           <LinkContainer data-aos={"zoom-in"} data-aos-duration="1500">
//             <AiFillStar className="text-iconed" />
//             <LinkItem href="https://www.capgemini.com/">Delivery Skills Portal</LinkItem>
//           </LinkContainer>
//           <LinkContainer data-aos={"zoom-out"} data-aos-duration="1500">
//             <FaUsers className="text-iconed" />
//             <LinkItem href="https://www.capgemini.com/">HR</LinkItem>
//           </LinkContainer>
//           <LinkContainer data-aos={"zoom-in"} data-aos-duration="1500">
//             <BiTable className="text-iconed" />
//             <LinkItem href="https://www.capgemini.com/">HR Changes</LinkItem>
//           </LinkContainer>
//           <LinkContainer data-aos={"zoom-out"} data-aos-duration="1500">
//             <FaUsers className="text-iconed" />
//             <LinkItem href="https://www.capgemini.com/">HR Connect</LinkItem>
//           </LinkContainer>
//           <LinkContainer data-aos={"zoom-in"} data-aos-duration="1500">
//             <ImFileText2 className="text-iconed" />
//             <LinkItem href="https://www.capgemini.com/">HR eNate</LinkItem>
//           </LinkContainer>
//           <LinkContainer data-aos={"zoom-out"} data-aos-duration="1500">
//             <TiLightbulb className="text-iconed" />
//             <LinkItem href="https://www.capgemini.com/">iPortal</LinkItem>
//           </LinkContainer>
//           <LinkContainer data-aos={"zoom-in"} data-aos-duration="1500">
//             <BiDesktop className="text-iconed" />
//             <LinkItem href="https://www.capgemini.com/">DGEM</LinkItem>
//           </LinkContainer>
//           <LinkContainer data-aos={"zoom-out"} data-aos-duration="1500">
//             <VscFiles className="text-iconed" />
//             <LinkItem href="https://www.capgemini.com/">Documents for Employees</LinkItem>
//           </LinkContainer>
//           <LinkContainer data-aos={"zoom-in"} data-aos-duration="1500">
//             <FaCarAlt className="text-iconed" />
//             <LinkItem href="https://www.capgemini.com/">Dojazd Capgemini</LinkItem>
//           </LinkContainer>
//         </LinkList>
//       </Page>
//     </>
//   );
// }

// export default EssentialLinks;
