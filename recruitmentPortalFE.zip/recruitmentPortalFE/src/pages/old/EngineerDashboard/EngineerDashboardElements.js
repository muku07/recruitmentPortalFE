import styled from 'styled-components';

//              main container and sign-in sections
export const MainContentCont = styled.div`
display: flex;
width: auto;
height: 200vh;
justify-content: center;
align-items: center;
`;

export const HeaderContainer = styled.div`
position: absolute;
top: 20%
`;

export const Title = styled.h1`
color: #0070ad;
text-align: center;
font-size: 2.5rem;
font-family: "Ubuntu";
`

export const MyProfileCVContainer = styled.div`
position: absolute;
box-shadow: 1px 1px 10px #888888;
:hover{opacity:0.9}
top: 40%;
left: 10%;
width: 55%;
height: 50%;
border: 5px solid #1ecbe1;
border-radius: 20px;
`

export const MyProfileImg = styled.img`
position: relative;
left: 20%;
top: 10%;
max-width: 315px;
`;

export const MyProfileHeader = styled.h2`
background-color: rgba(0, 168, 255, 0.6);
height: 30px;
border-radius: 0px 0px 10px 10px;
position: relative;
top: 14%;
text-align: center;
font-weight: bold;
`;

export const CVUpload = styled.div`
position:relative;
box-shadow: 1px 1px 10px #888888;
:hover{opacity:0.9}
right: -42%;
top: -15%;
width: 50%;
`;

//space for file input


export const UploadButton = styled.button`
position: relative;
left: 60%;
top: -10%;
height: 50px;
width: auto;
padding: 10px;
background: #ffffff;
border-radius: 10px;
border-color: #1ecbe1;
box-shadow: -4px 4px 6px rgba(0,120, 173, 0.5);
cursor: pointer;
font-weight: bold;
font-size: 20px;


&:hover {
    background-color: #abcdef;
}
`;


export const LnDContainer = styled.div`
position: absolute;
box-shadow: 1px 1px 10px #888888;
:hover{opacity:0.9};
top: 40%;
left: 65%;
width: 30%;
height: 50%;
border: 5px solid #1ecbe1;
border-radius: 20px;
`;

export const LnDImg = styled.img`
width: 180px;
`;

export const MyLnDHeader = styled(MyProfileHeader)`
top: 16%;
`;

export const ProjectsContainer = styled.div`
position: absolute;
box-shadow: 1px 1px 10px #888888;
:hover{opacity:0.9};
top: 95%;
left: 10%;
width: 28%;
height: 50%;
border: 5px solid #1ecbe1;
border-radius: 20px;
`;

export const ProjectsHeader = styled(MyProfileHeader)`
top: 17%;
`;

export const ProjectsCont = styled.img`
  width: 250px;
`;

export const CertsContainer = styled.div`
position: absolute;
box-shadow: 1px 1px 10px #888888;
:hover{opacity:0.9};
top: 95%;
left: 38%;
width: 28%;
height: 50%;
box-shadow: 1px 1px 10px #888888;
:hover{opacity:0.9}
border: 5px solid #1ecbe1;
border-radius: 20px;
padding-left: 1px;
padding-right: 1px;
`;

export const CertificationsHeader = styled(MyProfileHeader)`
top: -1%;
`;

/**            Certification */
export const CertTextCont = styled.div`

width: 340px;
height: 280px;
border-radius: 0px 0px 10px 10px;
`;

export const CertCont = styled.img`
  width: 250px;
  `;


export const EssentialsLinksContainer = styled.div`
position: absolute;
box-shadow: 1px 1px 10px #888888;
:hover{opacity:0.9};
top: 95%;
left: 66%;
width: 28%;
height: 50%;
border: 5px solid #1ecbe1;
border-radius: 20px;
`;

export const EssLinkHeader = styled(MyProfileHeader)`
top: 6%;
`;


/**            EssLink */
export const EssLinkTextCont = styled.div`
box-shadow: 1px 1px 10px #888888;
:hover{opacity:0.9}
width: 340px;
height: 280px;
border-radius: 0px 0px 10px 10px;

`;

export const EssLinkCont = styled.img`
  width: 230px;
`;













