import React, { useState, useEffect } from "react";
import imgone from "../../../../assets/user.png";
import AvatarElement from "../../../../components/Avatardyno";
import { BsCameraFill } from "react-icons/bs";

import {
  Page,
  HeadingContainer,
  Heading,
  ProfileDisplayItem,
  Title,
  DisplayCard,
  ProfileData,
  BottomAlign,
  TopAlign,
  ManageBtn,
  InputBox,
  Updatedata,
  ImageUploder,
} from "./MyProfileElements";

function MyProfile() {
  const ImgUpload = ({ onChange, src }) => (
    <>
      <div>
        <AvatarElement imageName={src} for="photo-upload" alt="" />
        <ImageUploder class="btn btn-primary">
          <BsCameraFill>ll</BsCameraFill>&nbsp; &nbsp;Choose Image
          <input
            type="file"
            id="photo-upload"
            onChange={onChange}
            style={{ display: "none" }}
            name="image"
          />
        </ImageUploder>
      </div>
    </>
  );
  const Phone = ({ onChange, value }) => (
    <div className="field">
      <Title htmlFor="phone">
        Phone&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      </Title>
      <InputBox
        id="phone"
        type="text"
        onChange={onChange}
        maxLength="30"
        value={value}
        placeholder="PhoneNumber"
        required
      />
    </div>
  );

  const Department = ({ onChange, value }) => (
    <div className="field">
      <Title htmlFor="department">
        Department&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      </Title>
      <InputBox
        id="department"
        type="text"
        onChange={onChange}
        maxLength="30"
        value={value}
        placeholder="department"
        required
      />
    </div>
  );

  const Designation = ({ onChange, value }) => (
    <div className="field">
      <Title htmlFor="designation">
        Designation&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      </Title>
      <InputBox
        id="designation"
        type="text"
        onChange={onChange}
        maxLength="30"
        value={value}
        placeholder="designation"
        required
      />
    </div>
  );

  const TechRole = ({ onChange, value }) => (
    <div className="field">
      <Title>Technical Role &nbsp;&nbsp;</Title>
      <InputBox
        id="techRole"
        type="text"
        onChange={onChange}
        maxLength="30"
        value={value}
        placeholder="techRole"
        required
      />
    </div>
  );

  const ReportTo = ({ onChange, value }) => (
    <div className="field">
      <Title>
        Reports To&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      </Title>
      <InputBox
        id="reportTo"
        type="text"
        onChange={onChange}
        maxLength="30"
        value={value}
        placeholder="reportTo"
        required
      />
    </div>
  );
  const Profile = ({
    onSubmit,
    src,
    name,
    email,
    phone,
    department,
    designation,
    techRole,
    reportTo,
  }) => (
    <form onSubmit={onSubmit}>
      <div style={{ display: "flex" }}>
        <AvatarElement imageName={src} for="photo-upload" alt="" />

        <TopAlign>
          <div>{name}</div>
          <div>{email}</div>
        </TopAlign>
      </div>
      <ProfileData>
        <BottomAlign>
          <Title>
            Phone&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          </Title>
          {phone}
          <br />
          <Title>Department&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</Title>
          {department}
          <br />
          <Title>Designation&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</Title>
          {designation}
          <br />
          <Title>Technical Role &nbsp;&nbsp;</Title>
          {techRole}
          <br />
          <Title>
            Reports
            To&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          </Title>
          {reportTo}
          <br />
          <br />{" "}
        </BottomAlign>
        <Updatedata type="submit" className="edit">
          Edit Profile{" "}
        </Updatedata>
      </ProfileData>
    </form>
  );

  const Edit = ({ onSubmit, children }) => (
    <form onSubmit={onSubmit}>{children}</form>
  );

  //State for the new accelerator form and errors from uncomplete
  // const normal = require('./UpdateProfilesElements/assets/user.png');

  const [file, setFile] = useState("");
  const [imagePreviewUrl, setImagePreviewUrl] = useState(imgone);
  const uname = "Adam";
  const email = "Adam@gmail.com";
  const [phone, setPhone] = useState("7586666159");
  const [department, setDepartment] = useState("Financial Services");
  const [designation, setDesignation] = useState("Consultant");
  const [techRole, setTechRole] = useState("IT");
  const [reportsTo, setReportsTo] = useState("Main");
  const [active, setActive] = useState("profile");
  const [heading, setHeading] = useState("My profile");

  const photoUpload = (e) => {
    e.preventDefault();
    const reader = new FileReader();
    const file = e.target.files[0];
    reader.onloadend = () => {
      setFile(file);
      setImagePreviewUrl(reader.result);
    };
    reader.readAsDataURL(file);
  };

  const editPhone = (e) => {
    const phone = e.target.value;
    setPhone(phone);
  };
  const editdepartment = (e) => {
    const dept = e.target.value;
    setDepartment(dept);
  };
  const editdesignation = (e) => {
    const designation = e.target.value;
    setDesignation(designation);
  };
  const edittechRole = (e) => {
    const techRole = e.target.value;
    setTechRole(techRole);
  };
  const editreportsTo = (e) => {
    const reportTo = e.target.value;
    setReportsTo(reportTo);
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    let activeP = active === "profile" ? "edit" : "profile";
    setActive(activeP);
    if (activeP === "edit") {
      setHeading("Update My Profile");
    } else {
      setHeading("My Profile");
    }
  };
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    let auth = sessionStorage.getItem("role");
    console.log(auth);

    if (auth === "ROLE_ADMIN") {
      setIsAdmin(true);
    }
  }, []);

  return (
    <Page>
      <HeadingContainer>
        <Heading>{heading}</Heading>
      </HeadingContainer>

      {isAdmin && (
        <ManageBtn href="/supervisor/manage">Manage Profile</ManageBtn>
      )}
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <ProfileDisplayItem>
        <DisplayCard>
          {active === "edit" ? (
            <Edit onSubmit={handleSubmit}>
              <div style={{ display: "flex", padding: "8px 0px 0px 50px  " }}>
                {" "}
                <ImgUpload onChange={photoUpload} src={imagePreviewUrl} />
                <TopAlign>
                  <div>{uname}</div>
                  <div>{email}</div>
                </TopAlign>
              </div>
              <ProfileData>
                <BottomAlign>
                  <Phone onChange={editPhone} value={phone} />
                  <Designation onChange={editdesignation} value={designation} />
                  <Department onChange={editdepartment} value={department} />
                  <TechRole onChange={edittechRole} value={techRole} />
                  <ReportTo onChange={editreportsTo} value={reportsTo} />
                </BottomAlign>
                <br />
                <Updatedata type="submit" className="save">
                  Save{" "}
                </Updatedata>
              </ProfileData>
            </Edit>
          ) : (
            <Profile
              onSubmit={handleSubmit}
              src={imagePreviewUrl}
              name={uname}
              email={email}
              phone={phone}
              department={department}
              designation={designation}
              techRole={techRole}
              reportTo={reportsTo}
            />
          )}
        </DisplayCard>
      </ProfileDisplayItem>
    </Page>
  );
}

export default MyProfile;
