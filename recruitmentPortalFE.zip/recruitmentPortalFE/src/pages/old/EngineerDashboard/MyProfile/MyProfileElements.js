import styled from "styled-components";
import { Link, NavLink } from "react-router-dom";
import { Button } from "react-bootstrap";

export const Page = styled.div`
  max-width: 100%;
  width: 100%;
`;

export const HeadingContainer = styled.div`
  height: 150px;
`;

export const ManageBtn = styled(Button)`
  height: 40px;
  background-color: #0070ad;
  top: 3%;
  position: relative;
  width:160px;
  left: 80%;
  border: 2px 2px solid;
  color: #fff;

  border-radius: 10px;

`;

export const Heading = styled.h1`
  text-align: center;
  font-size: 2.5rem;
  color: #0070ad;
  margin-top: 25px;
`;

export const ProfileData = styled.div`
  color: #0070ad;
  font-size: 15px;
  margin: 10px;
  padding: 20px;
`;

export const Title = styled.span`
  color: grey;
  font-size: 15px;
`;

export const Username = styled.span`
  color: grey;
  font-size: 15px;
`;
export const ProfileDisplayItem = styled.div`
  justify-content: center;
  margin-top: 2%;
`;

export const DisplayCard = styled.div`
  background-color: DodgerBlue;
  position: relative;
  left: 50%;
  top: 3%;
  transform: translate(-50%, -50%);
  padding: 15px;
  width: 50%;
  line-height: 20px;
  background: #fff;
  border-radius: 20px;
  border: 2px solid grey;
  box-shadow: 10px 10px 20px 5px lightblue;
`;
export const TopAlign = styled.div`

  color: #0070ad;
  opacity: 1;
  padding: 15px 5px 5px 25px;
  margin: 5px 40px 0px 0px;
  position: relative;
  line-height: 15px;
  font-size: 18px;
`;
export const BottomAlign = styled.div`
  margin: 20px 0px 0px 0px;
`;

export const EditProfile = styled(Link)`
  width: 150px;
  height: 200px;
  line-height: 40px;
  font-size: 12px;
  text-align: center;
  color: #12abdb;
  border-color: #0070ad;
  cursor: pointer;
  &:hover {
    transition: 0.3s;
    color: #1895d9;
  }
`;

export const Updatedata = styled.button`
//  margin: 5px 5px 5px 5px;
  padding: 5px;
  color: #fff;
  background: #0070ad;
  border-radius: 10px;
  border-color: #0070ad;
  box-shadow: 0px 0px 0px rgba(0, 120, 173, 0.5);
  cursor: pointer;
  font-size: 11px;
`;



export const InputBox = styled.input`
  border: 0;
  outline: 0;
  background: transparent;
  border-bottom: 1px solid #0070ad;
  color: #0070ad;
  font-size: 15px;
`;

export const EditButton = styled(NavLink)`
 text-decoration:none;
 position:relative;
 top:20px;
  padding: 5px;
  background: #0070ad;
  color: #fff;
  border: none;
  border-radius: 10px;
  border-color: #1ecbe1;
  box-shadow: -4px 4px 6px rgba(0, 120, 173, 0.5);
  cursor: pointer;
  font-weight: bold;
  font-size: 20px;
`;

 export const EditProfileform = styled.form`
 button {
  position:relative;
  padding: 5px;
  top:20px;
  background: #0070ad;
  color: #fff;
  border: none;
  border-radius: 10px;
  border-color: #1ecbe1;
  box-shadow: -4px 4px 6px rgba(0, 120, 173, 0.5);
  cursor: pointer;
  font-weight: bold;
  font-size: 20px;
}
 
 `;

 export const InputTextName = styled.input`
   font-size: 18px;
   padding: 10px;
   margin: 10px;
   background: papayawhip;
   border: 1px solid #0070ad;
   border-radius: 5px;
   ::placeholder {
     color: palevioletred;
   }
 `;

 export const FormError = styled.div`
  p {
    color: red;
  }
`;

export const ImageUploder = styled.label`
  padding: 5px;
  color: #fff;
  background: #0070ad;
  border-radius: 10px;
  border-color: #0070ad;
  box-shadow: 0px 0px 0px rgba(0, 120, 173, 0.5);
  cursor: pointer;
  font-size: 11px;
  font-family: Ubuntu, "times new roman", times, roman, serif;
  height:30px;
  width:100px;

  
  
  `;

 export const PaddingDiv =styled.div
 ` padding: 5px 5px 5px 5px;
 `;
 