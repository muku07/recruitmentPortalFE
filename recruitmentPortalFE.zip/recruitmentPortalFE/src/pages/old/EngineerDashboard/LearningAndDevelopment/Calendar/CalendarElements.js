import styled from "styled-components";

export const CalendarContainer = styled.div`
  position: absolute;
  top: 50%;
  height: 50vh;
  margin-left: 690px;
  width: auto;
`;

export const Calendar = styled.div`
position: absolute;
top: 55%;
height: 50vh;
width: auto;
`;

export const CalendarText = styled.div`
font-size: 1.5rem;
text-align: center;
color: #000;
padding: 10px;
font-weight: 500;
`;