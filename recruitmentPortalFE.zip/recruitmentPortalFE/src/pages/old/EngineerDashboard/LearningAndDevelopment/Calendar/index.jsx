import React, { useState } from "react";
import Calendar from "react-calendar";
import { CalendarContainer, CalendarText } from "./CalendarElements";
import "react-calendar/dist/Calendar.css";

export default function LearningCalendar() {
  const [value, onChange] = useState(new Date());

  return (
    <CalendarContainer>
      <CalendarText>Upcoming Events and Trainings</CalendarText>
      <Calendar onChange={onChange} value={value} />
    </CalendarContainer>
  );
}
