import styled from "styled-components";

export const LnDPage = styled.div`
  height: 130vh;
  max-width: 100%;
  /* width: auto; */
  background: #fff;

  display: flex;
  justify-content: center;
  // centers in the flex direction and the default flex-direction is row
  align-content: center;
  // centers perpendicular to the flex direction
`;


export const JavaContainer = styled.div`
  position: center;
  top: 20%;
  padding: 10px;
  height: 50vh;
  width: auto;
`;



export const PythonContainer = styled.div`
  position: center;
  top: 20%;
  padding: 10px;
  height: 50vh;
  width: auto;
`;


export const DotNetContainer = styled.div`
  position: center;
  top: 20%;
  padding: 10px;
  height: 50vh;
  width: auto;
`;


export const DevOpsContainer = styled.div`
  position: center;
  top: 20%;
  padding: 10px;
  height: 50vh;
  width: auto;
`;


export const HeadingTitleContainer = styled.div`
  position: absolute;
  top: 18%;
  padding: 10px;
  height: 50vh;
  width: auto;
`;

export const Title = styled.h1`
  color: #0070ad;
  text-align: center;
  font-size: 2rem;
  font-family: "Ubuntu";
`;

export const AboutTextContainer = styled.div`
  position: absolute;
  left: 5%;
  top: 22%;
  height: 50vh;
  width: auto;
`;

export const AboutText = styled.p`
  color: #0070ad;
  text-align: center;
  font-size: 1rem;
  margin: 5pc;
  font-family: "Ubuntu";
`;

export const PillarContainers = styled.div`
  position: absolute;
  left: 10%;
  top: 55%;
  height: 50vh;
  width: auto;
`;

export const PillarGrid = styled.div`
  position: absolute;
  display: grid;
  grid-template-columns: 22% 34% 30% 53%;
  grid-template-rows: 30% 30% 30%;
  grid-column-gap: 20px;
`;

export const JavaImg = styled.img`
  height: 105%;
  min-width: 170px;
  grid-column: 1/4;
  grid-row: 1/4;
  position: absolute;
  background: #ececec;
  border-radius: 20px;
  padding: 12px;

  &:hover {
    background: transparent;
    transform: scale(1.1);
    transition: all 0.2s ease-in-out;
  }
`;

export const DotNetImg = styled.img`
  height: 105%;
  grid-column: 2/4;
  grid-row: 1/4;
  position: absolute;
  background: #ececec;
  border-radius: 20px;
  padding: 12px;
  margin-left: -0.5pc;
  &:hover {
    background: transparent;
    transform: scale(1.1);
    transition: all 0.2s ease-in-out;
  }
`;

export const PythonImg = styled.img`
  height: 105%;
  width: 180px;
  grid-column: 3/4;
  grid-row: 2/4;
  position: absolute;
  background: #ececec;
  border-radius: 20px;
  padding: 12px;
  top: 120%;
  margin-left: -7.5pc;
  &:hover {
    background: transparent;
    transform: scale(1.1);
    transition: all 0.2s ease-in-out;
  }
`;

export const DevOpsImg = styled.img`
  height: 105%;
  grid-column: 4/4;
  grid-row: 2/4;
  position: absolute;
  top: 120%;
  width: 300px;
  margin-left: 2pc;
  background: #ececec;
  border-radius: 20px;
  padding: 12px;

  &:hover {
    background: transparent;
    transform: scale(1.1);
    transition: all 0.2s ease-in-out;
  }
`;

export const SubheadingCont = styled.div`
  text-align: center;
`;

export const SubheadingTitle = styled.h2`
  font-size: 1.5rem;
  font-family: "Ubuntu";
  font-weight: 500;
`;

export const LearningLinkCont = styled.div`
    position: absolute;
    margin-left: 35pc;
    top: 110%;
    height: 30%;
    text-align: center;
    font-size: 150%;
`;

export const LearningLinkGrid = styled.div`
  position: relative;
  margin-left: 5pc;
  display: grid;
  grid-template-columns: 50% 50%;
  grid-template-rows: 45% 50%;
  //This creates the grid in a row and column, columns have different spacing because they are all different sizes
    width: 550px;
    background: #ececec;
    border-radius: 20px;
  grid-row-gap: 8px;

  grid-column-gap: 5px;

  /* grid-template-columns: 1fr 1fr;

  grid-template-rows: 1fr 1fr; */
`;

export const PluralSightImg = styled.img`
  height: 65px;
  grid-column: 1/2;
  grid-row: 1/2;

  border-radius: 20px;
  padding: 10px;

  &:hover {
    transform: scale(1.1);
    transition: all 0.2s ease-in-out;
  }
`;

export const CourseraImg = styled.img`
  height: 55px;
  grid-column: 1/2;
  grid-row: 2/2;

  border-radius: 20px;
  padding: 10px;

  &:hover {
    transform: scale(1.1);
    transition: all 0.2s ease-in-out;
  }
`;

export const Java = styled.div`
  height: 270px;
  position: absolute;
  z-index: 1;
  top: -5%;
  margin-left: -15px;
  width: 200px;
  padding: 10px;
`;

export const Python = styled.div`
    height: 270px;
  position: absolute;
  z-index: 1;
  top: -5%;
  margin-left: -15px;
  width: 200px;
  padding: 10px;
`;

export const DevOps = styled.div`
  height: 270px;
  position: absolute;
  z-index: 1;
  top: -5%;
  padding: 10px;
  margin-left: -17px;
`;


export const DotNet = styled.div`
    height: 270px;
  position: absolute;
  z-index: 1;
  top: -5%;
  width: 200px;
  padding: 10px;
  margin-left: 155px;
`;

export const MyLearningImg = styled.img`
  height: 65px;
  position: relative;
  left: 20%;
  grid-column: 2/2;
  grid-row: 1/2;

  border-radius: 20px;
  padding: 10px;

  &:hover {
    transform: scale(1.1);
    transition: all 0.2s ease-in-out;
  }
`;

export const CapgNextImg = styled.img`
  height: 65px;
  position: relative;
  left: -5%;
  grid-column: 2/2;
  grid-row: 2/2;

  border-radius: 20px;
  padding: 10px;

  &:hover {
    transform: scale(1.1);
    transition: all 0.2s ease-in-out;
  }
`;
