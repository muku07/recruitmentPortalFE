import React, { useState } from "react";
import JavaLogo from "../../../../assets/JavaLogo.svg";
import DotNetLogo from "../../../../assets/DotNetLogo.svg";
import PythonLogo from "../../../../assets/PythonLogo.svg";
import DevopsLogo from "../../../../assets/DevopsLogo.svg";
import PluralsightLogo from "../../../../assets/PluralsightLogo.svg";
import CourseraLogo from "../../../../assets/CourseraLogo.svg";
import MyLearning from "../../../../assets/MyLearning.png";
import CapgeminiNext from "../../../../assets/CapgeminiNext.png";
import JavaPopup from "./Popups/JavaPopup";
import PythonPopup from "./Popups/PythonPopup";
import DevOpsPopup from "./Popups/DevOpsPopup";
import DotNetPopup from "./Popups/DotnetPopup";

import {
  AboutTextContainer,
  AboutText,
  HeadingTitleContainer,
  LnDPage,
  PillarContainers,
  JavaImg,
  Java,
  Title,
  DotNetImg,
  DotNet,
  DotNetContainer,
  PythonImg,
  DevOpsImg,
  DevOpsContainer,
  DevOps,
  PillarGrid,
  SubheadingCont,
  JavaContainer,
  PythonContainer,
  Python,
  SubheadingTitle,
  LearningLinkCont,
  LearningLinkGrid,
  PluralSightImg,
  CourseraImg,
  MyLearningImg,
  CapgNextImg,
} from "./LearningAndDevelopmentElements";
import LearningCalendar from "./Calendar";

function LearnAndDev() {
  const aboutText =
    "This is the MAPII Learning and Development page. We have 4 pillars that cover Java, .NET, Python and DevOps. " +
    "We provide learning materal across these pillars to keep you fully trained. You can find links to training recordings on each pillar. " +
    "There are also links to NEXT and myLearning along with Capgemini partners, such as Coursera and Pluralsight.";
  const pluralRef = "https://learn.pluralsight.com/programs/pluralsight";
  const courseraRef = "https://www.coursera.org/";
  const nextRef = "https://https://degreed.com/dguser86rd0002/dashboard";
  const mylearningRef = "https://mylearning.capgemini.com/";
  function ClickedPluralsight() {
    window.location.assign(pluralRef);
  }
  function ClickedCoursera() {
    window.location.assign(courseraRef);
  }
  function ClickedNext() {
    window.location.assign(nextRef);
  }
  function ClickedMyLearning() {
    window.location.assign(mylearningRef);
  }

  const [isOpen, setIsOpen] = useState(false);

  const togglePopup = () => {
    setIsOpen(!isOpen);
  };

  const [modalOpen, setModalOpen] = useState(false);

  return (
    <LnDPage>
      <HeadingTitleContainer>
        <Title>Learning and Development</Title>
      </HeadingTitleContainer>

      <AboutTextContainer>
        <AboutText>{aboutText}</AboutText>
      </AboutTextContainer>
      <LearningCalendar></LearningCalendar>

      <PillarContainers>
        <PillarGrid>
          <JavaContainer>
            <Java>
              <JavaImg
                src={JavaLogo}
                // src={JavaLogo}
                onClick={() => {
                  setModalOpen(true);
                }}
              ></JavaImg>

              {modalOpen && <JavaPopup setOpenModal={setModalOpen} />}
            </Java>
          </JavaContainer>
          <DotNetContainer>
            <DotNet>
              <DotNetImg
                src={DotNetLogo}
                onClick={() => {
                  setModalOpen(true);
                }}
              ></DotNetImg>

              {modalOpen && <DotNetPopup setOpenModal={setModalOpen} />}
            </DotNet>
          </DotNetContainer>
          <PythonContainer>
            <Python>
              <PythonImg
                src={PythonLogo}
                onClick={() => {
                  setModalOpen(true);
                }}
              ></PythonImg>

              {modalOpen && <PythonPopup setOpenModal={setModalOpen} />}
            </Python>
          </PythonContainer>
          <DevOpsContainer>
            <DevOps>
              <DevOpsImg
                src={DevopsLogo}
                onClick={() => {
                  setModalOpen(true);
                }}
              ></DevOpsImg>

              {modalOpen && <DevOpsPopup setOpenModal={setModalOpen} />}
            </DevOps>
          </DevOpsContainer>
        </PillarGrid>
      </PillarContainers>

      <LearningLinkCont>
        <SubheadingCont>
          <SubheadingTitle>Learning Links</SubheadingTitle>
        </SubheadingCont>
        <LearningLinkGrid>
          <PluralSightImg src={PluralsightLogo} onClick={ClickedPluralsight} />

          <CourseraImg src={CourseraLogo} onClick={ClickedCoursera} />

          <MyLearningImg src={MyLearning} onClick={ClickedMyLearning} />

          <CapgNextImg src={CapgeminiNext} onClick={ClickedNext} />
        </LearningLinkGrid>
      </LearningLinkCont>
    </LnDPage>
  );
}

export default LearnAndDev;
