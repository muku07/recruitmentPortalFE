import React, { useEffect, useState } from "react";
import Task from "../ModalInput/Task";
import Input from "../ModalInput/Input";

import {
  DevOpsModalBackground,
  ModalContainer,
  TitleCloseBtn,
  Title,
  Footer,
  Title2,
  Body,
  AddTopic,
  CloseBtn,
  CancelBtn,
  FooterBtn,
} from "./DevOpsPopupElements.js";
import JavaLogo from "../../../../../../assets/JavaLogo.svg";

function DevOpsPopup({ setOpenModal }) {
  const [tasks, setTasks] = useState([]);

  const taskList = tasks.map((e, i) => (
    <Task
      key={Math.random() * 1000}
      task={e}
      taskIndex={i}
      tasks={tasks}
      setTasks={setTasks}
    />
  ));

  useEffect(() => {
    console.log(tasks);
  }, [tasks, setTasks]);

  return (
    <DevOpsModalBackground>
      <ModalContainer>
        <TitleCloseBtn>
          <CloseBtn
            onClick={() => {
              setOpenModal(false);
            }}
          >
            X
          </CloseBtn>
        </TitleCloseBtn>
        <Title>
          <h1>Trainings</h1>
        </Title>
        <Title2>
          <p>Organise your Recordings!</p>
        </Title2>
        <Body>
          <AddTopic>
            <Input
              placeholder="Add Topic..."
              whatList={2}
              tasks={tasks}
              setTasks={setTasks}
            />
            {taskList}
          </AddTopic>
        </Body>

        <Footer>
          <FooterBtn></FooterBtn>
        </Footer>
      </ModalContainer>
    </DevOpsModalBackground>
  );
}

export default DevOpsPopup;
