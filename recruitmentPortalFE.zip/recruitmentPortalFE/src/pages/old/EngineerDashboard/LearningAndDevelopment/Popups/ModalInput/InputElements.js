import styled from "styled-components";

export const InputText = styled.input`  
 font-size: 18px;

padding: 10px;

margin: 10px;

background: #add8e6;

border: 1px solid #0070ad;

border-radius: 5px;
  `;