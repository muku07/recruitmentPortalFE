import styled from "styled-components";

export const ItemText = styled.input`  
font-size: 15px;

padding: 5px;
width: 300px;

margin: 1px;
font-weight: 600 ;
text-align: center;

background: white;

border: 1px solid #0070ad;

border-radius: 5px;
 `;
