import React from "react";
import {
  PythonModalBackground,
  ModalContainer,
  TitleCloseBtn,
  Title,
  Footer,
  Body,
  CloseBtn,
  CancelBtn,
  FooterBtn,
} from "./PythonPopupElements.js";
import JavaLogo from "../../../../../../assets/JavaLogo.svg";

function PythonPopup({ setOpenModal }) {
  return (
    <PythonModalBackground>
      <ModalContainer>
        <TitleCloseBtn>
          <CloseBtn
            onClick={() => {
              setOpenModal(false);
            }}
          >
            X
          </CloseBtn>
        </TitleCloseBtn>
        <Title>
          <h1>Trainings</h1>
        </Title>
        <Body>
          <p>Organise your Recordings!</p>
        </Body>
        <Footer>
          <CancelBtn
            onClick={() => {
              setOpenModal(false);
            }}
            id="cancelBtn"
          >
            Exit
          </CancelBtn>
          <FooterBtn></FooterBtn>
        </Footer>
      </ModalContainer>
    </PythonModalBackground>
  );
}

export default PythonPopup;
