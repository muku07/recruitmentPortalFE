import React, { useState } from "react";
import { InputText } from "./InputElements.js";
const Input = ({ tasks, setTasks, whatList, placeholder, taskIndex }) => {
  const [inputText, setInputText] = useState("");

  const handleChange = (e) => {
    setInputText(e.target.value);
  };

  const handleEnter = (e) => {
    if (e.keyCode === 13) {
      if (whatList === 1) {
        const newSubtask = {
          id: Math.random(),
          subtaskTitle: inputText,
          isDone: false,
        };

        const taskListCopy = [...tasks];
        taskListCopy[taskIndex].subtask.push(newSubtask);
        setTasks(taskListCopy);
      } else {
        setTasks([
          ...tasks,
          {
            taskTitle: inputText,
            isDone: false,
            desc: "",
            subtask: [],
          },
        ]);
      }
      setInputText("");
    }
  };
  return (
    <InputText
      onChange={handleChange}
      value={inputText}
      onKeyDown={handleEnter}
      placeholder={placeholder}
    />
  );
};

export default Input;
