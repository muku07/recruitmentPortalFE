import styled from "styled-components";


export const PythonModalBackground = styled.div` 
 display: block;
  position: fixed;
  left: 0;
  top: 0;
  justify-content: center;
  align-items: center;
  z-index: 9999;
  width: 100%;
  height: 100%;
  padding-top: 100px;
  background-color: black;
  background-color: rgba(211,211,211, 0.95);
  -webkit-transition: 0.5s;
  overflow: auto;
  transition: all 0.3s linear;
  
  `;

export const ModalContainer = styled.div`  
  background-color: #fefefe;
  margin: auto;
  display: flex;
  flex-direction: column;
  padding: 25px;
  padding: 20px;
  border-radius: 4px;
  max-width: 400px;
  height: 200px;
  `;

export const Title = styled.h1`  
  font-size: 1rem;
  position: relative;
  display: inline-block;
  text-align: center;
  margin-top: 10px;
`;

export const TitleCloseBtn = styled.div`  
  display: flex;
  justify-content: flex-end;
  `;


export const CloseBtn = styled.div`  
  background-color: transparent;
  border: none;
  font-size: 25px;
  cursor: pointer;
  `;

export const Body = styled.div`
  flex: 50%;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 1.7rem;
  text-align: center;
  `;

export const Footer = styled.div`
  flex: 20%;
  display: flex;
  justify-content: center;
  align-items: center;
`;

export const CancelBtn = styled.div`
  font-weight: 800;
  width: 100px;
  height: 45px;
  margin: 10px;
  display: flex;
  justify-content: center;
  align-items: center;
  border: none;
  background-color: cornflowerblue;
  color: white;
  border-radius: 8px;
  font-size: 22px;
  cursor: pointer;
`;


export const FooterBtn = styled.div`

  background-color: crimson;
`;
