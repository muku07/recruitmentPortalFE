import React from "react";
import myProfile from "../../../assets/MyProfile.svg";
import lnd from "../../../assets/LnD.svg";
import projects from "../../../assets/Projects.svg";
import essLink from "../../../assets/EssLink.svg";
import certifications from "../../../assets/certifications.svg";
import { Navigate, useNavigate } from "react-router-dom";
import {
  MainContentCont,
  MyProfileImg,
  MyProfileHeader,
  LnDImg,
  ProjectsCont,
  EssLinkCont,
  CertCont,
  HeaderContainer,
  Title,
  MyProfileCVContainer,
  CVUpload,
  UploadButton,
  LnDContainer,
  ProjectsContainer,
  CertsContainer,
  EssentialsLinksContainer,
  MyLnDHeader,
  ProjectsHeader,
  CertificationsHeader,
  EssLinkHeader,
} from "./EngineerDashboardElements";

function EngineerDashboard() {
  const navigate = useNavigate();

  const ClickedMyProfile = () => {
    // navigate('/home');
  };

  const ClickedLnD = () => {
    navigate("/home");
  };

  const ClickedProjects = () => {
    navigate("/home");
  };

  const ClickedEssLink = () => {
    navigate("/home");
  };

  const ClickedCert = () => {
    navigate("/home");
  };

  // CV attachment

  //------

  const [file, setFile] = React.useState("");

  function handleUpload(event) {
    setFile(event.target.files[0]);
  }

  const handleSubmission = () => {};

  return (
    <>
      <MainContentCont>
        <HeaderContainer>
          <Title>Engineers</Title>
        </HeaderContainer>

        <MyProfileCVContainer>
          <MyProfileImg src={myProfile} />

          <CVUpload>
            <input type="file" onChange={handleUpload} />
            <p>Filename: {file.name}</p>
          </CVUpload>

          <UploadButton onClick={handleSubmission}>Upload</UploadButton>

          <MyProfileHeader>Update your CV</MyProfileHeader>
        </MyProfileCVContainer>

        <LnDContainer>
          {" "}
          <LnDImg src={lnd} />
          <MyLnDHeader>Learning & Development</MyLnDHeader>
        </LnDContainer>

        <ProjectsContainer>
          <ProjectsCont src={projects} />

          <ProjectsHeader>Projects</ProjectsHeader>
        </ProjectsContainer>

        <CertsContainer>
          <CertCont src={certifications} />

          <CertificationsHeader>Certifications</CertificationsHeader>
        </CertsContainer>

        <EssentialsLinksContainer>
          <EssLinkCont src={essLink} />

          <EssLinkHeader>Essential Links</EssLinkHeader>
        </EssentialsLinksContainer>
      </MainContentCont>
    </>
  );
}

export default EngineerDashboard;
