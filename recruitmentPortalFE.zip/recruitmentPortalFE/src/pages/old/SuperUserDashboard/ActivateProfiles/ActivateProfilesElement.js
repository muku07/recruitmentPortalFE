import styled from "styled-components";
import SearchIcon from "../../../../assets/SearchIcon.svg";
import { MdClose } from "react-icons/md";

export const ActivateProfilesPage = styled.div`
  height: 230vh;
  width: 100%;
  display: flex;
  justify-content: center;
  // centers in the flex direction and the default flex-direction is row
  align-content: center;
  // centers perpendicular to the flex direction
`;

//This holds and positions the header
export const MainTitleContainer = styled.div`
  position: absolute;
  top: 140px;
  width: auto;
`;

//The header to style the text – font-family already stated in acc.css
export const MainTitle = styled.h1`
  text-align: center;
  color: #0070ad;
  font-size: 50px;
  font-weight: 600;
`;

export const SearchFormContainer = styled.div`
  position: absolute;
  left: 18%;
  top: 262px;
  height: 50vh;
  width: auto;
  overflow: hidden;
`;

//If you was to have a search container this goes inside the form container - styling of the input
export const SearchInput = styled.input`
  width: 500px;
  border: 1.5px solid #0070ad;
  border-radius: 5px;
  display: block;
  padding: 9px 4px 9px 9px;
  font-size: 14px;
  color: #272936;
  background: transparent url(${SearchIcon}) no-repeat 455px center;
  ::placeholder {
    color: #bbb;
  }
  &:focus {
    box-shadow: 0 0 3px 0 #12abdb;
    border-color: #12abdb;
    outline: none;
  }
`;

export const TopButtonContainer = styled.div`
  position: absolute;
  left: 65%;
  top: 262px;
  height: auto;
  width: auto;

  @media (max-width: 1100px) {
    left: 80%;
  } ;
`;

export const ActivateSelected = styled.button`
  padding: 10px 15px 10px 15px;
  border-radius: 4px;
  border: none;
  background: #003857;
  color: white;
  font-size: 18px;
  text-align: center;
  cursor: pointer;
  opacity: ${({ opacitybtn }) => (opacitybtn ? "0.3" : "1")};
`;

export const MainContentContainer = styled.div`
  display: flex;
  position: absolute;
  left: 16%;
  right: 16%;
  top: 350px;
  width: auto;
`;

export const ReportsToInput = styled.select`
  border: none;
  height: 35px;
  font-size: 16px;

  option {
    color: black;
    background: white;
    display: flex;
    white-space: pre;
  }
`;

export const AssignRoleInput = styled(ReportsToInput)``;

export const ActionButton = styled(ActivateSelected)``;

export const ActivateCheckbox = styled.input``;

//For the whole table
export const STable = styled.table`
  width: 100%;
  border-collapse: collapse;
  text-align: center;
  border-radius: 2px;
  margin-bottom: 200px;
`;

//For the table head
export const STHead = styled.thead`
  position: sticky;
  z-index: 3;
`;

//Table head row
export const STHeadTR = styled.tr`
  background: #0070ad;
`;

//Header for a cell
export const STH = styled.th`
  padding: 8px;
  border: 2px solid;

  font-weight: 600;
  font-size: 18px;
  color: #12abdb;

  p {
    color: black;
  }
`;

//The body of the table
export const STBody = styled.tbody``;

//Table body table rows
export const STBodyTR = styled.tr``;

//This is for the standard cells
export const STD = styled.td`
  padding: 8px;
  border: 2px solid;
  color: #12abdb;

  p {
    color: black;
  }
`;

export const PaginationContainer = styled.div`
  position: absolute;
  bottom: 15px;
`;

//Confirmation modal styling
export const ModalBackground = styled.div`
  position: fixed;
  z-index: 7;
  padding-top: 100px;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  background-color: rgb(0, 0, 0);
  background-color: rgba(0, 0, 0, 0.4);
`;

export const ModalWrapper = styled.div`
  width: 70%;
  height: auto;
  left: 15%;
  box-shadow: 0 5px 16px rgba(0, 0, 0, 0.2);
  background: #12abdb;
  position: relative;
  z-index: 15;
  border-radius: 10px;
  margin-bottom: 100px;
`;

export const ModalContent = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
`;

export const ModalTitle = styled.h1`
  margin-top: 30px;
  margin-bottom: 20px;
  color: #003857;
  font-size: 32px;
  font-weight: 600;
`;

export const ModalText = styled.p`
  margin: 5px 20px 15px 20px;
  color: white;
  font-size: 18px;
  font-weight: 400;
`;

export const ModalSubmitButton = styled.button`
  margin-top: 15px;
  margin-bottom: 20px;
  padding: 10px 15px;
  background: #ececec;
  border-radius: 4px;
  color: #003857;
  font-size: 14px;
  border: none;
  cursor: pointer;
`;

export const CloseModalButton = styled(MdClose)`
  cursor: pointer;
  position: absolute;
  top: 20px;
  right: 20px;
  width: 32px;
  height: 32px;
  padding: 0;
  z-index: 10;
  color: #003857;
`;

export const EntryError = styled.div`
  position: absolute;
  top: 55%;
  p {
    color: red;
    font-weight: bold;
  }
`;

export const ConfirmError = styled.div`
  color: red;
  font-weight: bold;
`;

export const EntryPatch = styled.div`
  color: #0070ad;
  font-weight: bold;
  display: flex;
  flex-direction: row;
  justify-content: space-between;

  p {
    margin-left: 10px;
  }
`;

export const PatchText = styled.div`
  color: #0070ad;
  font-weight: bold;
  margin-left: 10px;
`;
