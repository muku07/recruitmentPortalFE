import React from 'react';
import ActivateProfile from '..';
import { render, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';

//Need to import react as ou are testing a react component
//Import ActivateProfile as thats whats being tested
//Import render as you need to call and render the component(page) in the virtual dom to be tested
//Import expect as you use it to test you get the expected result

// First line calls test function, first param is a string - explanation
// and second param is a function to have the logic for the test

//Render the component in to a const
//Get the element you are testing and assign it to a const

//So component can be access everywhere, before each will run and render to component for each test
let component;

beforeEach(() => {
  component = render(<ActivateProfile />);
});

test('Testing that the page renders', () => {
  render(<ActivateProfile />);
});

test('Testing that the header renders correctly with text', () => {
  const headerElement = component.getByTestId('header');

  expect(headerElement.textContent).toBe('Activate Profile');
});

//Another way of writing the test
test('Testing the search bar will be empty with placeholder and search icon in corner', () => {
  const searchBarElement = component.getByTestId('searchBar');

  expect(searchBarElement.textContent).toBe('');
  expect(searchBarElement.getAttribute('placeholder')).toBe(
    'Employee first name or last name'
  );
  expect(searchBarElement).toHaveStyle(
    'background: transparent url(SearchIcon.svg) no-repeat 455px center'
  );
});

test('Testing the searchbar will store the text', () => {
  const searchBar = component.getByTestId('searchBar');

  fireEvent.change(searchBar, {
    target: {
      value: 'Test',
    },
  });

  expect(searchBar.value).toBe('Test');
});

test('Testing that the Activate selected button renders with text and disabled', () => {
  const ActivateSelectedBtn = component.getByTestId('ActivateSelected');

  expect(ActivateSelectedBtn.textContent).toBe('Activate Selected');
  expect(ActivateSelectedBtn).toHaveAttribute('disabled');
});

test('Testing that the Activate selected button is disabled when clicked on entry to page with opacity', () => {
  const ActivateSelectedBtn = component.getByTestId('ActivateSelected');

  fireEvent.click(ActivateSelectedBtn);

  expect(ActivateSelectedBtn).toBeDisabled;
  expect(ActivateSelectedBtn).toHaveStyle('opacity: 0.3');
});

test('Testing that the Activate selected button is not disabled or have opacity when selectAll checkbox is clicked', () => {
  const activateSelectedBtn = component.getByTestId('ActivateSelected');
  const selectAllCheckbox = component.getByTestId('selectAll');

  fireEvent.click(selectAllCheckbox);

  expect(activateSelectedBtn).not.toBeDisabled();
  expect(activateSelectedBtn).toHaveStyle('opacity: 1');
});

test('Testing that the table is created with the header titles and checkbox in that row', () => {
  const tableElement = component.getByTestId('tableElement');
  const tableHead = component.getByTestId('tableHead');
  const selectAllCheckbox = component.getByTestId('selectAll');

  expect(tableElement).toBeInTheDocument();
  expect(tableHead.textContent).toBe(
    'Employee IDFirst NameLast NameDesignationReports ToAssign RoleAction'
  );
  expect(tableHead.getAttribute('checkbox'));
  expect(selectAllCheckbox).not.toBeChecked();
});

test('Able to select a single checkbox from what is mapped', () => {
  const activateSelectedBtn = component.getByTestId('ActivateSelected');
  const selectCheckbox = component.getByTestId('101');
  const tableBodyRow = component.findByTestId('tableBodyRow');

  fireEvent.click(selectCheckbox);
  expect(selectCheckbox).toBeChecked();
});
