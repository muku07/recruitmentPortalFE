import React, { useState, useRef, useEffect } from "react";
import { useMsal } from "@azure/msal-react";

import {
  ActivateSelected,
  ActivateProfilesPage,
  MainContentContainer,
  MainTitle,
  MainTitleContainer,
  SearchFormContainer,
  SearchInput,
  TopButtonContainer,
  STable,
  STBody,
  STBodyTR,
  STD,
  STH,
  STHead,
  STHeadTR,
  ActionButton,
  ReportsToInput,
  AssignRoleInput,
  ActivateCheckbox,
  ModalBackground,
  ModalWrapper,
  ModalContent,
  ModalTitle,
  ModalText,
  ModalSubmitButton,
  CloseModalButton,
  EntryError,
  ConfirmError,
  EntryPatch,
  PatchText,
  PaginationContainer,
} from "./ActivateProfilesElement";
import { ProfilesApi } from "../../../../Services/API/Utilities/ProfilesAPI";
import { apiProvider } from "../../../../Services/API/Utilities/Provider";

import Pagination from "../../../../components/Pagination";

function ActivateProfile() {
  const [profile, setProfile] = useState([]);
  //First name and lastname is stored here to be run through filter
  const [searchQuery, setSearchQuery] = useState("");
  const [showModal, setShowModal] = useState(false);
  //For the checkbox states and storing selected rows
  const [isChecked, setIsChecked] = useState([]);
  //For holding and showing where fields are not filled
  const [error, setError] = useState("");
  const [patch, setPatch] = useState({
    success: [],
    errors: [],
  });

  const { accounts } = useMsal();
  const checkboxes = document.querySelectorAll("input[type = 'checkbox']");
  const getRolesApi = apiProvider.GetAllApi("roles");
  const getReportsToApi = apiProvider.GetAllApi("reportsto");

  //*****Pagination*****\\
  const [currentPage, setCurrentPage] = useState(1);
  const postsPerPage = 10;

  //Get current posts
  const indexOfLastPost = currentPage * postsPerPage;
  const indexOfFirstPost = indexOfLastPost - postsPerPage;
  const currentPosts = profile.slice(indexOfFirstPost, indexOfLastPost);

  //Change page
  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  useEffect(() => {
    let item = { activateFlag: false };
    ProfilesApi.GetProfilesApi("searchProfiles", item, setProfile);
    getRolesApi.request();
    getReportsToApi.request();
  }, []);

  //.....................functions to handle checkboxes - select all and single

  const handleSelectAll = () => {
    if (document.getElementById("selectAll").checked) {
      setIsChecked(profile.map((emp) => emp));
      checkboxes.forEach(function (checkbox) {
        checkbox.checked = true;
      });
    } else {
      checkboxes.forEach(function (checkbox) {
        setIsChecked([]);
        checkbox.checked = false;
      });
    }
  };

  const handleSelectOne = (emp) => {
    if (document.getElementById(emp.userId).checked) {
      setIsChecked([...isChecked, emp]);
    } else {
      if (!document.getElementById(emp.userId).checked) {
        setIsChecked(isChecked.filter((item) => item.userId !== emp.userId));
      }
    }
  };

  // --------------------------- function to handle Reports To and Assign Role of each row
  function handleChangeReport(e, i) {
    let newArr = [...profile];
    newArr[i].reportsTo = e.target.value;
    setProfile(newArr);
  }

  function handleChangeAssign(e, i) {
    let newArr = [...profile];
    newArr[i].roleId = e.target.value;
    setProfile(newArr);
  }

  //---------------------------- functions to handle submits of single and in the confirmation modal as well as clear the inputs
  const handleSubmitClear = () => {
    Array.from(document.querySelectorAll("select")).forEach(
      (input) => (input.value = 0)
    );

    checkboxes.forEach(function (checkbox) {
      setIsChecked([]);
      checkbox.checked = false;
    });
  };

  function HandleSubmitOneProfile(emp) {
    if (emp.reportsTo === 0) {
      setError(
        `You must provide the Reports To for profile: ` +
          emp.userId +
          " , " +
          emp.firstName +
          " , " +
          emp.lastName
      );
      return;
    }
    setError("");

    const itemLogs = {};
    let item = [
      {
        profileId: emp.userId,
        roleId: emp.roleId,
        reportstoId: emp.reportsTo,
        comments: "Activated by " + accounts[0].idTokenClaims.name,
      },
    ];
    itemLogs["activeProfiles"] = item;
    ProfilesApi.PatchApi("activateProfiles", itemLogs, setPatch);
    handleSubmitClear();
  }

  function HandleSubmitProfiles() {
    for (let i = 0; i < isChecked.length; i++) {
      let emp = isChecked[i];
      if (emp.reportsTo === 0) {
        setError(
          `You must provide the Reports To for profile: ` +
            emp.userId +
            " , " +
            emp.firstName +
            " , " +
            emp.lastName
        );
        return;
      }
      setError("");
    }
    const itemLogs = {}; //Creating an object array
    let tempArr = []; //Creating a temp array for the loop to store each element for array

    for (let i = 0; i < isChecked.length; i++) {
      let item = {
        profileId: isChecked[i].userId,
        roleId: isChecked[i].roleId,
        reportstoId: isChecked[i].reportsTo,
        comments: "Activated by " + accounts[0].idTokenClaims.name,
      };
      tempArr.push(item);
      itemLogs["activeProfiles"] = tempArr;
    }

    ProfilesApi.PatchApi("activateProfiles", itemLogs, setPatch).then(
      checkboxes.forEach(function (checkbox) {
        setIsChecked([]);
        checkbox.checked = false;
      })
    );
    handleSubmitClear();

    setShowModal((prev) => !prev);
  }

  useEffect(() => {
    setIsChecked([]);
    let item = { activateFlag: false };
    ProfilesApi.GetProfilesApi("searchProfiles", item, setProfile);
  }, [patch]);

  const ConfirmationModal = ({ showModal, setShowModal }) => {
    const modalRef = useRef();

    const closeModal = (e) => {
      if (modalRef.current === e.target) {
        setShowModal(false);
      }
    };

    const convertReport = (emp) => {
      try {
        for (let i = 0, l = getReportsToApi.data.length; i < l; i++) {
          if (getReportsToApi.data[i].id === parseInt(emp)) {
            return getReportsToApi.data[i].name;
          }
        }
      } catch (error) {
        console.log(error);
        return "Problem occured";
      }
    };

    const convertRole = (emp) => {
      try {
        for (let i = 0, l = getRolesApi.data.length; i < l; i++) {
          if (getRolesApi.data[i].roleId === parseInt(emp)) {
            return getRolesApi.data[i].userRole;
          }
        }
      } catch (error) {
        console.log(error);
        return "Problem occured";
      }
    };

    return (
      <>
        {showModal ? (
          <ModalBackground ref={modalRef} onClick={closeModal}>
            <ModalWrapper showModal={showModal}>
              <ModalContent>
                <ModalTitle>
                  Confirm the profiles you want to activate
                </ModalTitle>
                <ModalText>Please check before you confirm </ModalText>
                <ModalSubmitButton onClick={() => HandleSubmitProfiles()}>
                  Submit
                </ModalSubmitButton>

                {error && <ConfirmError>{error}</ConfirmError>}

                <STable>
                  <STHead>
                    <STHeadTR>
                      <STH>
                        <p>Profile ID</p>
                      </STH>
                      <STH>
                        <p>First Name</p>
                      </STH>
                      <STH>
                        <p>Last Name</p>
                      </STH>
                      <STH>
                        <p>Designation</p>
                      </STH>
                      <STH>
                        <p>Reports To</p>
                      </STH>
                      <STH>
                        <p>Assign Role</p>
                      </STH>
                    </STHeadTR>
                  </STHead>
                  <STBody>
                    {isChecked.map((emp, i) => (
                      <STBodyTR key={i}>
                        <STD>
                          <p>{emp.userId}</p>
                        </STD>
                        <STD>
                          <p>{emp.firstName}</p>
                        </STD>
                        <STD>
                          <p>{emp.lastName}</p>
                        </STD>
                        <STD>
                          <p>{emp.designationName}</p>
                        </STD>
                        <STD>
                          <p>{convertReport(emp.reportsTo)}</p>
                        </STD>
                        <STD>
                          <p>{convertRole(emp.roleId)}</p>
                        </STD>
                      </STBodyTR>
                    ))}
                  </STBody>
                </STable>
              </ModalContent>
              <CloseModalButton onClick={() => setShowModal((prev) => !prev)} />
            </ModalWrapper>
          </ModalBackground>
        ) : null}
      </>
    );
  };

  const openModal = () => {
    setShowModal((prev) => !prev);
  };

  return (
    <>
      <ActivateProfilesPage>
        <MainTitleContainer>
          <MainTitle data-testid="header">Activate Profile</MainTitle>
        </MainTitleContainer>

        <SearchFormContainer>
          <SearchInput
            data-testid="searchBar"
            type="search"
            value={searchQuery}
            placeholder="Employee first name or last name"
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </SearchFormContainer>

        <TopButtonContainer>
          <ActivateSelected
            data-testid="ActivateSelected"
            disabled={isChecked.length === 0 ? true : false}
            opacitybtn={isChecked.length === 0 ? true : null}
            onClick={openModal}
          >
            Activate Selected
          </ActivateSelected>
        </TopButtonContainer>
        {error && !showModal && (
          <EntryError>
            <p>{error}</p>
          </EntryError>
        )}

        {patch.success.length > 0 && (
          <EntryPatch>
            <p>The successful are profile activation id:</p>
            {patch.success.map((pat, i) => (
              <PatchText key={i}>{pat},</PatchText>
            ))}
          </EntryPatch>
        )}

        {patch.errors.length > 0 && (
          <EntryPatch>
            <p>The errors on profile activation are:</p>
            {patch.errors.map((pat, i) => (
              <PatchText key={i}>{pat},</PatchText>
            ))}
          </EntryPatch>
        )}

        <MainContentContainer>
          <STable data-testid="tableElement">
            <STHead data-testid="tableHead">
              <STHeadTR>
                <STH>
                  <ActivateCheckbox
                    data-testid="selectAll"
                    type="checkbox"
                    name="selectAll"
                    id="selectAll"
                    onChange={(e) => handleSelectAll(e)}
                  ></ActivateCheckbox>
                </STH>
                <STH>
                  <p>Profile Id</p>
                </STH>
                <STH>
                  <p>First Name</p>
                </STH>
                <STH>
                  <p>Last Name</p>
                </STH>
                <STH>
                  <p>Designation</p>
                </STH>
                <STH>
                  <p>Reports To</p>
                </STH>
                <STH>
                  <p>Assign Role</p>
                </STH>
                <STH>
                  <p>Action</p>
                </STH>
              </STHeadTR>
            </STHead>
            <STBody data-testid="tableBody">
              {currentPosts
                .filter((emp) => {
                  if (searchQuery === "") {
                    return emp;
                  } else if (
                    emp.firstName
                      .toLowerCase()
                      .includes(searchQuery.toLowerCase())
                    // && emp.LastName.toLowerCase().includes(searchQuery.toLowerCase())
                  ) {
                    return emp;
                  } else if (
                    emp.lastName
                      .toLowerCase()
                      .includes(searchQuery.toLowerCase())
                  ) {
                    return emp;
                  }
                  return null;
                })
                .map((emp, i) => (
                  <STBodyTR key={i} data-testid="tableBodyRow">
                    <STD>
                      <ActivateCheckbox
                        data-testid={emp.profileId}
                        type="checkbox"
                        id={emp.userId}
                        onChange={() => handleSelectOne(emp)}
                      ></ActivateCheckbox>
                    </STD>
                    <STD>
                      <p>{emp.userId}</p>
                    </STD>
                    <STD>
                      <p>{emp.firstName}</p>
                    </STD>
                    <STD>
                      <p>{emp.lastName}</p>
                    </STD>
                    <STD>
                      <p>{emp.designationName}</p>
                    </STD>
                    <STD>
                      <ReportsToInput
                        name="reportsTo"
                        onChange={(e) => handleChangeReport(e, i)}
                      >
                        <option value="0" hidden>
                          Reports to
                        </option>
                        {getReportsToApi.data?.map((report, i) => (
                          <option key={i} value={report.id}>
                            {report.name}
                          </option>
                        ))}
                      </ReportsToInput>
                    </STD>
                    <STD>
                      <AssignRoleInput
                        name="roleId"
                        onChange={(e) => handleChangeAssign(e, i)}
                      >
                        <option value="0" hidden>
                          ROLE_USER
                        </option>
                        {getRolesApi.data?.map((role, i) => (
                          <option key={i} value={role.roleId}>
                            {role.userRole}
                          </option>
                        ))}
                      </AssignRoleInput>
                    </STD>
                    <STD>
                      <ActionButton
                        onClick={(e) => HandleSubmitOneProfile(emp, e)}
                      >
                        Activate profile
                      </ActionButton>
                    </STD>
                  </STBodyTR>
                ))}
            </STBody>
          </STable>
          <PaginationContainer>
            <Pagination
              postsPerPage={postsPerPage}
              totalPosts={profile.length}
              paginate={paginate}
            />
          </PaginationContainer>
        </MainContentContainer>
        <ConfirmationModal showModal={showModal} setShowModal={setShowModal} />
      </ActivateProfilesPage>
    </>
  );
}

export default ActivateProfile;
