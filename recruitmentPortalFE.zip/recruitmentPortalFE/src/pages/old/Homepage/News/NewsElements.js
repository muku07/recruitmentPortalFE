import styled from "styled-components";

export const NewsPage = styled.div`
  height: 200vh;
  overflow: hidden;
  max-width: 100%;
  background: #fff;
  display: flex;
  justify-content: center;
  margin: 0 auto;
`;

export const HeadingContainer = styled.div`
  position: absolute;
  top: 12%;
  padding: 10px;
`;
export const PageContainer = styled.div`
  position: absolute;
  top: 20%;
  padding: 10px;
  align-items: center;
`;

export const NewsTitle = styled.h1`
  font-family: "Ubuntu";
  font-style: normal;
  font-weight: 700;
  font-size: 28px;
  line-height: 44px;
  text-align: center;

  color: #0070ad;
`;

export const NewsCards = styled.div`
  padding-top: 20px;
  display: block;
  gap: 20px 0px;
`;
export const NewsCard = styled.div`
  margin: 15px;
  background-color: #f3f3f3;
  border-radius: 15px;
  box-shadow: -4px 4px 6px rgba(0, 0, 0, 0.1);
  width: 758px;
  height: 165px;

  color: #fff;
`;
export const NewsImg = styled.img`
  width: 190px;
  left: 0;
  top: 0;
  display: block;
  border-radius: 15px 0px 0px 15px;
`;
export const NewsDetails = styled.div`
  padding: 20px 10px;
`;
export const NewsH3 = styled.h3`
  font-family: "Ubuntu";
  color: #000000;
  font-weight: 600;
  font-size: 20px;
  margin: 10px 0 15px 0;
`;
export const NewsP = styled.p`
  font-family: "Ubuntu";
  color: #808080;
  font-size: 15px;
  line-height: 30px;
  font-weight: 400;
`;

export const NewsContent = styled.div`
  display: grid;
  width: 100%;
  grid-template-columns: 190px 1fr;
`;

export const BCont = styled.div`
  width: 785px;
  height: 300px;
  background: #f3f3f3;
  grid-template-columns: 500px 1fr;
  border-radius: 5px;
`;

export const BImg = styled.img`
  height: 300px;
  position: relative;
  border-radius: 5px 0px 0px 5px;
`;

export const BTitleContainer = styled.div`
  position: absolute;
  top: 80px;
  text-align: right;
  right: 20px;
  width: 723px;
`;

export const BTitle = styled.p`
  overflow-wrap: break-word;
  inline-size: 450px;
  text-align: right;
  font-size: 30px;
  font-weight: 700;
  color: white;
`;
export const GoButton = styled.img`
  width: 36px;
  height: 36px;
  bottom: 8px;
  right: 16px;
  /* margin-left: 215px; */
`;

export const TestTitle = styled.mask`
  font-family: "Ubuntu";
  font-style: normal;
  font-weight: 700;
  background-color: white;
  font-size: 40px;
`;

export const ArticleButton = styled.div`
  height: 56px;
  width: 36px;
  padding-top: 10px;
  padding-left: 0px;
  padding-bottom: 10px;
`;

export const BannerButton = styled.div`
  padding: 10px;
  width: 56px;
  height: 56px;
  float: right;
  margin: 10px;
`;
