import {
  ArticleBanner,
  ArticleDetails,
  ArticleEntry,
  ArticleFooter,
  ArticleHead,
  ArticlePage,
  ArticleText,
  ArticleTitle,
  TextPlacement,
  DetailsEntry,
  BackButton,
  Back,
  CardH3,
  ShareGrid,
} from "./ArticleElements";

import { Helmet } from "react-helmet";

import back from "../../../../../assets/button.svg";

import { Link } from "react-router-dom";

function Article() {
  return (
    <>
      {" "}
      <Helmet>
        <script
          type="text/javascript"
          src="https://s0.assets-yammer.com/assets/platform_social_buttons.min.js"
        ></script>
        <script type="text/javascript">yam.platform.yammerShare();</script>
        <script
          async
          src="https://platform.twitter.com/widgets.js"
          charset="utf-8"
        ></script>
        <script
          src="https://platform.linkedin.com/in.js"
          type="text/javascript"
        >
          lang: en_US
        </script>
        <script type="IN/Share" data-url="https://www.linkedin.com"></script>
      </Helmet>
      <ArticlePage>
        <BackButton>
          <Link to={"/news"}>
            <Back src={back} />
          </Link>
        </BackButton>
        <ArticleHead>
          <ArticleBanner>
            <TextPlacement>
              <ArticleTitle>
                This is an article title about how articles have titles
              </ArticleTitle>
            </TextPlacement>
          </ArticleBanner>
          <ArticleDetails>
            <TextPlacement>
              <DetailsEntry>Published by Tom Jones</DetailsEntry>
            </TextPlacement>
          </ArticleDetails>
          <ArticleText>
            <ArticleEntry>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin non
              aliquet lacus, in maximus ligula. In sed libero nec elit varius
              tempus sit amet in felis. Sed at scelerisque velit, feugiat
              malesuada diam. Praesent consectetur, orci id sollicitudin
              dapibus, nibh enim feugiat felis, a convallis libero erat vel
              dolor. Phasellus commodo imperdiet ultricies. Proin id ex blandit,
              finibus lacus id, feugiat lacus. Sed a sagittis magna. Ut bibendum
              sodales dapibus. Morbi egestas fringilla tristique. Etiam in
              blandit mauris. Quisque id nulla vel ligula ornare efficitur ut
              commodo massa. Pellentesque convallis lacinia dui non ultrices. In
              commodo nulla vel mi lobortis commodo. <br />
              Aliquam a viverra velit. Orci varius natoque penatibus et magnis
              dis parturient montes, nascetur ridiculus mus. Aenean luctus massa
              at nunc lacinia laoreet. Donec ante magna, egestas non dolor
              vitae, porttitor viverra mauris. Nunc et sollicitudin tortor, sed
              mollis nibh. Aliquam non congue massa. Donec pharetra tristique
              varius. Maecenas libero ipsum, tincidunt a varius quis, bibendum
              at velit. Suspendisse potenti. In porta elit est. Nulla pharetra
              tortor ac est molestie, vitae venenatis sem ornare. Aenean
              imperdiet diam rhoncus, dictum tortor ac, sagittis ligula. Aliquam
              et euismod diam, condimentum viverra ligula. Nam consectetur diam
              dolor, in consequat tellus mollis vel.
              <br />
              Aliquam a viverra velit. Orci varius natoque penatibus et magnis
              dis parturient montes, nascetur ridiculus mus. Aenean luctus massa
              at nunc lacinia laoreet. Donec ante magna, egestas non dolor
              vitae, porttitor viverra mauris. Nunc et sollicitudin tortor, sed
              mollis nibh. Aliquam non congue massa. Donec pharetra tristique
              varius. Maecenas libero ipsum, tincidunt a varius quis, bibendum
              at velit. Suspendisse potenti. In porta elit est. Nulla pharetra
              tortor ac est molestie, vitae venenatis sem ornare. Aenean
              imperdiet diam rhoncus, dictum tortor ac, sagittis ligula. Aliquam
              et euismod diam, condimentum viverra ligula. Nam consectetur diam
              dolor, in consequat tellus mollis vel.
            </ArticleEntry>
            <CardH3>Read more!</CardH3>
            <ArticleFooter>
              <ShareGrid>
                <span id="yj-share-button"></span>
                <a
                  href="https://twitter.com/share?ref_src=twsrc%5Etfw"
                  class="twitter-share-button"
                  data-text="MAPII Capability News: "
                  data-hashtags="Capgemini"
                  data-show-count="false"
                  style={{ marginLeft: 2 }}
                >
                  Tweet
                </a>
                <a href="https://api.linkedin.com/v2/ugcPosts"></a>
              </ShareGrid>
            </ArticleFooter>
          </ArticleText>
        </ArticleHead>
      </ArticlePage>
    </>
  );
}
export default Article;
