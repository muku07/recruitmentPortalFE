import styled from "styled-components";

export const ArticleHead = styled.div``;

export const ArticlePage = styled.div`
  height: 200vh;
  overflow: hidden;
  max-width: 100%;
  background: #fff;
  display: flex;
  justify-content: center;
  margin: 0 auto;
`;
export const ArticleBanner = styled.div`
  background-image: url("https://s.marketwatch.com/public/resources/images/MW-GY798_LAUGH_ZG_20181119215830.jpg");
  margin-top: 89px;
  width: 758px;
  height: 300px;
`;

export const ArticleText = styled.div`
  margin-top: 60px;
  position: absolute;
  width: 758px;
  height: 500px;
`;

export const ArticleDetails = styled.div`
  position: absolute;
  width: 758px;
  height: 60px;
`;

export const ArticleFooter = styled.div`
  position: absolute;
  margin: auto;
  padding-left: 340px;
  width: 768px;
  height: 100px;
`;

export const ArticleTitle = styled.mask`
  font-family: "Ubuntu";
  font-style: normal;
  font-weight: 700;
  background-color: white;
  font-size: 40px;
`;

export const ArticleEntry = styled.p`
  font-family: "Ubuntu";
  font-style: normal;
  font-weight: 300;
  font-size: 20px;
  text-align: justify;
  text-justify: inter-word;
  ::first-letter {
    text-transform: uppercase;
    font-size: 60px;
    font-family: "Ubuntu";
    font-style: normal;
  }
`;

export const DetailsEntry = styled.p`
  font-family: "Ubuntu";
  font-style: normal;
  font-weight: 500;
  font-size: 15px;
`;

export const TextPlacement = styled.div`
  padding-top: 20px;
  padding-left: 20px;
`;
export const BackButton = styled.div`
  height: 56px;
  width: 36px;
  padding-top: 10px;
  padding-left: 0px;
  padding-bottom: 10px;
  margin-top: 20px;
`;

export const Back = styled.img`
  width: 36px;
  height: 36px;
  bottom: 8px;
  right: 16px;
  transform: rotate(180deg);
  /* margin-left: 215px; */
`;

export const CardH3 = styled.h3`
  text-align: center;
  font-family: "Ubuntu";
  color: #0070ad;
  font-weight: 600;
  font-size: 20px;
  margin: 10px 0 15px 0;
`;

export const ShareGrid = styled.div`
  margin: auto;
  display: inline-grid;
  grid-template-rows: 26px 25px;
  padding: 10px;
  background-color: #f3f3f3;
  border-radius: 15px 15px 15px 15px;

  background-color: #e8e8e8;
  :hover {
    opacity: 0.5;
    background-color: #f3f3f3;
  }
`;
