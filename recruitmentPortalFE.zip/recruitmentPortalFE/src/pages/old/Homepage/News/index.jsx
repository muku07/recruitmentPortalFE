import {
  HeadingContainer,
  NewsCard,
  NewsDetails,
  NewsH3,
  NewsP,
  NewsImg,
  NewsPage,
  NewsTitle,
  PageContainer,
  NewsContent,
  BCont,
  BImg,
  BTitleContainer,
  GoButton,
  TestTitle,
  ArticleButton,
  BannerButton,
} from "./NewsElements";

import { useState } from "react";

import { Link } from "react-router-dom";

import GoB from "../../../../assets/button.svg";
import CardImage from "../../../../assets/newscard.jpg";

function News() {
  const initialArticle = [
    {
      id: 1,
      title: "First title",
      description: "lorem ipsum lorem ipsum",
      author: "Tom Jones",
      content: "a very very long paragraph",
    },
    {
      id: 2,
      title: "Second title",
      description: "lorem ipsum lorem ipsum",
      author: "Tom Jones",
      content: "a very very long paragraph",
    },
    {
      id: 3,
      title: "First title",
      description: "lorem ipsum lorem ipsum",
      author: "Tom Jones",
      content: "a very very long paragraph",
    },
    {
      id: 4,
      title: "First title",
      description: "lorem ipsum lorem ipsum",
      author: "Tom Jones",
      content: "a very very long paragraph",
    },
  ];

  const [article, setArticle] = useState(initialArticle);

  return (
    <>
      <NewsPage>
        <HeadingContainer>
          <NewsTitle> News </NewsTitle>
        </HeadingContainer>

        <PageContainer>
          <BCont>
            <BImg src="https://s.marketwatch.com/public/resources/images/MW-GY798_LAUGH_ZG_20181119215830.jpg" />
            <BTitleContainer>
              <TestTitle>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec
                a.
              </TestTitle>
              <br />
              <BannerButton>
                <Link to={"/news/article"}>
                  <GoButton src={GoB} />
                </Link>
              </BannerButton>
            </BTitleContainer>
          </BCont>
          {article.map((data, id) => {
            return (
              <NewsCard key={id}>
                <NewsContent>
                  <NewsImg src={CardImage}></NewsImg>
                  <NewsDetails>
                    <NewsH3>{data.title}</NewsH3>
                    <NewsP>{data.description}</NewsP>
                    <ArticleButton>
                      <Link to={"/news/article"}>
                        <GoButton src={GoB} />
                      </Link>
                    </ArticleButton>
                  </NewsDetails>
                </NewsContent>
              </NewsCard>
            );
          })}
        </PageContainer>
      </NewsPage>
    </>
  );
}

export default News;
