import React, { useState, useRef, useEffect, useCallback } from "react";
import {
  EngineersHeading,
  EngineersPage,
  ProfileButtonNext,
  ProfileCont,
  ProfileItem,
  ProfileButtonPrev,
  ProfileScrollCont,
  ProfileName,
  TitleName,
  ManageBtn,
  ProfileDisplayItem,
  ModalFindOutButton,
  ModalFindOutBackground,
  ModalFindOutModalWrapper,
  ModalFindOutModalContent,
  ModalFindOutCloseModalButton,
  FindOutMoreModalName,
  FindOutMoreModalJob,
  FindOutMoreModalDep,
  FindOutMoreModalGrade,
  FindOutMoreModalReports,
  FindOutMoreModalEmail,
  FindOutMoreModalNumber,
  FindOutMoreModalQualifications,
  FindOutMoreModalSkills,
  FindOutMoreModalLinks,
  FindOutMoreModalCV,
  FindOutMoreModalCont1,
  FindOutMoreModalCont2,
  FindOutMoreModalCont3,
  FindOutMoreModalCont4,
  FilterButton,
  AvatarCont,
  FilterTitlesCont,
  FilterPopupCont,
  FilterPopupButton,
  SearchInput,
  FilterSearchBarsCont,
  FilterModalBackground,
  FilterModalWrapper,
  FilterModalContent,
  FilterCloseModalButton,
  FilterApplyModalButton,
  FilterModalHeader,
  FilterTitles,
  FilterButtonTitle,
} from "./EngineerProfilesElements";
import AvatarElement from "../../../../components/Avatar";

import { VscSearch } from "react-icons/vsc";
import { ImFilter } from "react-icons/im";

const currentProfile = [
  {
    name: "Name 1",
    desgination: "Data Engineer",
    picture: "",
    reportsTo: "Jane",
    grade: "D",
    department: "Financial Services",
    email: "name1@mail.com",
    number: "0000000",
  },
  {
    name: "Name 2",
    desgination: "Software Engineer",
    picture: "",
    reportsTo: "John",
    grade: "A",
    department: "Financial Services",
    email: "name2@mail.com",
    number: "0000000",
  },
  {
    name: "Name 3",
    desgination: "Cloud Engineer",
    picture: "",
    reportsTo: "Jane",
    grade: "C",
    department: "Financial Services",
    email: "name3@mail.com",
    number: "0000000",
  },
  {
    name: "Name 4",
    desgination: "Senior Manager",
    picture: "",
    reportsTo: "John",
    grade: "B",
    department: "Financial Services",
    email: "name4@mail.com",
    number: "0000000",
  },
  {
    name: "Name 5",
    desgination: "Data Engineer",
    picture: "",
    reportsTo: "Jane",
    grade: "D",
    department: "Financial Services",
    email: "name5@mail.com",
    number: "0000000",
  },
  {
    name: "Name 6",
    desgination: "Software Engineer",
    picture: "",
    reportsTo: "John",
    grade: "A",
    department: "Financial Services",
    email: "name6@mail.com",
    number: "0000000",
  },
  {
    name: "Name 7",
    desgination: "Data Engineer",
    picture: "",
    reportsTo: "Jane",
    grade: "D",
    department: "Financial Services",
    email: "name7@mail.com",
    number: "0000000",
  },
  {
    name: "Name 8",
    desgination: "Software Engineer",
    picture: "",
    reportsTo: "John",
    grade: "A",
    department: "Financial Services",
    email: "name8@mail.com",
    number: "0000000",
  },
  {
    name: "Name 9",
    desgination: "Data Engineer",
    picture: "",
    reportsTo: "Jane",
    grade: "D",
    department: "Financial Services",
    email: "name9@mail.com",
    number: "0000000",
  },
  {
    name: "Name 10",
    desgination: "Software Engineer",
    picture: "",
    reportsTo: "John",
    grade: "A",
    department: "Financial Services",
    email: "name10@mail.com",
    number: "0000000",
  },
];

function EngineerProfiles() {
  //This saves the profiles from backend
  const [profile, setProfile] = useState(currentProfile);

  //the filter modal and the search box input
  const [showModal, setShowModal] = useState(false);
  const [searchText, setSearchText] = useState("");

  //Handles the onChange of the search input
  const handleChange = (value, key) => {
    const lowercasedValue = value.toLowerCase().trim();
    setSearchText(lowercasedValue, key);
    console.log(searchText);
  };

  //This is for filter open and close
  const openModalFilterMore = () => {
    setShowModal((prev) => !prev);
    console.log(profile);
  };

  //For the scrolling of the profiles
  const ref = useRef(null);
  const scroll = (scrollOffset) => {
    ref.current.scrollLeft += scrollOffset;
  };

  //This modal open state is for the more info modal and selected employee state saves info to pass into that modal
  const [showModalFilter, setShowModalFilter] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState("");

  //This function is for the find out more modal
  const openModalFilter = (person) => {
    setSelectedEmployee(person);
    setShowModalFilter((prev) => !prev);
  };

  //Modal code starts here, the employee  is being passed into the modal per map
  const FindOutMoreModal = ({
    showModalFilter,
    setShowModalFilter,
    employee,
  }) => {
    //Ref is for the clicking outside main content
    const findOutModalRef = useRef();

    const closeFindOutModal = (e) => {
      if (findOutModalRef.current === e.target) {
        setShowModalFilter(false);
      }
    };

    const keyPress = useCallback(
      (e) => {
        if (e.key === "Escape" && showModalFilter) {
          setShowModalFilter(false);
        }
      },
      [setShowModalFilter, showModalFilter]
    );

    useEffect(() => {
      document.addEventListener("keydown", keyPress);
      return () => document.removeEventListener("keydown", keyPress);
    }, [keyPress]);

    return (
      <>
        {showModalFilter ? (
          <ModalFindOutBackground
            onClick={closeFindOutModal}
            ref={findOutModalRef}
          >
            <ModalFindOutModalWrapper showModalFilter={showModalFilter}>
              <ModalFindOutModalContent>
                <FindOutMoreModalCont1>
                  <AvatarCont>
                    <AvatarElement />
                  </AvatarCont>
                  <FindOutMoreModalName>{employee.name}</FindOutMoreModalName>
                </FindOutMoreModalCont1>

                <FindOutMoreModalCont2>
                  <FindOutMoreModalJob>
                    Job Role: {employee.desgination}
                  </FindOutMoreModalJob>
                  <FindOutMoreModalDep>
                    Department: {employee.department}
                  </FindOutMoreModalDep>
                  <FindOutMoreModalGrade>
                    Grade: {employee.grade}
                  </FindOutMoreModalGrade>
                  <FindOutMoreModalReports>
                    Reports to: {employee.reportsTo}
                  </FindOutMoreModalReports>
                </FindOutMoreModalCont2>

                <FindOutMoreModalCont3>
                  <FindOutMoreModalEmail>
                    e-Mail: {employee.email}
                  </FindOutMoreModalEmail>
                  <FindOutMoreModalNumber>
                    Number: {employee.number}
                  </FindOutMoreModalNumber>
                  <FindOutMoreModalLinks>Links:</FindOutMoreModalLinks>
                </FindOutMoreModalCont3>

                <FindOutMoreModalCont4>
                  <FindOutMoreModalQualifications>
                    Qualifications:
                  </FindOutMoreModalQualifications>
                  <FindOutMoreModalSkills>Skills:</FindOutMoreModalSkills>
                  <FindOutMoreModalCV>CV:</FindOutMoreModalCV>
                </FindOutMoreModalCont4>
              </ModalFindOutModalContent>
              <ModalFindOutCloseModalButton
                aria-label="Close modal"
                onClick={() => setShowModalFilter((prev) => !prev)}
              />
            </ModalFindOutModalWrapper>
          </ModalFindOutBackground>
        ) : null}
      </>
    );
  };
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    let auth = sessionStorage.getItem("role");

    console.log(auth);

    if (auth === "ROLE_ADMIN") {
      setIsAdmin(true);
    }
  }, []);
  return (
    <>
      <EngineersPage>
        {isAdmin && (
          <ManageBtn href="/supervisor/manage">Manage Profile</ManageBtn>
        )}
        <FilterTitlesCont>
          <FilterTitles>Name</FilterTitles>
          <FilterTitles>Job Role</FilterTitles>
          <FilterTitles>Department</FilterTitles>
          <FilterTitles>Grade</FilterTitles>
          <FilterTitles>Email</FilterTitles>
          <FilterTitles>Skills</FilterTitles>
        </FilterTitlesCont>
        <FilterSearchBarsCont>
          <SearchInput
            type="text"
            placeholder="Name"
            value={searchText.name}
            onChange={(e) => handleChange(e.target.value, e.target.key)}
            key="name"
            title="maria"
          />

          <SearchInput
            type="text"
            placeholder="Job Role"
            value={searchText.job}
            onChange={(e) => handleChange(e.target.value)}
          />
          <SearchInput
            type="text"
            placeholder="Department"
            value={searchText.department}
            onChange={(e) => handleChange(e.target.value)}
          />
          <SearchInput
            type="text"
            placeholder="Grade"
            value={searchText.grade}
            onChange={(e) => handleChange(e.target.value)}
          />
          <SearchInput
            type="text"
            placeholder="Email"
            value={searchText.email}
            onChange={(e) => handleChange(e.target.value)}
          />
          <SearchInput
            type="text"
            placeholder="Skills"
            value={searchText.skills}
            onChange={(e) => handleChange(e.target.value)}
          />
          <FilterButton>
            <FilterButtonTitle>Search</FilterButtonTitle>
          </FilterButton>
        </FilterSearchBarsCont>

        <EngineersHeading>Engineer Profiles</EngineersHeading>
        <ProfileScrollCont>
          <ProfileButtonPrev onClick={() => scroll(-350)}></ProfileButtonPrev>
          <ProfileButtonNext onClick={() => scroll(350)}></ProfileButtonNext>
        </ProfileScrollCont>

        <ProfileCont ref={ref}>
          {profile
            .filter((profile) => {
              if (searchText === "") {
                return profile;
              } else {
                return Object.keys(profile).some((key) =>
                  profile[key].toString().toLowerCase().includes(searchText)
                );
              }
              return null;
            })
            .map((profile, i) => (
              <ProfileItem key={i}>
                <ProfileName>
                  {profile.name}{" "}
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 1440 320"
                  >
                    <path
                      fill="#a2d9ff"
                      fillOpacity="1"
                      d="M0,64L30,90.7C60,117,120,171,180,165.3C240,160,300,96,360,112C420,128,480,224,540,218.7C600,213,660,107,720,85.3C780,64,840,128,900,144C960,160,1020,128,1080,106.7C1140,85,1200,75,1260,85.3C1320,96,1380,128,1410,144L1440,160L1440,0L1410,0C1380,0,1320,0,1260,0C1200,0,1140,0,1080,0C1020,0,960,0,900,0C840,0,780,0,720,0C660,0,600,0,540,0C480,0,420,0,360,0C300,0,240,0,180,0C120,0,60,0,30,0L0,0Z"
                    ></path>
                  </svg>
                </ProfileName>
                <AvatarElement />
                <ProfileDisplayItem>
                  <TitleName>
                    Job Title&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </TitleName>
                  {profile.desgination}
                </ProfileDisplayItem>
                <ProfileDisplayItem>
                  <TitleName>Reports To&nbsp;</TitleName>
                  {profile.reportsTo}
                </ProfileDisplayItem>
                <ProfileDisplayItem>
                  {" "}
                  <TitleName>
                    Grade&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </TitleName>
                  {profile.grade}
                </ProfileDisplayItem>
                <ProfileDisplayItem>
                  <TitleName>Department&nbsp;&nbsp;&nbsp;</TitleName>
                  {profile.department}
                </ProfileDisplayItem>

                <ModalFindOutButton onClick={() => openModalFilter(profile)}>
                  {" "}
                  Find out more
                </ModalFindOutButton>
                <br />
              </ProfileItem>
            ))}
        </ProfileCont>
      </EngineersPage>
      <FindOutMoreModal
        employee={selectedEmployee}
        showModalFilter={showModalFilter}
        setShowModalFilter={setShowModalFilter}
      />
    </>
  );
}

export default EngineerProfiles;
