import { MdClose } from "react-icons/md";
import styled from "styled-components";
import { BsArrowLeftCircle, BsArrowRightCircle } from "react-icons/bs";
import { Button } from "react-bootstrap";

export const EngineersPage = styled.div`
  background-color: #fff;
  margin-top: 75px;
  margin-left: 13%;
  width: 170vh;
  height: 50vh;
`;

export const ManageBtn = styled(Button)`
  height: 40px;
  background-color: #0070ad;
  top: -11%;
  position: relative;
  width:160px;
  left: -88%;
  border: 2px 2px solid;
  color: #fff;

  border-radius: 10px;

`;

export const EngineersHeading = styled.h2`
  color: #0070ad;
  position: absolute;
  top: 13%;
  right: 40%;
  font-size: 35px;
`;

export const ProfileCont = styled.div`
  width: 172vh;
  height: 55vh;
  overflow-y: hidden;
  display: flex;
  background-color: white;
  margin-left: -2%;
  margin-top: 18px;
  scroll-behavior: smooth;
  overflow-x: hidden;
`;

export const ProfileItem = styled.div`
  flex: 0 0 200px;
  width: 200px;
  display: block;
  justify-content: center;
  font-weight: 700;
  font-size: large;
  color: #1895d9;
  scroll-snap-align: start;
  background-color: white;
  margin-left: 1.5%;
  border-color: #1895d9;
  border: 10%;
  border-style: inset;
  border-radius: 0 0 0 0;
  border-color: #fff #c8e7f9 #c8e7f9 #c8e7f9;
`;

export const ProfileName = styled.div`
  position: relative;
  top: 0px;
  left: 0px;
  background-color: #a2d9ff;
  color: white;
  width: 195px;
  height: 40px;
  border-top-left-radius: 0%;
  border-top-right-radius: 0%;
  text-align: center;
  line-height: 40px;
`;

export const ProfileDesignation = styled.div`
  font-size: 10px;
  position: relative;
  top: 2%;
  left: 0%;
`;

export const ProfileScrollCont = styled.div`
  position: absolute;
  top: 60%;
  left: 8%;
  width: 86%;
`;

export const ProfileButtonPrev = styled(BsArrowLeftCircle)`
  position: absolute;
  height: 40px;
  width: 40px;
  color: #1895d9;
  cursor: pointer;
`;

export const ProfileButtonNext = styled(BsArrowRightCircle)`
  position: absolute;
  right: 0%;
  height: 40px;
  width: 40px;
  color: #1895d9;
  cursor: pointer;
`;

export const TitleName = styled.span`
  color: grey;
  font-size: 10px;
`;

export const ProfileDisplayItem = styled.div`
  margin: 5px;
  font-size: 12px;
  margin-top: 15px;
`;

// Modal for find out pop up starts here
export const ModalFindOutButton = styled.button`
  position: relative;
  top: 10%;
  left: 55%;
  padding: 5px;
  color: #fff;
  background: #c8e7f9;
  border-radius: 10px;
  border-color: #c8e7f9;
  box-shadow: 0px 0px 0px rgba(0, 120, 173, 0.5);
  cursor: pointer;
  font-size: 11px;
`;

export const ModalFindOutBackground = styled.div`
  position: fixed;
  z-index: 10;
  top: 0%;
  left: 0%;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
`;

export const ModalFindOutModalWrapper = styled.div`
  width: 700px;
  height: 540px;
  box-shadow: 0 5px 16px rgba(0, 0, 0, 0.2);
  background: #fff;
  color: #000;
  display: grid;
  grid-template-columns: 1fr 1fr;
  position: relative;
  border-radius: 10px;
  margin-top: -10px;
`;

export const ModalFindOutModalContent = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  line-height: 1.8;
  color: #141414;
  p {
    margin-bottom: 1rem;
  }
  button {
    padding: 10px 24px;
    background: #141414;
    color: #fff;
    border: none;
  }
`;

export const ModalFindOutCloseModalButton = styled(MdClose)`
  cursor: pointer;
  position: absolute;
  top: 10px;
  right: 10px;
  width: 32px;
  height: 32px;
  padding: 0;
  z-index: 10;
`;

export const FindOutMoreModalCont1 = styled.div`
  background-color: white;
  width: 600px;
  height: 100px;
  position: fixed;
  margin-top: -420px;
  margin-left: 350px;
  border: 2%;
  box-shadow: 1px 1px 3px rgba(0, 120, 173, 0.8);
`;

export const AvatarCont = styled.div`
  position: absolute;
  top: -20%;
  left: 40%;
`;

export const FindOutMoreModalName = styled.h1`
  position: absolute;
  top: 40%;
  left: 40%;
  color: #0070ad;
`;

export const FindOutMoreModalCont2 = styled.div`
  position: absolute;
  top: 26%;
  left: 27%;
  background-color: white;
  width: 250px;
  height: 350px;
  position: fixed;
  border: 2%;
  box-shadow: 1px 1px 3px rgba(0, 120, 173, 0.8);
`;

export const FindOutMoreModalJob = styled.p`
  color: grey;
`;

export const FindOutMoreModalDep = styled.p`
  color: grey;
`;

export const FindOutMoreModalGrade = styled.p`
  color: grey;
`;

export const FindOutMoreModalReports = styled.p`
  color: grey;
`;

export const FindOutMoreModalCont3 = styled.div`
  position: absolute;
  top: 26%;
  left: 48%;
  background-color: white;
  width: 350px;
  height: 160px;

  border: 2%;
  box-shadow: 1px 1px 3px rgba(0, 120, 173, 0.8);
`;

export const FindOutMoreModalEmail = styled.p`
  color: grey;
`;

export const FindOutMoreModalNumber = styled.p`
  color: grey;
`;

export const FindOutMoreModalLinks = styled.p`
  color: grey;
`;

export const FindOutMoreModalCont4 = styled.div`
  position: absolute;
  top: 56%;
  left: 48%;
  background-color: white;
  width: 350px;
  height: 190px;
  border: 2%;
  box-shadow: 1px 1px 3px rgba(0, 120, 173, 0.8);
`;

export const FindOutMoreModalQualifications = styled.p`
  color: grey;
`;

export const FindOutMoreModalSkills = styled.p`
  color: grey;
`;

export const FindOutMoreModalCV = styled.p`
  color: grey;
`;

// Modal filter container and button
export const FilterTitlesCont = styled.div`
  display: flexbox;
  float: left;
  margin-top: 25px;
  margin-left: -40px;
  color: #0070ad;
  height: 1px;
`;

export const FilterSearchBarsCont = styled.div`
  display: flex;
  align-items: center;
  height: 10vh;
  width: 60vh;
  margin-left: 0px;
  margin-top: 20px;
`;

export const FilterButton = styled.button`
  width: 100px;
  max-height: 15px;
  margin-left: 30px;
  margin-top: 10px;
  padding: 16px 32px;
  border-radius: 4px;
  border: none;
  background: #1895d9;
  color: white;
  font-size: 20px;
  align-items: center;
  cursor: pointer;
`;

export const FilterButtonTitle = styled.div`
  font-size: 15px;
  color: white;
  margin-left: -3px;
  margin-top: -8px;
`;

//Filter modal styling
export const SearchInput = styled.input`
  width: 120px;
  height: 20px;
  border: 1.5px solid #0070ad;
  margin-top: 10px;
  margin-left: 33px;
  border-radius: 5px;
  display: flexbox;
  float: left;
  padding: 9px 4px 9px 9px;
  font-size: 14px;
  color: #272936;
  ::placeholder {
    color: #bbb;
  }
  &:focus {
    box-shadow: 0 0 3px 0 #12abdb;
    border-color: #12abdb;
    outline: none;
  }
`;

export const FilterTitles = styled.div`
  margin-left: 105px;
  font-size: 14px;
  font-weight: 500;
  margin-top: 10px;
`;

export const FilterModalBackground = styled.div`
  position: fixed;
  left: 0;
  top: 0;
  z-index: 10;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
`;

export const FilterModalWrapper = styled.div`
  width: 515px;
  height: 500px;
  box-shadow: 0 5px 16px rgba(0, 0, 0, 0.2);
  background: #fff;
  color: #000;
  display: grid;
  grid-template-columns: 1fr 1fr;
  border-radius: 10px;
`;

export const FilterModalContent = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  line-height: 1.8;
  color: #141414;
  margin-top: 350px;

  p {
    margin-bottom: 1rem;
  }
  button {
    padding: 10px 24px;
    background: #141414;
    color: #fff;
    border: none;
  }
`;

export const FilterCloseModalButton = styled(MdClose)`
  cursor: pointer;
  position: relative;
  top: 10px;
  right: 10px;
  width: 32px;
  height: 32px;
  padding: 0;
  z-index: 10;
`;

export const FilterApplyModalButton = styled.button`
  cursor: pointer;
  width: 380px;
  margin-top: 30px;
  margin-left: 50px;
  border-radius: 10px;
  font-size: 15px;
`;

export const FilterModalHeader = styled.h2`
  color: black;
  margin-top: -370px;
  margin-left: 170px;
  width: 300px;
`;
