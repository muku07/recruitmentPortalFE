import {
  RewardsPage,
  HeadingTitleContainer,
  Title,
  Award1Img,
  Award2Img,
  Award3Img,
  Award1Container,
  Award2Container,
  Award3Container,
  Text1,
} from "./RewardsandRecognitionElements";

import { Link } from "react-router-dom";

import Award1 from "../../../../assets/Award1.svg";
import Award2 from "../../../../assets/Award2.svg";
import Award3 from "../../../../assets/Award3.svg";

function RewardsandRecognition() {
  return (
    <RewardsPage>
      <HeadingTitleContainer>
        <Title>Rewards and Recognition</Title>
      </HeadingTitleContainer>
      <Award1Container>
        <Award1Img src={Award1} />
        <Text1>Goes that Extra Mile</Text1>
      </Award1Container>
      <Award2Container>
        <Award2Img src={Award2} />
      </Award2Container>
      <Award3Container>
        <Award3Img src={Award3} />
      </Award3Container>
    </RewardsPage>
  );
}
export default RewardsandRecognition;
