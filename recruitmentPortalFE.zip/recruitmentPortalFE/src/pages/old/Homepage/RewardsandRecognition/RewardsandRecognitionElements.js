import { Link } from 'react-router-dom';
import styled from 'styled-components';


export const RewardsPage = styled.div`
  height: 200vh;
  overflow: hidden;
  max-width: 100%;
  width: auto;
  background: #fff;
  display: flex;
  justify-content: center;
  // centers in the flex direction and the default flex-direction is row
  align-content: center;
 
`;

export const HeadingTitleContainer = styled.div`
  position: absolute;
  top: 18%;
  padding: 10px;
  height: 50vh;

`;

export const Title = styled.h1`
  color: #0070ad;
  text-align: center;
 
  font-size: 2rem;
  font-family: "Ubuntu";
`;

// export const EmployeeProfileContainer = styled.div`
//   position: absolute;
//   top: 18%;
//   padding: 10px;
//   height: 50vh;

// `;

// export const Employeeofthemonth = styled.div`
// position: absolute;
// top: 18%;
// padding: 10px;
// height: 50vh;

// `;

export const Award1Container = styled.div`
position: absolute;
top:50%;
left: 30%;


`;

export const Award1Img = styled.img`
position: absolute;
max-width: 100px;
height: 100px;
`;

export const Text1 = styled.h1`
position: relative;
color: #000;
font-family: 'Ubuntu';
font-size: 1rem;
top: 60%;
left: -14%;
margin-top: 30px;
font-style:oblique;
z-index: 10;

`;


export const Award2Container = styled.div`
position: absolute;
top:35%;
left: 45%;

`;

export const Award2Img = styled.img`
position: absolute;
max-width: 100px;
height: 100px;
`;

export const Award3Container = styled.div`
position: absolute;
top: 50%;
left: 60%;
`;

export const Award3Img = styled.img`
position: absolute;
max-width: 100px;
height: 100px;

`;