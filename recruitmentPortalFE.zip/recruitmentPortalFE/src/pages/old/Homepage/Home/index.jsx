// Jeff Semple 24-03-2022
import { useEffect, useState } from "react";
import imgLeadboardChart from "../../../../assets/placeholderOrganizationalChart.jpg";
import imageAvatar from "../../../../assets/person-avatar-placeholder.png";
import { Carousel } from "react-responsive-carousel";
import { Doughnut } from "react-chartjs-2";
import React from "react";
import axios from "axios";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import AOS from "aos";
import "aos/dist/aos.css";
import PropTypes from "prop-types";
import {
  AboutHeadingTitle,
  OrgChartSection,
  OrgChartTitle,
  HomePage,
  TestimonialContainer,
  Testimonial,
} from "./HomeElement";

TestimonialCard.propTypes = {
  authorName: PropTypes.string.isRequired,
  imgSrc: PropTypes.string.isRequired,
  position: PropTypes.string.isRequired,
  text: PropTypes.string.isRequired,
};

function TestimonialCard({ authorName, imgSrc, position, text }) {
  return (
    <Testimonial>
      <img src={imgSrc} alt={"A profile image for " + authorName}></img>
      <h2>{authorName}</h2>
      <h3>{position}</h3>
      <p>{text}</p>
    </Testimonial>
  );
}

function Home() {
  const URL = "https://my.api.mockaroo.com/chartdata.json?key=23570990";

  const [chartData, setChartData] = useState([]);
  const reactDonutChartBackgroundColor = [
    "#00E396",
    "#FEB019",
    "#FF4560",
    "#775DD0",
  ];

  const doughnutData = {
    labels: ["AWS", "AZURE", "PEGA", "JAVA", "QAI", "ORACLE", "IBM", "GOOGLE"],
    datasets: [
      {
        data: [25, 65, 100, 15, 45, 115, 10, 25],
        backgroundColor: reactDonutChartBackgroundColor,
      },
    ],
  };

  const doughnutOptions = {
    maintainAspectRatio: true,
    layout: {
      padding: 0,
      autoPadding: false,
    },
    plugins: {
      legend: {
        position: "bottom",
        labels: {
          color: "#fff",
          usePointStyle: true,
          pointStyle: "circle",
        },
      },
    },
  };

  // chart data needs sorting..
  const fetchChartJSON = () => {
    fetch(URL)
      .then((res) => res.json())
      .then((result) => {
        setChartData(result);
        console.log("result", result);
        console.log("setChartData", chartData);
      });

    axios.get(URL).then((res) => {
      setChartData(res.data);
    });
    //
  };

  useEffect(() => {
    AOS.init({});
    fetchChartJSON();
  }, []);

  const testimonialTestText = `Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                  Ut enim ad minim veniam, quis nostrud exercitation ullamco
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                  Ut enim ad minim veniam, quis nostrud exercitation ullamco "
                  "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                  Ut enim ad minim veniam, quis nostrud exercitation ullamco
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                  Ut enim ad minim veniam, quis nostrud exercitation ullamco "
                  "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                  Ut enim ad minim veniam, quis nostrud exercitation ullamco
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                  Ut enim ad minim veniam, quis nostrud exercitation ullamco "
                  "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                  Ut enim ad minim veniam, quis nostrud exercitation ullamco
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                  Ut enim ad minim veniam, quis nostrud exercitation ullamco `;

  return (
    <HomePage>
      <AboutHeadingTitle>Who We Are</AboutHeadingTitle>
      <p>
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
        veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
        commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
        velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
        occaecat cupidatat non proident, sunt in culpa qui officia deserunt
        mollit anim id est laborum."
      </p>

      <OrgChartSection>
        <OrgChartTitle>Leadership</OrgChartTitle>
        <div>
          <Doughnut
            data={doughnutData}
            options={doughnutOptions}
            aria-label="A chart demonstrating the skills of the leadership at CapGemini"
          />
        </div>
        <Carousel
          infiniteLoop={true}
          autoPlay={true}
          animationHandler={"slide"}
          transitionTime={1000}
          showStatus={false}
          showIndicators={false}
          dynamicHeight={true}
        >
          <img alt="An image showing the leaders" src={imgLeadboardChart} />
          <img alt="An image showing the leaders" src={imgLeadboardChart} />
          <img alt="An image showing the leaders" src={imgLeadboardChart} />
        </Carousel>
      </OrgChartSection>

      <TestimonialContainer>
        <Carousel
          infiniteLoop={true}
          // autoPlay={true}
          animationHandler={"slide"}
          transitionTime={2500}
          showStatus={false}
          showIndicators={false}
          showThumbs={false}
        >
          <TestimonialCard
            imgSrc={imageAvatar}
            authorName="John Smith"
            position="Director"
            text={testimonialTestText}
          />
          <TestimonialCard
            imgSrc={imageAvatar}
            authorName="John Smith"
            position="Director"
            text={testimonialTestText}
          />
          <TestimonialCard
            imgSrc={imageAvatar}
            authorName="John Smith"
            position="Director"
            text={testimonialTestText}
          />
          <TestimonialCard
            imgSrc={imageAvatar}
            authorName="John Smith"
            position="Director"
            text={testimonialTestText}
          />
        </Carousel>
      </TestimonialContainer>
    </HomePage>
  );
}
export default Home;
