import styled from "styled-components";

export const HomePage = styled.div`
  margin: 0 1rem 1rem 5.25rem;
  padding-top: 1rem;
  text-align: center;
  display: flex;
  flex-direction: column;
`;

export const AboutHeadingTitle = styled.h1`
  margin: auto;
`;

export const OrgChartSection = styled.div`
  background-color: #3a1f70;
  border-radius: 2rem;
  margin: 0 1rem;
  padding: 1.5rem;
  display: grid;
  grid-template-columns: 50% 50%;
  grid-template-rows: auto auto;

  & > h1 {
    grid-column-start: span 2;
    margin-bottom: 1.5rem;
  }

  & > div > canvas {
    grid-column: 1 / 2;
    max-width: 80vw;
    max-height: 100%;
  }

  // fixes bad carousel styling
  & > div:nth-of-type(2) {
    display: flex;
    flex-direction: column;
    justify-content: center;

    & * {
      margin: 0;
      padding: 0;
    }

    & .thumbs {
      margin: 1rem;
      display: flex;
      justify-content: center;
    }
  }

  @media screen and (max-width: 768px) {
    grid-template-columns: 100%;
    grid-template-rows: auto 50% 50%;

    & > h1 {
      grid-column-start: 1;
    }

    & > div > canvas {
      grid-column: 1;
    }
  }
`;

export const OrgChartTitle = styled.h1`
  color: #fff;
`;

export const TestimonialContainer = styled.div`
  margin: 1rem;
  background-color: #3a1f70;
  border-radius: 2rem;
  padding: 1.5rem;
  color: #fff;
  overflow: hidden;

  // the below enables arrows to not collide with scrollbar
  & > .carousel-root > .carousel {
    overflow: visible;
    & > .control-next {
      right: -1.45rem;
    }
    & > .control-prev {
      left: -1.45rem;
    }
  } // end arrow collide fix
  @media screen and (max-width: 425px) {
    padding: 0.5rem 1.5rem;
  }
`;

export const Testimonial = styled.div`
  display: grid;
  grid-template-columns: 15rem auto;
  grid-template-rows: 15rem 11% 11% auto;
  height: 55vh;
  margin-right: 0.5rem;

  & > * {
    margin: 0;
    padding: 0;
  }

  & > img {
    grid-column: 1 / 1;
    grid-row: 1 / 1;
    max-height: 100%;
    padding: 0.5rem;
  }

  & > h2 {
    grid-column: 1 / 2;
    grid-row: 2 / 3;
  }

  & > h3 {
    grid-column: 1 / 2;
    grid-row: 3 / 4;
    font-size: 1.25rem;
    color: rgba(255, 255, 255, 0.8);
  }

  & > p {
    grid-column: 2 / 3;
    grid-row: span 4;
    overflow-y: scroll;
    text-align: justify;
    padding: 0 0.25rem;

    &::-webkit-scrollbar-track {
      background-color: rgb(137, 121, 169);
      max-width: 1vw;
      border-radius: 1vw;
    }
    &::-webkit-scrollbar {
      background-color: rgb(137, 121, 169);
      max-width: 1vw;
      border-radius: 1vw;
    }
    &::-webkit-scrollbar-thumb {
      background: rgba(230, 230, 230, 0.8);
      border-radius: 1vw;
    }
  }

  @media screen and (max-width: 426px) {
    grid-template-columns: 45% 55%;
    grid-template-rows: 17% 17% 11% auto;
    margin: 0;
    min-height: fit-content;

    & > img {
      grid-column: 1/2;
      grid-row: 1/3;
      object-fit: cover;
      padding: 0;
    }
    & > h2 {
      grid-column: 2/3;
      grid-row: 1/2;
      overflow-y: scroll;
    }
    & > h3 {
      grid-column: 2/3;
      grid-row: 2/3;
    }
    & > p {
      grid-column: span 3;
      grid-row: 3/5;
      font-size: 0.75rem;
    }
  }
`;
