// import React, { useState } from "react";
// import ButtonDownFaqs from "../../../../assets/ButtonDownFaqs.svg";

// import {
//   FAQPage,
//   HeadingContainer,
//   FaqWrapper,
//   FaqMapContainer,
//   FaqBlock,
//   FaqQuestion,
//   FaqAnswer,
//   FaqArrow,
//   Title,
// } from "./FAQsElements";

// function Faqs() {
//   //The current FAQs I thought of
//   const currentFaqs = [
//     {
//       id: 1,
//       question: "I am not a part of the MAPII practice, can I make an account?",
//       answer:
//         "No. This portal is only for the MAPII practice. However, in the future, a portal for your practice will be available.",
//       open: false,
//     },
//     {
//       id: 2,
//       question:
//         "I want to look at the portal as a visitor, what access do I have?",
//       answer: "As a visitor, you are only able to see the homepage.",
//       open: false,
//     },
//     {
//       id: 3,
//       question: "What are the possible tiers to sign up to within the Portal?",
//       answer:
//         "Once you sign up and become a member, you can become an Engineer or Supervisor. An Engineer can upload and update your CV, view all other engineers, create-retrieve-update-delete your own profile, create a blog and look at essential links. " +
//         "A Supervisor can do all of the above and also view certifications and statistics, upload/view accelerators, view CV’s of engineers.",
//       open: false,
//     },
//     {
//       id: 4,
//       question: "What is on our profile?",
//       answer:
//         "Name, profile picture, CV, skills, certifications you have achieved",
//       open: false,
//     },
//     {
//       id: 5,
//       question:
//         "When I sign up, as a senior, do I become an engineer or Supervisor?",
//       answer:
//         "When you sign up, you will become an Engineer. The admin will assign you as a Supervisor.",
//       open: false,
//     },
//     {
//       id: 6,
//       question: "Can anyone write in the blog?",
//       answer:
//         "Yes. The blog is for all signed up members to contribute to. Your submission will need to be approved by the selected reviewers though.",
//       open: false,
//     },
//   ];

//   // Use state to control the open and close state for each FAQ array
//   const [faqs, setFaqs] = useState(currentFaqs);

//   const toggleFAQ = (index) => {
//     setFaqs(
//       faqs.map((faq, i) => {
//         if (i === index) {
//           faq.open = !faq.open;
//         } else {
//           faq.open = false;
//         }

//         return faq;
//       })
//     );
//   };
//   useEffect(() => {
//     AOS.init({});
//   }, []);
//   return (
//     <FAQPage>
//       <HeadingContainer data-aos={"zoom-in"} data-aos-duration="1500">
//         {/* <Title>FAQs (Frequently Asked Questions)</Title> */}

//         <Title>
//           FAQs
//           <Typed
//             strings={[" (Frequently Asked Questions)"]}
//             typeSpeed={3}
//             backSpeed={100}
//             loopCount={0}
//             startDelay={3000}
//             showCursor={true}
//             cursorChar={"!"}
//           />
//         </Title>
//       </HeadingContainer>

//       <FaqMapContainer data-aos="zoom-out" data-aos-duration="1500">
//         {faqs.map((faq, i) => (
//           <FaqWrapper key={faq.id}>
//             <FaqBlock key={faq.id} onClick={() => toggleFAQ(i)}>
//               <FaqQuestion open={faq.open}>
//                 {" "}
//                 {faq.question} <FaqArrow open={faq.open} src={ButtonDownFaqs} />
//               </FaqQuestion>
//               <FaqAnswer open={faq.open}>{faq.answer}</FaqAnswer>
//             </FaqBlock>
//           </FaqWrapper>
//         ))}
//       </FaqMapContainer>
//     </FAQPage>
//   );
// }

// export default Faqs;
