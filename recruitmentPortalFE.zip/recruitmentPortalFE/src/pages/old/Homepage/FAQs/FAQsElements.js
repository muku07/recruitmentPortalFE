import styled from "styled-components";

export const FAQPage = styled.div`
  overflow: hidden;
  max-width: 100%;
  background: #fff;
  display: flex;
  justify-content: center;
  // centers in the flex direction and the default flex-direction is row
  align-content: center;
  // centers perpendicular to the flex direction
`;

export const HeadingContainer = styled.div`
  position: absolute;
  top: 20%;
  height: auto;
  width: auto;
`;

export const Title = styled.h1`
  color: #0070ad;
  text-align: center;
  font-size: 2.5rem;
  font-family: "Ubuntu";
`;

export const FaqMapContainer = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  position: absolute;
  top: 30%;
  left: 5%;
  padding: 20px;
  height: auto;
  width: auto;
  margin: 30px auto;

  background: #fff;
  text-align: center;
`;

export const FaqWrapper = styled.div`
  width: 100%;
  max-width: 900px;
  margin: 0 auto;
  padding: 15px;
  font-family: "Ubuntu";
`;

export const FaqBlock = styled.div`
  margin: 15px;
  padding: 15px;
  background-color: #1895d9;
  border-radius: 15px;
  box-shadow: -4px 4px 6px rgba(0, 120, 173, 0.5);
  cursor: pointer;
  color: #fff;
`;

export const FaqQuestion = styled.div`
  position: relative;
  font-weight: bold;
  font-size: 140%;
  padding-right: 80px;
  margin: 5px;

  transition: 0.8s ease-in-out;


  margin-bottom: ${({ open }) => (open ? "15px" : "0px")};
  //Conditional styling to drop down margin when clicked
`;

export const FaqArrow = styled.img`
  position: absolute;
  top: 50%;
  right: 0px;
  transform: translateY(-50%);
  max-width: 60px;
  height: 60px;

  background-position: center;
  background-size: contain;
  background-repeat: no-repeat;

  transition: 0.8s ease-in-out;


  transform: ${({ open }) =>
    open ? "translateY(-50%) rotate(180deg)" : "0px"};
  //Conditional styling to flip arrow when clicked
`;

export const FaqAnswer = styled.div`
  opacity: 0;
  max-height: 0;
  overflow-y: hidden;
  width: 100%;
  margin: 5px;
  transition: 0.8s ease-in-out;
  

  font-size: 110%;

  max-height: ${({ open }) => (open ? "1000px" : "0px")};
  opacity: ${({ open }) => (open ? "1" : "0")};
  //Conditional styling make visable and add height when clicked
`;
