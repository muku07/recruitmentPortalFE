import { Card, TextField, FormControl, Fab  } from "@mui/material";
import styles from "styled-components";
import { styled } from "@mui/material/styles";

export const ContentWrapper = styles.div`

   margin-top: 2%;
   display:grid;
   grid-template-rows: auto auto;
   width:85%;
`;

export const ContentCard = styled(Card)`
  padding: 1rem 1rem;
  margin-left: 20px;
  height: 470px;
`;

export const Title = styled("div")`
  padding: 1rem 0rem;
  display: flex;
  align-items: center;
  gap: 8px;

  span {
    text-align: center;
    font-weight: 500;
    font-size: 1.5rem;
  }
`;
export const Button = styles.div`
margin-top: 8px;
margin-left:auto;
align-items: flex-end;
//display: inline-block;
    width:71px;
    height:37px;
  // left: 1104.12px;
    top: 88px;
    padding: 8px 16px;
    border-radius: 10px;
    background-color: ${(props) => props.backgroundColour};
`;

export const TextBox = styled(TextField)`
  //align-items: flex-end;
  display: inline-block;
  background: var(--bg-primary);

  //margin-left: auto;
  // margin-right: auto;
  margin-top: 2%;
  font-size: large;
  width: ${(props) => props.width};
`;

export const Form = styled(FormControl)`
  //align-items: flex-end;
  //display: inline-block;
  background: var(--bg-primary);
  width: 20%;
  //margin-left: auto;
  margin-top: 2%;
  font-size: large;
`;
export const ButtonContainer = styles.div`
margin-left:auto;
 display: flex; 
 justify-content: space-evenly;

`;

export const TextBoxContainer = styles.div`
//width: 100%;
//margin-left:auto;
 display: flex; 
 justify-content: space-evenly;
 padding: 8px;
margin: dense;

`;

export const Paragraph = styles.div`

   margin-left: 6.5%;
   padding: 4px 16px;
   font-weight: bold;

`;

export const AnotherTextBox = styled(TextField)`
width: 100%;
padding: 8px 105px 0 60px;

`;

export const ActionButton = styled(Fab)`

size:small;
margin-left:auto;
background-color:#205CE9;
`;
