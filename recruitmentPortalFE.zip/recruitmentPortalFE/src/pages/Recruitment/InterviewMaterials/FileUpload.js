import React, { useState } from "react";
import { FileCard,InputFile } from "./FileUploadElement.js";
import { MdAddCircle } from "react-icons/md";


function FileUploader() {
  const [file, setFile] = useState(null);

  const handleFileChange = (event) => {
    setFile(event.target.files[0]);
  };

  return (
    <div>
      <FileCard>
        <InputFile
          id="file-upload"
          type="file"
          name="resume"
          accept=".doc,.docx,application/pdf,.pdf,.ppt,.pptx"
         // value={values.resume}
          onChange={handleFileChange}
        />
         {/* <MdAddCircle style={{ color: "blue" }} /> */}
         
        {file && <img src={URL.createObjectURL(file)} alt="Uploaded file" />}
         {file && <button onClick={() => setFile(null)}>Remove file</button>}

      </FileCard>
    </div>
  );
}

export default FileUploader;
