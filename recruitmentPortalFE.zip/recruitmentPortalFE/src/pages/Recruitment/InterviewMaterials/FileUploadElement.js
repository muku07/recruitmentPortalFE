import styled from "styled-components";

export const FileCard = styled.div`

    background-color: rgba(0,0,0,0);
   // border: 1.5px solid #ececec;
   border: dashed blue;
    border-radius: 5px;
    padding: -2px 0px 0px 0px;
    position: relative;
    width: 860px;
    margin: 1px 80px 0px 80px;
   
    text-align: center;
    height: 100px
`;


export const FileInput = styled.div`
    position: relative;
    margin-bottom: 25px;
`;

export const InputFile = styled.input`
    position: relative;
    width: 100%;
    z-index: 2;
    cursor: pointer;
    opacity: 0;
`;

export const FileButton = styled.label`
    position: absolute;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 200%;
    z-index: 1;
    display: flex;
    justify-content: center;
    align-items: center;
    color: #ececec;
    background-color: #0070ad;
    font-size: 14px;
    cursor: pointer;
    border: none;
    border-radius: 5px;
    outline: none;
    box-shadow: 0 0 1px 0 #12abdb;
`;

export const ImageI = styled.i`
    background-color: #0070ad;
    display: flex;
    color: #ececec;
    justify-content: center;
    align-items: center;
    margin-right: 5px;
`;

export const FileTag = styled.p`
    font-size: 12px;
    font-family: inherit;
    padding-top: 3px;
`;