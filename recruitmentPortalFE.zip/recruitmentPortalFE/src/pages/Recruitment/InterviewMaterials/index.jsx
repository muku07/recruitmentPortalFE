import * as React from "react";
import { useState, useEffect } from "react";
import { FileUploader } from "./FileUpload";
import { useNavigate, useLocation } from "react-router-dom";
import {
  ContentCard,
  ContentWrapper,
  Title,
  Button,
  TextBox,
  AnotherTextBox,
  Form,
  ButtonContainer,
  TextBoxContainer,
  Paragraph,
  ActionButton,
} from "./InterviewMaterialsStyles";
import {
  InputLabel,
  Select,
  MenuItem,
  Chip,
  Stack,
  Fab,
  InputAdornment,
} from "@mui/material";
import {
  FileCard,
  FileInput,
  InputFile,
  ImageI,
  FileButton,
  FileTag,
} from "./FileUploadElement";

import { MdAddCircle } from "react-icons/md";
import { MuiChipsInput } from "mui-chips-input";
//import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import AddIcon from "@mui/icons-material/Add";
import FormControl from "@mui/material/FormControl";
import Selected, { SelectChangeEvent } from "@mui/material/Select";
import { makeStyles } from "@material-ui/core/styles";
import ArrowBackIosNewIcon from "@mui/icons-material/ArrowBackIosNew";
import FileUpload from "./FileUpload";
import axios from "axios";

//ACTS AS A CSS STYLING FILE INSTEAD OF INSTYLING
const useStyles = makeStyles((theme) => ({
  chip: {
    marginTop: "5px",
    backgroundColor: "white",
    border: "2px solid blue",
    color: "blue",
    fontWeight: 300,
  },
}));

function InterviewMaterials() {
  
  const navigate = useNavigate();
  let locationData = useLocation();
  console.log(locationData.state);
  const handleChange = () => console.log("handle change");
  // static array of techs (should be end point)
  const[fileTitle, setFileTitle]=useState("");

  const [techSelection, setTechSelection] = useState([
    { techName: "java", techId: 2 },
    { techName: "REACT", techId: 1 },
    { techName: ".NET", techId: 3 },
    { techName: "AWS", techId: 4 },
  ]);

  const [chips, setChips] = useState(["Java", "REACT"]);
  const classes = useStyles();

  //function for handling drop down

  const handleDropDownChanges = (event: SelectChangeEvent) => {
    // console.log("event");
    // console.log(event.target.value);
    // console.log("tempInterviewers");
    // console.log(tempInterviewers);

    let selectedTech = event.target.value;
    // console.log("selectedTech");
    // console.log(selectedTech);

    const selectedObject = techSelection.find(
      (item) => item.techName === selectedTech
    );

    setChips((prevState) =>
      prevState.length == 0 ? [selectedTech] : [...prevState, selectedTech]
    );

    // console.log("selectedObject");
    // console.log(selectedObject);

    // this allows a list of multiple techs to be added but
    // would have to apply a method for a mistaken tech selected to be removed
    // contextData.setTechnologies((prevState) =>
    //   prevState.length == 0 ? [selectedObject] : [...prevState, selectedObject]
    // );
    //contextData.setTechnologies([selectedObject]);

    // console.log("contextData.technologies");
    // console.log(contextData.technologies);
  };


  const handleDropDownMatType = (event: SelectChangeEvent) => {
    // console.log("event");
    // console.log(event.target.value);
    // console.log("tempInterviewers");
    // console.log(tempInterviewers);

    let selectedTech = event.target.value;
    // console.log("selectedTech");
    // console.log(selectedTech);

    const selectedObject = techSelection.find(
      (item) => item.techName === selectedTech
    );

     };

  function handleDeleteChip(index) {
    // contextData.setChips(contextData.chips.filter((chip, i) => i !== index));
    const tech = chips[index];
    console.log("value of tech " + tech);

    // Find the index of the interviewer object with a matching email property
    const techIndex = techSelection.findIndex(
      (techSelection) => techSelection.techName === tech
    );
    console.log("value of techIndex " + techIndex);

    // filter out the selected interviewer from the "interviewers" state in the context data
    setTechSelection((prevState) => {
      return prevState.filter((techSelection, i) => i !== techIndex);
    });

    // filter out the selected email from the "chips" state in the context data
    setChips((prevState) => {
      return prevState.filter((chip, i) => i !== index);
    });
  }

  function cancelButton() {
    navigate("/recruitment/material-list");

    //    let handleSaveButton=(event)=>{
    //     let myProm= axios.post("http://localhost:3000/emps", matObj)
    //     myProm.then((matRes)=> {console.log("Material inserted")})
    //     .catch((matErr)=>{console.log("Error in insertion");})
    //  }
  }
  return (
    <ContentWrapper>
      <Title>
        <Paragraph> Add new material </Paragraph>
        <ButtonContainer>
          <Button onClick={() => cancelButton()}>Cancel</Button>
          <Button backgroundColour="#205CE9" style={{ color: "white" }}>
            Save
          </Button>
        </ButtonContainer>
      </Title>
      <ContentCard>
        <Paragraph> Add new material </Paragraph>
        <TextBoxContainer>
          <input type="text" name="FileTitle" value={fileTitle}  onChange={(event)=>{setFileTitle(event.target.value)}}/>
          <Form>
            <InputLabel id="demo-simple-select-label">
              Type of Material
            </InputLabel>
            <Select
              labelId="demo-simple-select-label"
              id="demo-simple-select"
              value={techSelection}
              label="Type of Material"
              onChange={handleDropDownMatType}
            >
              {techSelection.map((tech, techIndex) => {
                return <MenuItem key={tech.techId}>{tech.techName}</MenuItem>;
              })}
            </Select>
          </Form>
        </TextBoxContainer>
        <Paragraph> Choose technology </Paragraph>
        <div style={{ width: "100%", margin: "2%" }}>
          {/* <MuiChipsInput value={chips} onChange={handleChipsChange} /> */}

          <FormControl
            style={{ width: "86%", fontSize: "25px", marginLeft: "5%" }}
          >
            {/* <InputLabel
              id="demo-simple-select-label"
              // style={{ fontSize: "12px" }}
            >
              Select Technology
            </InputLabel> */}
            <InputLabel id="demo-simple-select-label">
              Select Technology
            </InputLabel>
            <Select
              // labelId="demo-simple-select-label"
              //   id="demo-simple-select"
              label="Select Technology"
              // boxShadow={1}
              //IconComponent={ArrowBackIosNewIcon}
              //classes={{ icon: classes.arrow }}
              onChange={handleDropDownChanges}
              style={{
                width: "100%",
                // height: "50px",
                // backgroundColor: "rgb(240,240,240)",
                // fontSize: "12px",
              }}
            >
              {techSelection.map((item) => (
                <MenuItem
                  key={item.id}
                  value={item.techName}
                  style={{ fontSize: "12px" }}
                >
                  {item.techName}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          <div style={{ margin: "4px 60px 0px " }}>
            {chips.map((chip, index) => (
              <Chip
                key={chip}
                label={chip}
                onDelete={() => handleDeleteChip(index)}
                className={classes.chip}
              />
            ))}
          </div>
        </div>
        <Paragraph> Add a file with materials </Paragraph>
        {/* <FileCard>
          <FileInput>
            <InputFile
              id="file-upload"
              type="file"
              name="resume"
              accept=".doc,.docx,application/pdf,.pdf,.ppt,.pptx"
              //   value={values.resume}
              //    onChange={uploadHandler}
            />
            Upload a file containing materials
          </FileInput>
          <MdAddCircle style={{ color: "blue" }} />
          <ul>
            {/* {files &&
            files.map((f) => (
              <FileItem key={f.name} file={f} deleteFile={deleteFileHandler} />
            ))}
          </ul>
        </FileCard> */}

        <FileUpload />
      </ContentCard>
      <ButtonContainer>
        <Button onClick={() => cancelButton()}>Cancel</Button>
        <Button
          backgroundColour="#205CE9"
          style={{ color: "white" }}
          type="submit"
        >
          Save
        </Button>
      </ButtonContainer>
    </ContentWrapper>
  );
}
//   function Dropdown(props) {
//   return (
//     <DropdownWrapper action={props.action} onChange={props.onChange}>
//       <StyledLabel htmlFor="services">{props.formLabel}</StyledLabel>
//       <StyledSelect id="services" name="services">
//         {props.children}
//       </StyledSelect>
//     </DropdownWrapper>
//   );
// }
export default InterviewMaterials;
