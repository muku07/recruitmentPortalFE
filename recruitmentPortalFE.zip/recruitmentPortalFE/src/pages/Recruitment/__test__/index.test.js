import Recruitment from "..";
import {
    render,
    fireEvent,
    screen,
    shallow,
    getByTestId,
  } from "@testing-library/react";
  import { Routes, Route, MemoryRouter } from "react-router-dom";
import "@testing-library/jest-dom/extend-expect";
import React from "react";

const renderComponent = () => {
    render(
        <MemoryRouter>
            <Routes>
                <Route
                    path="/"
                    element={<Recruitment />}
                 />
            </Routes>
        </MemoryRouter>
    )
};

test("Does Component Render?", async () => {
    renderComponent();
});

test("Tab Panels", async () => {
    renderComponent();

    var retrieveTab = await screen.findByTestId("retrieveTab");
    var availabilityTab = await screen.findByTestId("availabilityTab");
    var candidatesTab = await screen.findByTestId("candidatesTab");
   
    expect(retrieveTab).toBeInTheDocument();
    expect(availabilityTab).toBeInTheDocument();
    expect(candidatesTab).toBeInTheDocument();

    expect(retrieveTab.textContent).toBe("Retrieve Panel")
    expect(availabilityTab.textContent).toBe("Availability")
    expect(candidatesTab.textContent).toBe("Candidates")
});

test("Schedule Interview Button", async () => {
    renderComponent();

    var scheduleInterview = await screen.findByTestId("scheduleInterviewButton");

    expect(scheduleInterview).toBeInTheDocument();
    expect(scheduleInterview.textContent).toBe("Schedule an interview");
});