import { styled } from "@mui/material/styles";
import styles from "styled-components";
// import Button from "@mui/material/Button";
import Button from "@material-ui/core/Button";
import Paper from "@material-ui/core/Paper";
import { Box, Card } from "@mui/material";
import InputBase from "@mui/material/InputBase";

export const ContentWrapper = styled("div")`
  margin-top: 5%;
  margin-left: auto;
  margin-right: auto;
  /* margin-left: 45%; */
  width: 90%;
  padding: 10px;
`;
export const TableWrapper = styled(Paper)`
  margin-top: 5%;
  margin-left: 45%;
  width: 85%;
  padding: 10px;
`;

export const TitleOnHover = styles.div`
  color: blue;
 
  &:hover{
    transform: scale(110%);
     cursor: pointer;
    }
`;

export const BoxStyled = styled(Box)`
  text-align: center;
  background-color: white;
  padding: 20px;
  min-width: 60%;
  transform: "translate(-50%, -50%)";
`;

export const SearchBox = styled(InputBase)`
  padding: 0 0.3rem 0 0.4rem;
  background: var(--bg-primary);
  border-radius: 0.3rem;
  width: 60%;
`;

export const ContentHeader = styles.h1`
   font-size: 20px;
   text-align: left;
   margin-left: 5%;
   margin-buttom: 5%;
   height: 55px;
   width: 55%;
  //  padding-right:100px;
 `;

export const filterMaterialWrapper = styled(Card)`
  padding: 2rem 3rem;
`;

export const AddButton = styled(Button)`
  float: right;
  /* margin-left: 10%; */
  max-height: 30px;
  margin-top: 3.5%;
  margin-right: 5%;
  background-color: blue;
`;

export const SearchBarButtonWrapper = styles.div`
display:flex;
width:115%;
margin-left:45px;

`;
