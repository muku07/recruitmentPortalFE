import React, { useState, useContext } from "react";
import Table from "@material-ui/core/Table";
import TableContainer from "@material-ui/core/TableContainer";
import Paper from "@material-ui/core/Paper";
import TableBody from "@material-ui/core/TableBody";
import TableRow from "@material-ui/core/TableRow";
import TableCell from "@material-ui/core/TableCell";
import TableHead from "@material-ui/core/TableHead";
import TablePagination from "@material-ui/core/TablePagination";
import useTheme from "@material-ui/core/styles/useTheme";
import FirstPageIcon from "@material-ui/icons/FirstPage";
import LastPageIcon from "@material-ui/icons/LastPage";
import KeyboardArrowLeft from "@material-ui/icons/KeyboardArrowLeft";
import KeyboardArrowRight from "@material-ui/icons/KeyboardArrowRight";
import IconButton from "@material-ui/core/IconButton";
import { makeStyles, createStyles } from "@material-ui/core/styles";
import { MaterialListContext } from "../Context/MaterialListContext";
import Chip from "@mui/material/Chip";
import DeleteOutlineRoundedIcon from "@mui/icons-material/DeleteOutlineRounded";
import { TextField, Box } from "@mui/material";
import SearchRoundedIcon from "@mui/icons-material/SearchRounded";
import SearchIcon from "@mui/icons-material/Search";
// import Button from "@mui/material/Button";
import Button from "@material-ui/core/Button";
import {
  TitleOnHover,
  BoxStyled,
  SearchBox,
  TableWrapper,
  ContentHeader,
  filterMaterialWrapper,
  AddButton,
  SearchBarButtonWrapper,
} from "../ListMaterialsStyles";
const useStyles = makeStyles((theme) =>
  createStyles({
    wrapper: {
      width: "90%",
      marginLeft: "auto",
      marginRight: "auto",
      marginTop: "auto",
      marginButtom: "auto",
      fontSize: "10px",
    },
    root: {
      width: "100%",
    },
    container: {
      // maxHeight: 440,
      // maxHeight: 410,
    },
    visuallyHidden: {
      border: 0,
      clip: "rect(0 0 0 0)",
      height: 1,
      margin: -1,
      overflow: "hidden",
      padding: 0,
      position: "absolute",
      top: 20,
      width: 1,
    },
    chip: {
      marginTop: "5px",
      backgroundColor: "white",
      border: "2px solid blue",
      color: "blue",
      fontSize: "13px",
    },
    head: {
      fontWeight: "bold",
      fontSize: "15px",
      textAlign: "left",
    },
    oddRow: {
      backgroundColor: theme.palette.grey[200],
      fontSize: "10px",
    },
    evenRow: {
      backgroundColor: "white",
      fontSize: "10px",
    },
    icon: {
      color: "red",
      position: "absolute",
      // top: "50%",
      // left: "50%",
      marginLeft: "30px",
      fontSize: "30px",
      transform: "translate(-50%, -50%)",
      cursor: "pointer",
      "&:hover": {
        fontSize: "50px",
      },
    },
  })
);

//
export default function MaterialListTable() {
  const contextData = useContext(MaterialListContext);
  // console.log("contextData");
  // console.log(contextData.jsonData);
  const jsonData = contextData.jsonData;
  const classes = useStyles();
  const theme = useTheme();
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [count, setCount] = useState(jsonData.length);
  const emptyRows =
    rowsPerPage - Math.min(rowsPerPage, jsonData.length - page * rowsPerPage);
  // useState to create a state variable for the search text
  // const [searchText, setSearchText] = useState("");

  // use the search text to filter the rows of the table
  const filteredData = jsonData.filter((row) => {
    return row.title
      .toLowerCase()
      .includes(contextData.searchText.toLowerCase());
  });
  // const TablePaginationActions = (props) => {
  //   const theme = useTheme();
  //   const { count, page, rowsPerPage, handleChangePage } = props;
  // };
  const handleBackButtonClick = (event) => {
    handleChangePage(event, page - 1);
  };
  const handleNextButtonClick = (event) => {
    handleChangePage(event, page + 1);
  };
  const handleLastPageButtonClick = (event) => {
    handleChangePage(event, Math.max(0, Math.ceil(count / rowsPerPage) - 1));
  };
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };
  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };
  const handleFirstPageButtonClick = (event) => {
    setPage(0);
  };
  function onTitleClick(row) {
    contextData.setRowSelected(row);
    contextData.handleTitleClickMaterial();
  }
  function onDeleteClick(row) {
    contextData.setRowSelected(row);
    contextData.handleDeleteIconClickMaterial();
  }

  return (
    <div className={classes.wrapper}>
      <TableWrapper className={classes.wrapper}>
        <TableContainer
          boxShadow={3}
          component={Paper}
          className={classes.container}
        >
          <Table stickyHeader aria-label="sticky table">
            <TableHead>
              <TableRow>
                <TableCell className={classes.head}>Title</TableCell>
                <TableCell className={classes.head}>Type</TableCell>
                <TableCell className={classes.head}>Created</TableCell>
                <TableCell className={classes.head}>Technology</TableCell>
                <TableCell className={classes.head}>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredData
                .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                .map((row, index) => (
                  <TableRow
                    key={row.title}
                    className={
                      index % 2 === 0 ? classes.evenRow : classes.oddRow
                    }
                  >
                    <TableCell>
                      <TitleOnHover onClick={() => onTitleClick(row)}>
                        {row.title}
                      </TitleOnHover>
                    </TableCell>

                    <TableCell>{row.type}</TableCell>
                    <TableCell>
                      {row.created_by.first_name +
                        " " +
                        row.created_by.last_name}
                    </TableCell>
                    <TableCell>
                      {row.technology.map((value, index) => (
                        <Chip
                          key={index}
                          label={value.tech_name}
                          className={classes.chip}
                        />
                      ))}
                    </TableCell>
                    <TableCell>
                      <DeleteOutlineRoundedIcon
                        onClick={() => onDeleteClick(row)}
                        className={classes.icon}
                      />
                    </TableCell>
                  </TableRow>
                ))}
              {emptyRows > 0 && (
                <TableRow style={{ height: 53 * emptyRows }}>
                  <TableCell colSpan={6} />
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
        <TablePagination
          rowsPerPageOptions={[5, 10, 25]}
          component="div"
          count={count}
          rowsPerPage={rowsPerPage}
          page={page}
          onChangePage={handleChangePage}
          onChangeRowsPerPage={handleChangeRowsPerPage}
        >
          <div>
            <IconButton
              onClick={handleFirstPageButtonClick}
              disabled={page === 0}
              aria-label="first page"
            >
              {theme.direction === "rtl" ? <LastPageIcon /> : <FirstPageIcon />}
            </IconButton>
            <IconButton
              onClick={handleBackButtonClick}
              disabled={page === 0}
              aria-label="previous page"
            >
              {theme.direction === "rtl" ? (
                <KeyboardArrowRight />
              ) : (
                <KeyboardArrowLeft />
              )}
            </IconButton>
            <IconButton
              onClick={handleNextButtonClick}
              disabled={page >= Math.ceil(count / rowsPerPage) - 1}
              aria-label="next page"
            >
              {theme.direction === "rtl" ? (
                <KeyboardArrowLeft />
              ) : (
                <KeyboardArrowRight />
              )}
            </IconButton>
            <IconButton
              onClick={handleLastPageButtonClick}
              disabled={page >= Math.ceil(count / rowsPerPage) - 1}
              aria-label="last page"
            >
              {theme.direction === "rtl" ? <FirstPageIcon /> : <LastPageIcon />}
            </IconButton>
          </div>
        </TablePagination>
      </TableWrapper>
    </div>
  );
}
