import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import MaterialListTable from "./MaterialList-table/MaterialListTable";
import { MaterialListContext } from "./Context/MaterialListContext";
import axios from "axios";
import InputAdornment from "@mui/material/InputAdornment";
import Button from "@material-ui/core/Button";

import SearchIcon from "@mui/icons-material/Search";
import {
  ContentWrapper,
  AddButton,
  BoxStyled,
  ContentHeader,
  SearchBarButtonWrapper,
  handleSearchChange,
  SearchBox,
  contextData,
} from "./ListMaterialsStyles";
import DrawFilter from "./FilterSort";
const jsonData = [
  {
    title: "Technical Invitation",
    type: "Web application",
    created_by: {
      first_name: "John",
      last_name: "Doe",
    },
    technology: [
      {
        tech_id: "1",
        tech_name: "JavaScript",
      },
      {
        tech_id: "2",
        tech_name: "React",
      },
    ],
  },
  {
    title: "Angular questions",
    type: "Mobile application",
    created_by: {
      first_name: "Jane",
      last_name: "Smith",
    },
    technology: [
      {
        tech_id: "3",
        tech_name: "Java",
      },
      {
        tech_id: "4",
        tech_name: "Android",
      },
    ],
  },
  {
    title: "Java questions",
    type: "Desktop application",
    created_by: {
      first_name: "Bob",
      last_name: "Johnson",
    },
    technology: [
      {
        tech_id: "5",
        tech_name: "C#",
      },
      {
        tech_id: "6",
        tech_name: ".NET",
      },
    ],
  },
  {
    title: "React Native tasks",
    type: "AI",
    created_by: {
      first_name: "Mike",
      last_name: "Williams",
    },
    technology: [
      {
        tech_id: "7",
        tech_name: "Python",
      },
      {
        tech_id: "8",
        tech_name: "TensorFlow",
      },
    ],
  },
  {
    title: "Javascript questions",
    type: "Web application",
    created_by: {
      first_name: "Emily",
      last_name: "Jones",
    },
    technology: [
      {
        tech_id: "9",
        tech_name: "Ruby",
      },
      {
        tech_id: "10",
        tech_name: "Rails",
      },
    ],
  },
  {
    title: "Generic invitation",
    type: "Desktop application",
    created_by: {
      first_name: "David",
      last_name: "Miller",
    },
    technology: [
      {
        tech_id: "11",
        tech_name: "C++",
      },
      {
        tech_id: "12",
        tech_name: "Qt",
      },
    ],
  },
  {
    title: "Java tasks",
    type: "Mobile application",
    created_by: {
      first_name: "Jessica",
      last_name: "Brown",
    },
    technology: [
      {
        tech_id: "13",
        tech_name: "Swift",
      },
      {
        tech_id: "14",
        tech_name: "iOS",
      },
    ],
  },
  {
    title: ".Net questions",
    type: "AI",
    created_by: {
      first_name: "Richard",
      last_name: "Moore",
    },
    technology: [
      {
        tech_id: "15",
        tech_name: "Python",
      },
      {
        tech_id: "16",
        tech_name: "PyTorch",
      },
    ],
  },
  {
    title: "Mapii questions",
    type: "Web application",
    created_by: {
      first_name: "Ashley",
      last_name: "Taylor",
    },
    technology: [
      {
        tech_id: "17",
        tech_name: "PHP",
      },
      {
        tech_id: "18",
        tech_name: "Laravel",
      },
    ],
  },
  {
    title: "Star Trek questions",
    type: "Desktop application",
    created_by: {
      first_name: "Michael",
      last_name: "Anderson",
    },
    technology: [
      {
        tech_id: "19",
        tech_name: "C++",
      },
      {
        tech_id: "20",
        tech_name: "Qt",
      },
    ],
  },
];

export default function MaterialList() {
  const navigate = useNavigate();
  const [rowSelected, setRowSelected] = useState({});
  const [searchText, setSearchText] = useState("");
  // console.log("jsonData");
  // console.log(jsonData);
  const getInterviews = async () => {
    // place holder locaiton for axios call
    // axios
    //   .get(`fake link`)
    //   .then((response) => {
    //     // this is where the response would set the jsonData used in the table
    //   })
    //   .catch((err) => console.error(`material list ${err.message}`));
  };

  function handleTitleClickMaterial() {
    // console.log("rowSelected");
    // console.log(rowSelected);
    console.log("");
    console.log("rowSelected value");
    console.log(" " + rowSelected.title);
    console.log(" " + rowSelected.type);
    console.log(
      " " +
        rowSelected.created_by.first_name +
        " " +
        rowSelected.created_by.last_name
    );
    console.log(rowSelected.technology);
    console.log("");
    // navigate("/recruitment/placeholder", {
    //   state: { data: rowSelected},
    // });
  }

  function handleDeleteIconClickMaterial() {
    // console.log("rowSelected");
    // console.log(rowSelected);
    console.log("rowSelected delete");
    console.log(" " + rowSelected.title);
    console.log(" " + rowSelected.type);
    console.log(
      " " +
        rowSelected.created_by.first_name +
        " " +
        rowSelected.created_by.last_name
    );
    console.log(rowSelected.technology);
    console.log("");
    // navigate("/recruitment/placeholderDelete", {
    //   state: { data: rowSelected },
    // });
  }

  function handleNewMaterials() {
    alert("add new materials");
  } // create a function to handle changes to the search text
  const handleSearchChange = (event) => {
    setSearchText(event.target.value);
  };

  useEffect(() => {
    // getInterviews();
  }, []);
  return (
    <ContentWrapper>
      <>
        <DrawFilter />3
        <SearchBarButtonWrapper>
          <ContentHeader>
            <SearchBox
              // label="Find the Material by Title"
              // component={Paper}
              // value={searchText}
              placeholder="Find the Material by Title"
              onChange={handleSearchChange}
              elevation={3}
              inputProps={{
                style: {
                  background: "var(--bg-primary)",
                  width: "100%",
                  marginLeft: "5px",
                  marginRight: "auto",
                  marginBottom: "5px",
                },
              }}
              endAdornment={<SearchIcon sx={{ color: "var(--disabled)" }} />}
            />
          </ContentHeader>

          <AddButton variant="contained" onClick={() => handleNewMaterials()}>
            Add New Matterial
          </AddButton>
        </SearchBarButtonWrapper>
        <MaterialListContext.Provider
          value={{
            jsonData,
            setRowSelected,
            searchText,
            setSearchText,
            handleTitleClickMaterial,
            handleDeleteIconClickMaterial,
            handleNewMaterials,
          }}
        >
          <MaterialListTable />
        </MaterialListContext.Provider>
      </>
    </ContentWrapper>
  );
}
