import React, { useEffect, useReducer } from "react";
// import Fab from "@mui/material/Button";
import Fab from "@mui/material/Button";
import TuneRoundedIcon from "@mui/icons-material/TuneRounded";
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";
import {
  StyledSwipeableDrawer,
  SwipeableDrawerTypography,
  FilterSortContainer,
} from "./FilterSortStyles";

const fabStyles = {
  backgroundColor: "var(--bg-primary)",
  borderRadius: "1rem 0 0 1rem",
  width: "3rem",
  margin: "1rem 0 auto 0",
  boxShadow: "0 0 0 0.05rem rgba(115, 115, 115, 0.6)",
  transition: "all 0.25s ease-in-out",
  "&:hover": {
    backgroundColor: "var(--bg-primary)",
    scale: "1.2",
    transform: "translateX(-0.2rem)",
  },
};

export default function DrawFilter() {
  return (
    <FilterSortContainer sx={{ zIndex: 99 }} variant="extended">
      <Fab
        variant="extended"
        // onClick={() => dispatch({ type: "drawer", sesame: "open" })}
        sx={fabStyles}
      >
        <TuneRoundedIcon />
      </Fab>
      <StyledSwipeableDrawer anchor="right" open={false} variant="persistent">
        {/* s,dknflen */}
        <Fab
          // id="drawer-close"
          // onClick={() => dispatch({ type: "drawer", sesame: "close" })}
          sx={{
            ...fabStyles,
            left: "-3.75rem",
          }}
        >
          <CloseRoundedIcon />
        </Fab>
      </StyledSwipeableDrawer>
    </FilterSortContainer>
  );
}
