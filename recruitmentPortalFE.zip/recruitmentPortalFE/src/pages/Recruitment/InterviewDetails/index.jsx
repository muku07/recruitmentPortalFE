import * as React from "react";
import { useState } from "react";
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import { useNavigate, useLocation } from "react-router-dom";
import {
  ContentRightSide,
  ContentLeftSide,
} from "./InterviewDetailsContent/InterviewDetailsContent";
import { InterviewerDetailsContext } from "./Contexts/InterviewDetailsContext";
import {
  ContentWrapper,
  ContentDisplay,
  EditPanelButton,
  IconColor,
  BackButtonWrapper,
  TopButtonWrapper,
  ArrowBackIosIconStyle,
  ArrowBackIosIconWapper,
  DocumentTitleBackButton,
} from "./InterviewDetailsStyles";

function InterviewDetails() {
  const navigate = useNavigate();
  let locationData = useLocation();
  console.log("this is all the data");
  console.log(locationData.state);
  const [interviewers, setInterviewers] = useState([]);
  const [inteviewersOutside, setInterviewersOutside] = useState(
    locationData.state.externalInterviewerEmailId
  );
  function backButton() {
    navigate("/recruitment");
  }

  function handleEditInterviewClick() {
    // console.log("interviewers interviewers interviewers");
    // console.log(interviewers);
    navigate("/recruitment/edit-details", {
      state: { data: locationData, interviewers, inteviewersOutside },
    });
  }

  // useEffect(() => {}, []);
  return (
    <ContentWrapper>
      <TopButtonWrapper>
        <BackButtonWrapper>
          <ArrowBackIosIconWapper onClick={() => backButton()}>
            <IconColor>
              <ArrowBackIosIconStyle>
                <ArrowBackIosIcon />
              </ArrowBackIosIconStyle>
            </IconColor>

            <DocumentTitleBackButton styles={{ "margin-left": "15px" }}>
              {" "}
              Interview Details
            </DocumentTitleBackButton>
          </ArrowBackIosIconWapper>
        </BackButtonWrapper>
        <EditPanelButton
          onClick={() => handleEditInterviewClick()}
          variant="contained"
        >
          Edit Interview
        </EditPanelButton>
      </TopButtonWrapper>

      <ContentDisplay data-testid="contentDisplay">
        <InterviewerDetailsContext.Provider
          value={{
            interviewers,
            setInterviewers,
            locationData,
            inteviewersOutside,
            setInterviewersOutside,
          }}
        >
          <ContentLeftSide />
          <ContentRightSide />
        </InterviewerDetailsContext.Provider>
      </ContentDisplay>
    </ContentWrapper>
  );
}

export default InterviewDetails;
