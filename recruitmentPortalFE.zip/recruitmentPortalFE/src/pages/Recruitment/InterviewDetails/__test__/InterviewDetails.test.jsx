
import InterviewDetails from "..";
import {
  render,
  fireEvent,
  screen,
  shallow,
  getByTestId,
} from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import React from "react";

let component;

beforeEach(() => {
  component = render(<InterviewDetails />);
});

test("Testing that the InterviewDetails page renders", () => {
  render(<InterviewDetails />);
});

test("Testing that left and right content loads", () => {
  const contentDisplay = component.getAllByTestId("contentDisplay")[0];
  let content =
    "Interview will occure:11NovemberThursday12:30 PM 1:00 PMtype of interviewTechnical interviewJob TitleJava developerIntervieweeJohn SpartanCandidateIDEmailPhone number117masterchief@hotmail.co.uk34324923497Download Assestment formDownload Candidate CVInterveiwersDoctor JonesSofthware EnigneerDoctor Who.net somethingIndiana Jonespython somethingPeople outside organizationDoctor Jonesjones@hotmail.co.ukDoctor Whodoctor@gmail.comIndiana Jonestest@gmail.com";
  expect(contentDisplay.textContent).toBe(content);
});

test("Testing that  right content loads", () => {
    const contentDisplayRight = component.getAllByTestId("contentDisplayRight")[0];
    let content =
    "InterveiwersDoctor JonesSofthware EnigneerDoctor Who.net somethingIndiana Jonespython somethingPeople outside organizationDoctor Jonesjones@hotmail.co.ukDoctor Whodoctor@gmail.comIndiana Jonestest@gmail.com"
      expect(contentDisplayRight.textContent).toBe(content);
  });

  test("Testing that left  content loads", () => {
    const contentDisplayLeft = component.getAllByTestId("contentDisplayLeft")[0];
    let content =
    "Interview will occure:11NovemberThursday12:30 PM 1:00 PMtype of interviewTechnical interviewJob TitleJava developerIntervieweeJohn SpartanCandidateIDEmailPhone number117masterchief@hotmail.co.uk34324923497Download Assestment formDownload Candidate CV"
    
    expect(contentDisplayLeft.textContent).toBe(content);
  });
 

  
