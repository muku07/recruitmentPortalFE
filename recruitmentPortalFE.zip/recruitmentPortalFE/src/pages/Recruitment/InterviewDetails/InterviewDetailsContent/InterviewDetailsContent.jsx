import React, { useContext, useState, useEffect } from "react";
import Avatar from "@mui/material/Avatar";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import axios from "axios";
import { InterviewerDetailsContext } from "../Contexts/InterviewDetailsContext";
import {
  ContentDisplayLeft,
  ContentDisplayRight,
  ContentInterviewDetails,
  ContentInterviewers,
  DownloadButtonWrapper,
  DownloadForm,
  DownloadCV,
  SensorCandidateWrapper,
  CondidateNameWrapper,
  IconColor,
  CandidateInfo,
  CondidateCellStyle,
  TableContainerStyle,
  TableCelltyle,
  TypeInterviewJobTitleWrapper,
  TypeJobTitleStyleHeader,
  TypeJobTitleStyleDetail,
  SensorOccupiedIconStyle,
  InterviewersStyle,
  InterviewersRoleStyle,
  Interviewers,
  InterviewerProfile,
} from "./InterviewDetailsStyles";

function ContentLeftSide() {
  const contextData = useContext(InterviewerDetailsContext);
  const DATETIME = new Date(
    contextData.locationData.state.interviewStartDateTime
  );

  const date = pad(DATETIME.getDate());

  // const month = new Date(data.interviewStartDate).toLocaleString(
  //   'default', {weekday: 'long',month:'long', hour:'numeric',minute:"numeric"}
  // );
  const day = new Date(
    contextData.locationData.state.interviewStartDateTime
  ).toLocaleString("default", {
    weekday: "long",
  });
  const month = new Date(
    contextData.locationData.state.interviewStartDateTime
  ).toLocaleString("default", {
    month: "long",
  });
  const timeStart = new Date(
    contextData.locationData.state.interviewStartDateTime
  ).toLocaleString("default", { hour: "numeric", minute: "numeric" });
  const timeEnd = new Date(
    contextData.locationData.state.interviewEndDateTime
  ).toLocaleString("default", {
    hour: "numeric",
    minute: "numeric",
  });

  function pad(n) {
    return n < 10 ? "0" + n : n;
  }

  // var monthNames = [
  //   "January",
  //   "February",
  //   "March",
  //   "April",
  //   "May",
  //   "June",
  //   "July",
  //   "August",
  //   "September",
  //   "October",
  //   "November",
  //   "December",
  // ];

  return (
    <ContentDisplayLeft data-testid="contentDisplayLeft">
      <ContentInterviewDetails>
        <div style={{ fontWeight: "bold" }}>Interview will occure:</div>
        <div style={{ fontWeight: "bold", fontSize: "35px" }}>{date}</div>
        <div style={{ fontWeight: "bold" }}>{month}</div>
        {day}
        <div style={{ fontWeight: "bold", color: "rgb(32, 92, 233)" }}>
          {/* 12:30 PM 1:00 PM - placeholder */}
          {timeStart} {timeEnd}
        </div>
        <br />
        <TypeInterviewJobTitleWrapper>
          <TypeJobTitleStyleDetail>
            <TypeJobTitleStyleHeader>type of interview</TypeJobTitleStyleHeader>
            {/* Technical interview */}
            {contextData.locationData.state.interviewType.interviewTypeName}
          </TypeJobTitleStyleDetail>
        </TypeInterviewJobTitleWrapper>
        {CandidateInformationTable()}
        <DownloadButtonWrapper>
          <DownloadForm
            onClick={() => alert("Assestment form")}
            variant="contained"
          >
            Download Assestment form
          </DownloadForm>
          <DownloadCV onClick={() => alert("Candidate CV")} variant="contained">
            Download Candidate CV
          </DownloadCV>
        </DownloadButtonWrapper>
      </ContentInterviewDetails>
    </ContentDisplayLeft>
  );
}

function CandidateInformationTable() {
  const contextData = useContext(InterviewerDetailsContext);

  return (
    <TableContainerStyle data-testid="tableContainerStyle">
      <div style={{ fontSize: 12, marginTop: 10 }}>Interviewee</div>
      <Table sx={{ minWidth: 650, p: 50 }} aria-label="simple table">
        <TableBody>
          <div>
            <CandidateInfo>
              <SensorCandidateWrapper align="left">
                <IconColor>
                  <SensorOccupiedIconStyle />
                </IconColor>
                <CondidateNameWrapper>
                  {contextData.locationData.state.candidate.firstName}{" "}
                  {contextData.locationData.state.candidate.lastName}
                  <div style={{ fontSize: "11px", color: "rgb(32, 92, 233)" }}>
                    Candidate
                  </div>
                </CondidateNameWrapper>
              </SensorCandidateWrapper>
              <TableHead align="center">
                <TableRow>
                  <TableCelltyle align="center">
                    <CondidateCellStyle>ID</CondidateCellStyle>
                  </TableCelltyle>
                  <TableCelltyle align="center">
                    <CondidateCellStyle>Email</CondidateCellStyle>
                  </TableCelltyle>
                  <TableCelltyle align="center">
                    <CondidateCellStyle>Phone number</CondidateCellStyle>
                  </TableCelltyle>
                </TableRow>
              </TableHead>
              <TableRow
                sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
              >
                <TableCelltyle sx={{ m: 50 }} component="th" scope="row">
                  {contextData.locationData.state.candidate.candidateId}
                </TableCelltyle>
                <TableCelltyle component="th" scope="row">
                  {contextData.locationData.state.candidate.emailId}
                </TableCelltyle>
                <TableCelltyle component="th" scope="row">
                  {contextData.locationData.state.candidate.mobileNumber}
                </TableCelltyle>
              </TableRow>
            </CandidateInfo>
          </div>
        </TableBody>
      </Table>
    </TableContainerStyle>
  );
}

function ContentRightSide() {
  const dataContext = useContext(InterviewerDetailsContext);
  const mappedOutside =
    dataContext.locationData.state.externalInterviewerEmailId.split(",");
  const intervieweesOutside = mappedOutside.join(", ");
  console.log(intervieweesOutside);
  const getInterviews = async () => {
    // needs to be used to set outside interviewers but I don't have any
    // exact endpoint to do that yet
    dataContext.locationData.state.userIds.map((content) => {
      axios
        .get(
          `https://mapii-portal-profile-service.azurewebsites.net/profile/${content}`
        )
        .then((response) => {
          // console.log("second axios call " + response.data.userId);
          // console.log(response.data);

          dataContext.setInterviewers((prevState) => [
            ...prevState,
            response.data,
          ]);
        })
        .catch((err) => console.error(`interviewers ${err.message}`));
    });
  };

  useEffect(() => {
    getInterviews();
  }, []);

  return (
    <ContentDisplayRight data-testid="contentDisplayRight">
      {/* {console.error(`data`)}
      {console.error(dataContext)} */}
      <ContentInterviewers>
        Interviewers
        <br />
        <Interviewers>
          {dataContext.interviewers.map((content) => {
            return (
              <div style={{ display: "flex" }}>
                <InterviewerProfile>
                  <Avatar />
                </InterviewerProfile>

                <div styles={{ marginTop: 1 }}>
                  <InterviewersStyle>
                    {content.firstName} {content.lastName}
                  </InterviewersStyle>

                  <InterviewersRoleStyle>
                    {content.designationName}
                  </InterviewersRoleStyle>
                </div>
              </div>
            );
          })}
        </Interviewers>
        <br />
        <div style={{ fontWeight: "bold" }}>People outside organization</div>
        <Interviewers>{intervieweesOutside}</Interviewers>
      </ContentInterviewers>
    </ContentDisplayRight>
  );
}
export { ContentRightSide, ContentLeftSide, CandidateInformationTable };
