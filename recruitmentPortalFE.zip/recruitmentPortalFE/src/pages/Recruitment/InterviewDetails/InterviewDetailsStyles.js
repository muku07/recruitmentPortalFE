
import styles from "styled-components";
import { styled } from "@mui/material/styles";
import Button from "@mui/material/Button";
import { Card, Stack, TextField } from "@mui/material";
import InputBase from "@mui/material/InputBase";
import Box from "@mui/material/Box";
import TableContainer from "@mui/material/TableContainer";
import TableCell from "@mui/material/TableCell";
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import SensorOccupiedIcon from "@mui/icons-material/SensorOccupied";
export const ContentWrapper = styles.div`

   margin-top:-2%;
   display:grid;
   grid-template-rows: auto auto;
   width:85%;
`;

export const ContentDisplay = styles.div`
 padding:5px;
 display:flex;
 margin-top:1%;
//  height:500PX;
`;

export const ContentDisplayLeft = styles.div`
  
width:1250px;
`;
export const ContentDisplayRight = styles.div`

width:250px;
margin-left:-25%;


`;

export const ContentInterviewDetails = styled(Card)`
  padding: 1rem 1rem;
  padding-left: 25px;
  width: 70%;
  height: 470px;
`;

export const ContentInterviewers = styled(Card)`
  padding: 1rem 1rem;
  margin-left: 20px;
  height: 470px;
`;

export const EditPanelButton = styled(Button)`
  float: right;
  max-width: fit-content;
  max-height: 30px;
  margin-top: 3.5%;
  /* margin-left:87.5%; */
  margin-left: 51%;
`;

export const DownloadButtonWrapper = styled("div")`
  // position: fixed;
  // bottom: 0px;
  // right: 0px;

  margin-left: 54%;
  margin-top: 4%;
  display: flex;
`;

export const DownloadForm = styled(Button)`
  /* margin-left: 30%; */
  max-width: fit-content;
  max-height: 25px;
  font-size: 10px;
`;

export const DownloadCV = styled(Button)`
  margin-left: 10px;
  max-width: fit-content;
  max-height: 30px;
  max-height: 25px;
  font-size: 10px;
`;

export const SensorCandidateWrapper = styled("div")`
  display: flex;
`;

export const CondidateNameWrapper = styled("div")`
  margin-left: 2px;
  margin-top: 2px;
  font-size: 12px;
`;

export const IconColor = styles.div`  
   color:white;
   height:35px;
   width:35px;
   padding:2px;
   border-radius:50%;
   background-color:rgb(32, 92, 233);

`;

export const SensorOccupiedIconStyle = styled(SensorOccupiedIcon)`
  font-size: x-large;
  margin-left: 3.5px;
  margin-right: auto;
`;

export const SearchBox = styled(TextField)`
  background: var(--bg-primary);

  width: 100%;
  margin-left: auto;
  margin-right: auto;
  margin-top: 2%;
  font-size: larger;
`;

export const CandidateInfo = styles.div`

  font-weight: bolder;
  font-size: large;
  margin-left:2%;
  margin-top:2%;

`;

export const CondidateCellStyle = styles.div`
color:rgb(32, 92, 233);
  font-weight: bold;
`;

export const TableContainerStyle = styled(TableContainer)`
  /* margin-left: auto; */
  /* margin-right: auto; */
  margin-top: 5px;
  max-width: 90%;
`;

export const TableCelltyle = styled(TableCell)`
  padding-left: 70px;
  padding-right: 70px;
  max-width: 90%;
`;

export const InterviewDate = styles.div`
`;
export const InterviewMonth = styles.div`
`;
export const InterviewTime = styles.div`
`;
export const InterviewType = styles.div`
`;

export const TypeInterviewJobTitleWrapper = styles.div`
display:flex;
`;

export const TypeJobTitleStyleHeader = styles.div`
color:rgb(32, 92, 233);
font-weight:bold;
`;

export const TypeJobTitleStyleDetail = styles.div`
margin-right:80px;

`;

export const InterviewersStyle = styles.div`
font-size:11px;
font-weight:bold;
padding-top:8px;

`;
export const InterviewersRoleStyle = styles.div`
font-size:9px;
color:rgb(32, 92, 233);
`;

export const Interviewers = styles.div`
margin-left:10px;
margin-top:10px;
`;

export const BackButtonWrapper = styled("div")`
  font-weight: bolder;
  font-size: 20px;
  margin-top: 3%;
  &:hover{
    cursor: pointer;
    opacity: .7;
  }
  /* margin-left: 10%; */
`;

export const TopButtonWrapper = styles.div`
display:flex;
`;

export const ArrowBackIosIconStyle = styled(ArrowBackIosIcon)`
  font-size: large;
  margin-left: 9px;
  margin-bottom: 4px;
`;

export const ArrowBackIosIconWapper = styles.div`  

   display:flex;
   
`;


export const DocumentTitleBackButton = styles.div`
margin-left:10px;
margin-top:2px;
`;


export const InterviewerProfile= styled('div')`
padding:5px;
`;