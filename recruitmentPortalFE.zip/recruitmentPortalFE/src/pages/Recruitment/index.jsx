import * as React from "react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

import { Button } from "@mui/material";
import { ContentWrapper, Title, StyledTabList, StyledTab, StyledTabPanel } from "./RecruitmentStyles";

import RetrievePanel from "./RetrievePanel";
import Candidates from "./Candidates";
import Availability from "./Availability";

import Box from '@mui/material/Box';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';


const TabViewStatus = {
    RETRIEVE_PANEL: "retrievePanel",
    AVAILABILITY: "availability",
    CANDIDATES: "candidate",
};


export default function Recruitment() {
    const navigate = useNavigate();

    const [view, setView] = useState(TabViewStatus.RETRIEVE_PANEL);

    return (
      <>
        <ContentWrapper data-testid="contentWrapper">
          <Title>
              <span>Interviews</span>

              <Button
                variant="contained"
                onClick={() => navigate("/recruitment/interview")}
                data-testid="scheduleInterviewButton"
              >
                  Schedule an interview
              </Button>
          </Title>

          <Box>
            <TabContext value={view}>
              <Box>
                <TabList
                  onChange={(e, value) => setView(value)}
                  aria-label="Recruitment Tabs"
                  variant="fullWidth"
                  centered
                  >
                  <Tab label="Retrieve Panel" value={TabViewStatus.RETRIEVE_PANEL} data-testid="retrieveTab"/>
                  <Tab label="Availability" value={TabViewStatus.AVAILABILITY} data-testid="availabilityTab"/>
                  <Tab label="Candidates" value={TabViewStatus.CANDIDATES} data-testid="candidatesTab"/>
                </TabList>
              </Box>
              <TabPanel value={TabViewStatus.RETRIEVE_PANEL} >
                <RetrievePanel />
              </TabPanel>
              <TabPanel value={TabViewStatus.AVAILABILITY} >
                <Availability />
              </TabPanel>
              <TabPanel value={TabViewStatus.CANDIDATES} >
                <Candidates />
              </TabPanel>
            </TabContext>
          </Box>

        </ContentWrapper>
      </>
    )
}