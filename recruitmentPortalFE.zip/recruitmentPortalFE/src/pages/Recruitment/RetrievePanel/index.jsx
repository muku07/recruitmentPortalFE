import * as React from "react";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { Scheduler, WeekView, Toolbar, DateNavigator, Appointments, AppointmentTooltip  } from '@devexpress/dx-react-scheduler-material-ui';
import { ViewState } from '@devexpress/dx-react-scheduler';
import { Stack, Box, getCircularProgressUtilityClass } from '@mui/material';
import { DateTime } from "luxon";

import { ToolbarKey, ToolbarWrapper, BoxKey } from "./RetreievePanelStyles";

const colours = [
    "#F1948A",
    "#BB8FCE",
    "#85C1E9",
    "#82E0AA",
    "#F7DC6F",
    "#FA99ED",
    "#64B5F6"]; // <-- default colour

export default function RetrievePanel() {
    const navigate = useNavigate();

    const [technologies, setTechnologies] = useState([]);
    const [scheduleData, setScheduledData] = useState([]);
    const [interviewsData, setInterviewsData] = useState([]);
    const [currentDate, setCurrentDate] = useState(DateTime.now());

    const customToolbarSpaceComponent = (props) => {
        return (
            <ToolbarWrapper>
                <ToolbarKey spacing={2.5} direction="row">
                    {technologies.map((tech, i) => (
                        <Stack spacing={1} direction="row">
                            <BoxKey sx={{backgroundColor: colours[i]}}/>
                            <span>{tech.techName}</span>
                        </Stack>
                    ))}
                </ToolbarKey>
            </ToolbarWrapper>
        )
    }

    // function getColourByTechId(props) {
    //     var toReturn = 6;
    //     technologies.forEach((tech, i) => {
    //         if (props.data.techId === tech.techId) {
    //             toReturn = i;
    //         }
    //     });
    //     return toReturn;
    // }

    const CustomAppointment = ({
        children, onClick, style, ...restProps
      }) => (
        <Appointments.Appointment
          {...restProps}
        //   style={{
        //     ...style,
        //     backgroundColor: colours[getColourByTechId(restProps)],
        //     borderRadius: '8px',
        //   }}
          onClick={() => goToInterviewDetails(restProps.data)}
        >
          {children}
        </Appointments.Appointment>
    );

    function goToInterviewDetails(props) {
        console.log(interviewsData[props.id]);
        navigate("/recruitment/interview-details", {state: interviewsData[props.id]});
    }

    function GetAllTechnologyTypes() {
        const url = " https://mapii-recruitment-panel.azurewebsites.net/RecruitmentMaterial/technologies";
        axios.get(url,
            {
                headers: {
                  "Access-Control-Allow-Origin": "*",
                },
            })
            .then(res => {
                setTechnologies(res.data.slice(0,6));
            })
            .catch(error => {
                console.log(error);
            }
        );
    }
    
    function GetAllInterviews() {
        const url = "https://mapii-recruitment-interview.azurewebsites.net/interviews";
        axios.get(url, 
            {
                headers: {
                  "Access-Control-Allow-Origin": "*",
                },
            })
            .then(res => {
                console.log(res.data);
                var formatted = [];
                res.data.forEach((interview, i) => {
                    formatted = [...formatted, {
                        id: i,
                        startDate: interview.interviewStartDateTime,
                        endDate: interview.interviewEndDateTime,
                        title: interview.candidate.firstName + " " + interview.candidate.lastName,
                        //techId: interview.userIdOne.technology.techId
                        }]
                });
                console.log(formatted);
                setScheduledData(formatted);
                setInterviewsData(res.data);
                
            })
            .catch(error => {
                console.log(error);
            }
        );
        // MOCK DATA
        // setScheduledData([
        //     {startDate: '2022-11-23T14:00', endDate: '2022-11-23T15:30', title: 'Josh Brodski'},
        //     {startDate: '2022-11-24T11:00', endDate: '2022-11-24T12:15', title: 'Norville Rogers'},
        //     {startDate: '2022-11-24T10:00', endDate: '2022-11-24T13:30', title: 'Gary Palecki'},
        //     {startDate: '2022-11-21T16:00', endDate: '2022-11-21T17:00', title: 'Minnie Christy'},
        //     {startDate: '2022-11-28T15:00', endDate: '2022-11-28T15:45', title: 'Divya Kumari'},
        //     {startDate: '2022-11-28T15:45', endDate: '2022-11-28T16:15', title: 'Jokasta Karczewska'}
        // ]);
    }

    useEffect(() => {
        //GetAllTechnologyTypes();
        GetAllInterviews();
    }, []);

    return (
        <div
            data-testid="schedular"
        >
            <Scheduler
                data={scheduleData}
                height={700}
                firstDayOfWeek={1}
                >
                <ViewState
                    currentDate={currentDate}
                    onCurrentDateChange={e => setCurrentDate(e)}
                />

                <WeekView
                    excludedDays={[0,6]}
                    startDayHour={6}
                    endDayHour={22}
                    cellDuration={60}
                    intervalCount={1}
                />

                <Toolbar flexibleSpaceComponent={customToolbarSpaceComponent}/>
                <DateNavigator />
                <Appointments 
                    appointmentComponent={CustomAppointment}
                />
            </Scheduler>
        </div>
    );
}