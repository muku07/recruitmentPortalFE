import { styled } from "@mui/material/styles";
import { Stack, Box } from '@mui/material';
import { WeekView } from '@devexpress/dx-react-scheduler-material-ui';


export const ToolbarKey = styled(Stack)`
    margin: auto !important;
    align-items: center;
    text-align: center;
`;

export const ToolbarWrapper = styled('div')`
    margin-left: auto;
`;

export const BoxKey = styled(Box)`
    width: 25px;
    height: 25px;
    border-radius: 3px;
`;