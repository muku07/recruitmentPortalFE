import RetrievePanel from "..";
import {
    render,
    fireEvent,
    screen,
    shallow,
    getByTestId,
  } from "@testing-library/react";
  import { Routes, Route, MemoryRouter } from "react-router-dom";
import "@testing-library/jest-dom/extend-expect";
import React from "react";

const renderComponent = () => {
    render(
        <MemoryRouter>
            <Routes>
                <Route
                    path="/"
                    element={<RetrievePanel />}
                 />
            </Routes>
        </MemoryRouter>
    )
};

test("Does Component Render?", async () => {
    renderComponent();

    var schedular = await screen.findByTestId("schedular");
    expect(schedular).toBeInTheDocument();
});