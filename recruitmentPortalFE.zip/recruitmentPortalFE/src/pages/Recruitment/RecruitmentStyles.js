import { styled } from "@mui/material/styles";
import TabList from "@mui/lab/TabList";
import TabPanel from "@mui/lab/TabPanel";
import Tab from "@mui/lab/TabPanel";

export const ContentWrapper = styled('div')`
  margin: auto !important;
  padding: 1.5rem 0rem;
  height: auto;
  width: 80%;
`;

export const Title = styled('div')`
  padding: 1rem 0rem;
  display: flex;
  align-items: center;
  gap: 8px;

  span {
    text-align: center;
    font-weight: 500;
    font-size: 1.5rem;
  }

  button {
    margin-left: auto;
  }
`;

export const StyledTabList = styled(TabList)`
  min-height: 2rem;
  margin: 0.3rem 0;
`;

export const StyledTab = styled(Tab)`
  max-height: 2rem;
  /* &.Mui-selected {
    font-weight: 700;
  }
  & {
    max-height: 2rem;
    min-height: 2rem;
  } */
`;

export const StyledTabPanel = styled(TabPanel)`
  padding: 0;
  display: grid;
  grid-gap: 1rem;
  grid-template-columns: repeat(auto-fill, minmax(15rem, 5fr));
  grid-template-rows: repeat(auto-fill, minmax(18rem, 1fr));
  justify-content: space-between;
  grid-auto-flow: row;
  margin-bottom: 1rem;
`;
