import * as React from "react";
import { useState } from "react";

export default function Availability() {
    
    
    return (
        <>
        Availability Tab
        </>
    )
}