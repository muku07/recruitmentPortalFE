
import { styled } from "@mui/material/styles";
import { Card, Stack, TextField } from "@mui/material";

export const ContainerCard = styled(Card)`
    padding: 2rem 3rem;
`;

export const Title = styled('div')`
    font-size: 1.4rem;
    font-weight: 500rem;
`;

export const HStack = styled(Stack)`
    direction: row;
    justify-content: center;
    align-items: center;
`;

export const StackItem = styled('div')``;

export const StyledTextField = styled(TextField)`
    width: 100%;
`
