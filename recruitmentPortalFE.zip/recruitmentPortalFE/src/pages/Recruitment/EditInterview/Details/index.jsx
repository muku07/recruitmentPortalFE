import { useState, useRef, useEffect } from "react";
import { useContext } from "react";
import axios from "axios";
import * as React from "react";
import dayjs, { Dayjs } from "dayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { TimePicker } from "@mui/x-date-pickers/TimePicker";
import { CalendarPicker } from "@mui/x-date-pickers/CalendarPicker";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
// import { Interview } from "../Interfaces";
import { DateTime } from "luxon";
import { PickerOnChangeFn } from "@mui/x-date-pickers/internals/hooks/useViews";
import { PickerSelectionState } from "@mui/x-date-pickers/internals";
import { AdapterLuxon } from "@mui/x-date-pickers/AdapterLuxon";
import { EditInterviewerDetailsContext } from "../Context/InterviewEditDetailsContext";
import {
  ContainerCard,
  Title,
  HStack,
  StackItem,
  StyledTextField,
} from "./DetailsStyles";

import { Grid, TextField } from "@mui/material";

import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Selected, { SelectChangeEvent } from "@mui/material/Select";
import { makeStyles } from "@material-ui/core/styles";
import ArrowBackIosNewIcon from "@mui/icons-material/ArrowBackIosNew";

const useStyles = makeStyles({
  arrow: {
    transform: "rotate(-90deg)",
    color: "blue",
  },
  label: {
    fontWeight: "bold",
    color: "blue",
  },
});

export default function Details() {
  const contextData = useContext(EditInterviewerDetailsContext);
  // this is to be added due to figma style to be changed, the idea I beleive
  // is to use it to hold the dropdown list of tech options then use it to assign
  // the assesment form for the contextData.SetAssessmentForm("") value
  const [techSelection, setTechSelection] = useState([
    { techName: "java", techId: 2 },
    { techName: ".Net", techId: 1 },
  ]);
  const classes = useStyles();

  function GetAssessmentFormTypes() {
    const url = "https://recruitmentservice-mapii.azurewebsites.net/getall"; // check this link is for the correct API
    axios
      .get(url)
      .then((res) => {
        // contextData.SetAssessmentForm();
        // setTechSelection(res.data);
        console.log("techSelection");
        console.log(techSelection);
      })
      .catch((error) => {
        console.log(error);
      });
  }

  function assessmentFormOnChange(event) {
    // const index = event.target.options.selectedIndex;
    // var idKey = event.target.options[index].getAttribute("data-key");
    // interview.SetAssessmentForm(event.target.value);
    // interview.SetAssessmentFormID(idKey);
  }

  function updateCalendarPickerEvent(e) {
    contextData.setStartDateTime(new Date(e.valueOf()).setHours(16, 0, 0, 0));
    contextData.setEndDateTime(new Date(e.valueOf()).setHours(17, 0, 0, 0));
  }

  useEffect(() => {
    // GetAssessmentFormTypes();
  }, []);

  const handleChanges = (event: SelectChangeEvent) => {
    // console.log("event");
    // console.log(event.target.value);
    // console.log("tempInterviewers");
    // console.log(tempInterviewers);

    let selectedTech = event.target.value;
    // console.log("selectedTech");
    // console.log(selectedTech);

    const selectedObject = techSelection.find(
      (item) => item.techName === selectedTech
    );

    // console.log("selectedObject");
    // console.log(selectedObject);

    // this allows a list of multiple techs to be added but
    // would have to apply a method for a mistaken tech selected to be removed
    // contextData.setTechnologies((prevState) =>
    //   prevState.length == 0 ? [selectedObject] : [...prevState, selectedObject]
    // );
    contextData.setTechnologies([selectedObject]);

    // console.log("contextData.technologies");
    // console.log(contextData.technologies);ata.chips, event.target.value]);
    // contextData.setCurrentChip("");
  };
  return (
    <ContainerCard data-testid="container">
      <Title>Set the details</Title>

      <LocalizationProvider dateAdapter={AdapterDayjs}>
        <HStack direction="row" spacing={3}>
          <StackItem data-testid="dateCalendarPicker">
            <LocalizationProvider
              dateAdapter={AdapterLuxon}
              adapterLocale={"en-gb"}
            >
              <CalendarPicker
                disablePast
                // onChange={(e) => contextData.setStartDateTime(e.valueOf())}
                onChange={(e) => updateCalendarPickerEvent(e)}
                renderInput={(params) => <TextField {...params} />} // unsure what IDE error is - works anyways?
              />
            </LocalizationProvider>
          </StackItem>

          <StackItem sx={{ pb: 3 }}>
            <Grid container columnSpacing={2} rowSpacing={2}>
              <Grid item xs={12}>
                <StyledTextField
                  style={{
                    backgroundColor: "rgb(240,240,240)",
                  }}
                  InputLabelProps={{
                    style: {
                      fontWeight: "bold",
                      color: "blue",
                    },
                  }}
                  id="dateTextField"
                  data-testid="dateTextField"
                  value={new Date(contextData.startDateTime).toLocaleDateString(
                    "en-gb"
                  )} // unsure what IDE error is - works anyways?
                  label="Date"
                />
              </Grid>
              <Grid item xs={6}>
                <LocalizationProvider
                  dateAdapter={AdapterLuxon}
                  adapterLocale={"en-gb"}
                >
                  <TimePicker
                    data-testid="startTimePicker"
                    label={<span className={classes.label}>Start Time</span>}
                    value={new Date(contextData.startDateTime)}
                    onChange={(d) =>
                      contextData.setStartDateTime(d !== null ? d : Date.now())
                    }
                    renderInput={(params) => (
                      <TextField {...params} fullWidth />
                    )}
                  />
                </LocalizationProvider>
              </Grid>
              <Grid item xs={6}>
                <LocalizationProvider
                  dateAdapter={AdapterLuxon}
                  adapterLocale={"en-gb"}
                >
                  <TimePicker
                    data-testid="endTimePicker"
                    label={<span className={classes.label}>End Time</span>}
                    value={new Date(contextData.endDateTime)}
                    onChange={(d) =>
                      contextData.setEndDateTime(d !== null ? d : Date.now())
                    }
                    renderInput={(params) => (
                      <TextField {...params} fullWidth />
                    )}
                  />
                </LocalizationProvider>
              </Grid>

              <Grid item xs={12}>
                <FormControl style={{ width: "100%", fontSize: "25px" }}>
                  <InputLabel
                    id="demo-simple-select-label"
                    // style={{ fontSize: "12px" }}
                  >
                    Select Technology
                  </InputLabel>
                  <Selected
                    boxShadow={1}
                    label="Select Technology"
                    IconComponent={ArrowBackIosNewIcon}
                    classes={{ icon: classes.arrow }}
                    onChange={handleChanges}
                    style={{
                      width: "100%",
                      // height: "50px",
                      // backgroundColor: "rgb(240,240,240)",
                      // fontSize: "12px",
                    }}
                  >
                    {techSelection.map((item) => (
                      <MenuItem
                        key={item.id}
                        value={item.techName}
                        style={{ fontSize: "12px" }}
                      >
                        {item.techName}
                      </MenuItem>
                    ))}
                  </Selected>
                </FormControl>
              </Grid>
            </Grid>
          </StackItem>
        </HStack>
      </LocalizationProvider>
    </ContainerCard>
  );
}
