import * as React from "react";
import { useState, useContext } from "react";
import SearchIcon from "@mui/icons-material/Search";
import broSvg from "../../../../assets/bro.svg";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import axios from "axios";
import Typography from "@mui/material/Typography";
import { TextField, Box } from "@mui/material";
import { EditInterviewerDetailsContext } from "../Context/InterviewEditDetailsContext";
import {
  ContentWrapper,
  ContentHeader,
  ImageContainer,
  SearchBox,
  CandidateInfo,
  CondidateCellStyle,
  BoxStyled,
  IconColor,
  TableContainerStyle,
  TableCelltyle,
  SensorOccupiedIconStyle,
  CondidateNameWrapper,
  SensorCandidateWrapper,
} from "./CandidateStyles";
import { Paper } from "@mui/material";

function Candidate() {
  const contextData = useContext(EditInterviewerDetailsContext);
  console.log("endDateTime");
  console.log(contextData.endDateTime);

  function onKeyDown(event) {
    if (
      event.key === "Enter" &&
      (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(
        event.target.value
      ) ||
        /^[0-9]+$/.test(event.target.value))
    ) {
      // 👇 Get input value
      contextData.setLabel("Search");
      contextData.setLabelColour("#225dd3");

      getCandidate(event.target.value);
    } else if (event.key === "Enter") {
      contextData.setLabel("Seach by Email or Phone number");
      contextData.setLabelColour("#d82828");
    }
  }

  const getCandidate = async (value) => {
    contextData.setLabel(" Searching ");
    setTimeout(() => {
      axios
        .get(
          `https://mapii-recruitment-candidate.azurewebsites.net/candidate/${value}`,
          {
            responseType: "json",
          }
        )
        .then((response) => {
          contextData.setCandidate_Id(response.data.candidateId);
          contextData.setEmailId(response.data.emailId);
          contextData.setFirstName(response.data.firstName);
          contextData.setLastName(response.data.lastName);
          contextData.setMobileNumber(response.data.mobileNumber);
          contextData.setLabel("Found");
          contextData.setLabelColour("#548f2a");
        })
        .catch((error) => {
          if (!error.response) {
            contextData.setLabel(" Network Error ");
            contextData.setLabelColour("#d82828");
          } else if (
            error.response.status === 404 ||
            error.response.status === 400
          ) {
            contextData.setLabel(" No candidate found ");
            contextData.setLabelColour("#fb7107");
            // console.error("error status : " +errorStatus);
          } else {
            // console.error(errorStatus);
            contextData.setLabel(" Internal Server error ");
            contextData.setLabelColour("#d82828");
          }
        });
    }, 1000);
  };

  function CandidateDetailsTable() {
    return (
      <TableContainerStyle data-testid="tableContainerStyle">
        <Table sx={{ minWidth: 650, p: 50 }} aria-label="simple table">
          <TableBody>
            <div>
              <CandidateInfo>
                <SensorCandidateWrapper align="left">
                  <IconColor>
                    <SensorOccupiedIconStyle />
                  </IconColor>
                  <CondidateNameWrapper>
                    {contextData.firstName} {contextData.lastName}
                    <div style={{ fontSize: "9px", color: "rgb(32, 92, 233)" }}>
                      Candidate
                    </div>
                  </CondidateNameWrapper>
                </SensorCandidateWrapper>
                <TableHead align="center">
                  <TableRow>
                    <TableCelltyle align="center">
                      <CondidateCellStyle data-testid="CondidateCellStyle">
                        ID
                      </CondidateCellStyle>
                    </TableCelltyle>
                    <TableCelltyle align="center">
                      <CondidateCellStyle>Email</CondidateCellStyle>
                    </TableCelltyle>
                    <TableCelltyle align="center">
                      <CondidateCellStyle>Phone number</CondidateCellStyle>
                    </TableCelltyle>
                  </TableRow>
                </TableHead>
                <TableRow
                  sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                >
                  <TableCelltyle sx={{ m: 50 }} component="th" scope="row">
                    {contextData.candidate_Id}
                  </TableCelltyle>
                  <TableCelltyle component="th" scope="row">
                    {contextData.emailId}
                  </TableCelltyle>
                  <TableCelltyle component="th" scope="row">
                    {/* {candidateDetails.mobileNumber} */}
                    {contextData.mobileNumber}
                  </TableCelltyle>
                </TableRow>
              </CandidateInfo>
            </div>
          </TableBody>
        </Table>
      </TableContainerStyle>
    );
  }

  function ImageSeenCandidateNames() {
    if (contextData.label === "Found") {
      return (
        <TableContainerStyle data-testid="tableContainerStyle">
          <Table sx={{ minWidth: 650, p: 50 }} aria-label="simple table">
            <TableBody>
              <div>
                <CandidateInfo>
                  <SensorCandidateWrapper align="left">
                    <IconColor>
                      <SensorOccupiedIconStyle />
                    </IconColor>
                    <CondidateNameWrapper>
                      {contextData.firstName} {contextData.lastName}
                      <div
                        style={{ fontSize: "9px", color: "rgb(32, 92, 233)" }}
                      >
                        Candidate
                      </div>
                    </CondidateNameWrapper>
                  </SensorCandidateWrapper>
                  <TableHead align="center">
                    <TableRow>
                      <TableCelltyle align="center">
                        <CondidateCellStyle data-testid="CondidateCellStyle">
                          ID
                        </CondidateCellStyle>
                      </TableCelltyle>
                      <TableCelltyle align="center">
                        <CondidateCellStyle>Email</CondidateCellStyle>
                      </TableCelltyle>
                      <TableCelltyle align="center">
                        <CondidateCellStyle>Phone number</CondidateCellStyle>
                      </TableCelltyle>
                    </TableRow>
                  </TableHead>
                  <TableRow
                    sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                  >
                    <TableCelltyle sx={{ m: 50 }} component="th" scope="row">
                      {contextData.candidate_Id}
                    </TableCelltyle>
                    <TableCelltyle component="th" scope="row">
                      {contextData.emailId}
                    </TableCelltyle>
                    <TableCelltyle component="th" scope="row">
                      {/* {candidateDetails.mobileNumber} */}
                      {contextData.mobileNumber}
                    </TableCelltyle>
                  </TableRow>
                </CandidateInfo>
              </div>
            </TableBody>
          </Table>
        </TableContainerStyle>
      );
    }
    return (
      <>
        <ImageContainer data-testid="testImage" img src={broSvg} />
        <br />
        Search Candidate by their email
        <br />
        or phone number
      </>
    );
  }

  return (
    <ContentWrapper data-testid="contentWrapper">
      <BoxStyled>
        {/* <ContentHeader data-testid="contentHeader">
          <SearchBox
            label={contextData.label}
            onKeyDown={onKeyDown}
            data-testid="searchCandidate"
            component={Paper}
            elevation={3}
            InputLabelProps={{
              style: { color: contextData.labelColour },
            }}
            endAdornment={<SearchIcon sx={{ color: "var(--disabled)" }} />}
          />
        </ContentHeader>
        <br /> */}
        {/* {ImageSeenCandidateNames()} */}
        {CandidateDetailsTable()}
      </BoxStyled>
      <div styles={{ padding: "50px" }}>
        <Typography
          variant="subtitle2"
          sx={{ marginTop: "2rem", paddingBottom: "1rem" }}
        >
          Special instructions
        </Typography>
        <Box boxShadow={3}>
          <TextField
            value={contextData.candidateAdditionalNote}
            onChange={(event) =>
              contextData.setCandidateAdditionalNote(event.target.value)
            }
            // placeholder="Enter instructions for recruiters"
            label="Type the special instructions"
            fullWidth
            variant="outlined"
            inputProps={{
              style: {
                background: "var(--bg-primary)",
                // width: "190%",
                marginLeft: "auto",
                marginRight: "auto",
              },
            }}
          />
        </Box>
      </div>
    </ContentWrapper>
  );
}
export default Candidate;
