
import styles from "styled-components";
import { styled } from "@mui/material/styles";
import InputBase from "@mui/material/InputBase";
import Box from "@mui/material/Box";
import TableContainer from "@mui/material/TableContainer";
import TableCell from "@mui/material/TableCell";
import { Card, Stack, TextField } from "@mui/material";
import SensorOccupiedIcon from "@mui/icons-material/SensorOccupied";

export const ContentWrapper = styled(Card)`
  padding: 2rem 3rem;
`;

// export const ContentWrapper = styles.div`

// //   margin-bottom: 40%;
// //   margin-left: 30%;
// //   margin-right: 30%;
//   margin-top: 5%;
//   text-align: center;
//   font-size: 25px;
//   width:95%;

// `;
export const BoxStyled = styled(Box)`
  /* margin-top: 2%; */

  text-align: center;
  font-size: 25px;
  /* box-shadow: 1px 1px 10px #888888; */
  background-color: white;
  padding: 20px;
  min-width: 60%;
  /* margin-left: -8%; */
  transform: "translate(-50%, -50%)";
`;

export const ContentHeader = styles.h1`
   font-size: 20px;
   text-align: left;
 `;

export const ImageContainer = styles.img`

   width:20%;
  
 `;

export const SearchBox = styled(TextField)`
  background: var(--bg-primary);

  width: 100%;
  margin-left: auto;
  margin-right: auto;
  margin-top: 2%;
  font-size: larger;
`;

export const CandidateInfo = styles.div`

  font-weight: bolder;
  font-size: large;
  margin-left:2%;
  margin-top:2%;

`;

export const CondidateCellStyle = styles.div`
  color:blue;
  font-weight: bold;
`;

export const TableContainerStyle = styled(TableContainer)`
  margin-left: auto;
  margin-right: auto;
  max-width: 90%;
`;

export const TableCelltyle = styled(TableCell)`
  padding-left: 70px;
  padding-right: 70px;
  max-width: 90%;
`;

export const SensorCandidateWrapper = styled("div")`
  display: flex;
`;

export const CondidateNameWrapper = styled("div")`
  margin-left: 2px;
  margin-top: 2px;
  font-size: 12px;
`;

export const IconColor = styles.div`  
   color:white;
   height:35px;
   width:35px;
   padding:2px;
   border-radius:50%;
   background-color:rgb(32, 92, 233);

`;

export const SensorOccupiedIconStyle = styled(SensorOccupiedIcon)`
  font-size: x-large;
  /* margin-left: 2px; */
  margin-right: auto;
`;
