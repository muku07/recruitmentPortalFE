
import Candidate from  "../..";


import {
    render,
    fireEvent,
    screen,
    shallow,
    getByTestId,
  } from "@testing-library/react";
  import "@testing-library/jest-dom/extend-expect";
  import React from "react";


  
let component;

beforeEach(() => {
  component = render(<Candidate />);
});

test("Testing that the Candidate page renders", () => {
  render(<Candidate />);
});



test("SearchBox should have Search on screen", () => {
  const headerElement = component.getByTestId("searchCandidate")[0];
  expect(headerElement.textContent).toBe(" Search  Search ");
});

test("Testing that the Candidate page renders an image", () => {
  // render(<Candidate />);

  const logo = component.getByRole('img');
  expect(logo).toHaveAttribute('src', 'bro.svg');

  // const Candidate = screen.getAllByTestId('testImage');
  // expect(Candidate).toHaveAttribute('src', '<img class="sc-gsnTZi dzXbuM" data-testid="testImage" src="bro.svg" />');
  

});

