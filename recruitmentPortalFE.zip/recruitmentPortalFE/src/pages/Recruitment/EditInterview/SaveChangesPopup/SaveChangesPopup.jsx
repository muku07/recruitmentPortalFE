import axios from "axios";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import { Button } from "@mui/material";
import { useContext } from "react";
import { ScheduleInterviewContext } from "../Context/InterviewEditDetailsContext";
import { DateTime } from "luxon";
import { useNavigate } from "react-router-dom";
export default function InformativeSaveChangesPopup() {
  const contextData = useContext(ScheduleInterviewContext);
  const navigate = useNavigate();
  function SaveChangesEvent() {
    const convertStartDateTimeStringToDate = new Date(
      contextData.startDateTime
    );
    const dateStartString = convertStartDateTimeStringToDate
      .toISOString()
      .replace("T", " ")
      .substr(0, 19);

    console.log("dateStartString");
    const convertEndDateTimeStringToDate = new Date(contextData.endDateTime);
    const dateEndString = convertEndDateTimeStringToDate
      .toISOString()
      .replace("T", " ")
      .substr(0, 19);

    axios
      .put(
        `http://localhost:8080/interviews/${contextData.candidateInterviewId}`,
        {
          candidate: {
            candidateId: contextData.candidate_Id,
          },
          technology: {
            techId: contextData.technologies[0].techId,
          },
          userIds: contextData.userId,
          interviewType: {
            interviewTypeId: 2,
          },
          interviewStartDateTime: dateStartString,
          interviewEndDateTime: dateEndString,
          additionalNote: contextData.instructionsComment,
          externalInterviewerEmailId: contextData.externalInterviewerEmailId,
          interviewerAdditionalNote: contextData.interviewerAdditionalNote,
          candidateAdditionalNote: contextData.candidateAdditionalNote,
        }
      )
      .then((response) => {
        console.log(response);
      })
      .catch((error) => {
        console.error(error);
      });
  }
  function NavigateEvent() {
    // navigate("/recruitment");
  }
  function handleCloseCancelPopup() {
    contextData.setOpenCancelPopup(false);
  }
  function handleAgreedSavePopup() {
    contextData.setOpenSaveChangesPopup(false);
    SaveChangesEvent();
  }
  function handleCloseSavePopup() {
    contextData.setOpenSaveChangesPopup(false);
  }

  function SavePopup() {
    console.log(contextData.candidate_Id);
    function canSave() {
      if (
        contextData.technologies.length === 0 ||
        contextData.candidate_Id === undefined
      ) {
        return 0;
      } else {
        return 1;
      }
    }
    return (
      <>
        {!canSave() ? (
          <Dialog
            open={contextData.openSaveChangesPopup}
            onClose={handleCloseCancelPopup}
            aria-labelledby="alert-dialog-title-save"
            aria-describedby="alert-dialog-description-save"
          >
            <DialogTitle id="alert-dialog-title-save">{"ALERT!"}</DialogTitle>
            <DialogContent>
              <DialogContentText data-testid="alert-dialog-description-save">
                {contextData.technologies.length === 0 ? (
                  <>Technology has no assigned value</>
                ) : (
                  <></>
                )}
                {contextData.candidate_Id === undefined ? (
                  <>
                    <br />
                    You have not selected a Candidate
                  </>
                ) : (
                  <></>
                )}
              </DialogContentText>
            </DialogContent>
            <DialogActions>
              <Button variant="contained" onClick={handleCloseSavePopup}>
                Cancel
              </Button>
            </DialogActions>
          </Dialog>
        ) : (
          <Dialog
            open={contextData.openSaveChangesPopup}
            onClose={handleCloseCancelPopup}
            aria-labelledby="alert-dialog-title-save"
            aria-describedby="alert-dialog-description-save"
          >
            <DialogTitle id="alert-dialog-title-save">{"ALERT!"}</DialogTitle>
            <DialogContent>
              <DialogContentText data-testid="alert-dialog-description-save">
                Changes to this interview will be saved, this action cannot be{" "}
                <br />
                undone, do you wish to continue?
              </DialogContentText>
            </DialogContent>
            <DialogActions>
              <Button variant="contained" onClick={handleCloseSavePopup}>
                Cancel
              </Button>
              <Button
                variant="outlined"
                onClick={handleAgreedSavePopup}
                autoFocus
              >
                Schedule Interview
              </Button>
            </DialogActions>
          </Dialog>
        )}
      </>
    );
  }

  return <>{SavePopup()}</>;
}
