import React, { createContext } from "react";

export const EditInterviewerDetailsContext = createContext();
export const ScheduleInterviewContext = createContext();
