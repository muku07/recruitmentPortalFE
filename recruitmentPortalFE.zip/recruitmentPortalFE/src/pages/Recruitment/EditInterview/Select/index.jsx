import { DateTime } from "luxon";
import React, { useState, useEffect } from "react";
import Card from "@mui/material/Card";
import Typography from "@mui/material/Typography";
import Chip from "@mui/material/Chip";
import ClearRoundedIcon from "@mui/icons-material/ClearRounded";
import { MuiChipsInput } from "mui-chips-input";
import { useContext } from "react";
import { EditInterviewerDetailsContext } from "../Context/InterviewEditDetailsContext";
import { TextField, Box } from "@mui/material";
import { Paper } from "@mui/material";
import axios from "axios";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Selected, { SelectChangeEvent } from "@mui/material/Select";
import { makeStyles } from "@material-ui/core/styles";

const useStyles = makeStyles((theme) => ({
  chip: {
    marginTop: "5px",
    backgroundColor: "white",
    border: "2px solid blue",
    color: "blue",
    fontWeight: 300,
  },
}));

function Select() {
  const contextData = useContext(EditInterviewerDetailsContext);
  const classes = useStyles();

  // const shortDate = interview.date.toLocaleString(DateTime.DATE_SHORT);
  // const longDate = interview.date.toLocaleString(DateTime.DATE_HUGE);

  const [tempInterviewers, setTempInterviewers] = React.useState([]);

  const shortDate = contextData.startDateTime.toLocaleString(
    DateTime.DATE_SHORT
  );
  const longDate = contextData.startDateTime.toLocaleString(DateTime.DATE_HUGE);

  function submitSearch(event) {
    contextData.setCurrentChip(event.target.value);

    axios
      .post(
        "https://mapii-portal-profile-service.azurewebsites.net/searchProfiles",
        {
          activateFlag: true,

          firstName: contextData.currentChip,
        }
      )
      .then((response) => {
        setTempInterviewers(response.data);

        console.log("contextData interviewers");
        console.log(contextData.interviewers);
      })
      .catch((error) => {
        // handle the error
      });
  }

  const handleChanges = (event: SelectChangeEvent) => {
    console.log("event");
    console.log(event.target.value);
    console.log("tempInterviewers");
    console.log(tempInterviewers);

    let selectedEmail = event.target.value;

    const selectedObject = tempInterviewers.find(
      (item) => item.emailId === selectedEmail
    );

    // console.log("selectedObject");
    // console.log(selectedObject);

    contextData.setUserId((prevState) => [...prevState, selectedObject.userId]);
    // console.log("user id");
    // console.log(contextData.userId);

    contextData.setInterviewers((prevState) =>
      prevState.length == 0 ? [selectedObject] : [...prevState, selectedObject]
    );

    contextData.setChips([...contextData.chips, event.target.value]);
    contextData.setCurrentChip("");
  };

  function handleDeleteChip(index) {
    // contextData.setChips(contextData.chips.filter((chip, i) => i !== index));
    const email = contextData.chips[index];
    // Find the index of the interviewer object with a matching email property
    const interviewerIndex = contextData.interviewers.findIndex(
      (interviewer) => interviewer.emailId === email
    );
    // filter out the selected interviewer from the "interviewers" state in the context data
    contextData.setInterviewers((prevState) => {
      return prevState.filter((interviewer, i) => i !== interviewerIndex);
    });
    // filter out the selected email from the "chips" state in the context data
    contextData.setChips((prevState) => {
      return prevState.filter((chip, i) => i !== index);
    });
  }
  function handleKeyPress(event) {
    if (event.key === "Enter") {
      event.preventDefault();
    }
  }

  useEffect(() => {
    let chipsTemp = contextData.interviewers.map((i) => i.emailId);
    contextData.setChips(chipsTemp);
  }, [contextData.interviewers]);
  return (
    <Card sx={{ padding: "2rem 4rem", gap: "1rem" }}>
      <Typography variant="subtitle2">
        The field below displays interviewers available for:
        <b
          onMouseOver={(e) => (e.currentTarget.innerText = longDate)}
          onMouseLeave={(e) => (e.currentTarget.innerText = shortDate)}
        >
          {" " + shortDate}
        </b>
        <br />
        <br />
        {tempInterviewers.length && contextData.currentChip.length > 0 ? (
          <Box
            sx={{
              width: "30%",
              height: "50px",
              display: "flex",
              justifyContent: "flex-end",
            }}
          >
            <FormControl style={{ width: "100%", fontSize: "12px" }}>
              <InputLabel
                id="demo-simple-select-label"
                style={{ fontSize: "12px" }}
              >
                interviewer/s
              </InputLabel>
              <Selected
                onChange={handleChanges}
                style={{
                  width: "100%",
                  height: "50px",
                  backgroundColor: "rgb(240,240,240)",
                  fontSize: "12px",
                }}
              >
                {tempInterviewers.map((item) => (
                  <MenuItem
                    key={item.id}
                    value={item.emailId}
                    style={{ fontSize: "12px" }}
                  >
                    {item.emailId}
                  </MenuItem>
                ))}
              </Selected>
            </FormControl>
          </Box>
        ) : (
          <></>
        )}
      </Typography>
      <Typography
        variant="subtitle2"
        sx={{ marginTop: "2rem", paddingBottom: "1rem" }}
      >
        Search for interviewers inside orignization
      </Typography>
      <Box boxShadow={3}>
        <TextField
          // label="Add Interviewer"
          value={contextData.currentChip}
          onChange={(event) => submitSearch(event)}
          label="Type the Interviewers name"
          fullWidth
          onKeyPress={handleKeyPress}
          inputProps={{
            style: {
              background: "var(--bg-primary)",
              width: "100%",
              marginLeft: "auto",
              marginRight: "auto",
            },
          }}
        />
      </Box>

      <div>
        {contextData.chips.map((chip, index) => (
          <Chip
            key={chip}
            label={chip}
            onDelete={() => handleDeleteChip(index)}
            className={classes.chip}
          />
        ))}
      </div>

      <Typography
        variant="subtitle2"
        sx={{ marginTop: "2rem", paddingBottom: "1rem" }}
      >
        To invite external people to meeting, enter below.
      </Typography>
      <Box boxShadow={3}>
        <MuiChipsInput
          value={contextData.externalInterviewerEmailId
            .split(",")
            .filter((item) => item !== "")}
          onChange={(value) =>
            contextData.setExternalInterviewerEmailId(value.join(","))
          }
          // label="Type external email/s then press 'enter'"
          label=" "
          // placeholder="Type external email/s then press 'enter'"
          // sx={inputStyle}
          // sx={inputStyle}
          fullWidth
          inputProps={{
            style: {
              background: "var(--bg-primary)",
              width: "100%",
              marginLeft: "auto",
              marginRight: "auto",
            },
          }}
          sx={{
            display: "flex",
            flexWrap: "wrap",
            alignItems: "flex-start",
          }}
        />
      </Box>
      <Typography
        variant="subtitle2"
        sx={{ marginTop: "2rem", paddingBottom: "1rem" }}
      >
        Special instructions
      </Typography>
      <Box boxShadow={3}>
        <TextField
          value={contextData.instructionsComment}
          onChange={(event) =>
            contextData.setInstructionsComment(event.target.value)
          }
          label="Enter instructions for recruiters"
          fullWidth
          variant="outlined"
          inputProps={{
            style: {
              background: "var(--bg-primary)",
              width: "100%",
              marginLeft: "auto",
              marginRight: "auto",
            },
          }}
        />
      </Box>
    </Card>
  );
}
export default Select;

// import { DateTime } from "luxon";
// import React, { useState } from "react";
// import Card from "@mui/material/Card";
// import Typography from "@mui/material/Typography";
// import Chip from "@mui/material/Chip";
// import ClearRoundedIcon from "@mui/icons-material/ClearRounded";
// import { MuiChipsInput } from "mui-chips-input";
// import { SearchBox } from "./SelectElements";
// import {Person, Interview, Panel} from "../Interfaces"

// interface Props {
//   candidate: Person;
//   interview: Interview;
//   panel: Panel;
// }

// const inputStyle = {
//   width: "100%",
//   padding: "0 0.3rem 0 0.4rem",
//   marginTop: "0.75rem",
//   background: "var(--bg-primary)",
//   borderRadius: "0.3rem",
// };
// const customChip = (_, props) => {
//   return (
//     <Chip
//       {...props}
//       sx={{
//         color: "var(--accent)",
//         fontWeight: 600,
//         border: "2px solid",
//         background: "#fff",
//       }}
//       deleteIcon={
//         <ClearRoundedIcon sx={{ color: "var(--accent) !important" }} />
//       }
//     />
//   );
// };
// function Select({ candidate, interview, panel }: Props) {

//   const shortDate = interview.date.toLocaleString(DateTime.DATE_SHORT);
//   const longDate = interview.date.toLocaleString(DateTime.DATE_HUGE);

//   return (
//     <Card sx={{ padding: "2rem 4rem", gap: "1rem" }}>
//       <Typography variant="h6">Select interviewers</Typography>
//       <Typography variant="subtitle2">
//         The field below displays interviewers available for:
//         <b
//           onMouseOver={(e) => (e.currentTarget.innerText = longDate)}
//           onMouseLeave={(e) => (e.currentTarget.innerText = shortDate)}
//         >
//           {" " + shortDate}
//         </b>
//       </Typography>

//       <MuiChipsInput
//         value={panel.interviewers}
//         onChange={(interviewerName) => panel.setInterviewers(interviewerName)}
//         label="Enter interviewers name"
//         sx={inputStyle}
//         renderChip={customChip}
//       />
//       <Typography variant="subtitle2" sx={{ marginTop: "2rem" }}>
//         To invite external people to meeting, enter below.
//       </Typography>
//       <MuiChipsInput
//         value={panel.extInterviewers}
//         onChange={(value) => {
//           panel.setExtInterviewers(value);
//         }}
//         label="People outside the organisation"
//         sx={inputStyle}
//         renderChip={customChip}
//       />
//     </Card>
//   );
// }
// export default Select;
