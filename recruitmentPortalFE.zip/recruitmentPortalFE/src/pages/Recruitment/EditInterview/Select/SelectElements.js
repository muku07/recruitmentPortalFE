import { styled } from "@mui/material/styles";
import InputBase from "@mui/material/InputBase";

export const SearchBox = styled(InputBase)`
  padding: 0 0.3rem 0 0.4rem;
  background: var(--bg-primary);
  border-radius: 0.3rem;
  width: 30%;
`;
