import { styled } from "@mui/material/styles";
import {Card, StepConnector, stepConnectorClasses, colors} from "@mui/material";

export const CardContainer = styled(Card)`
    padding: 2rem 5rem ;
`;

export const SummaryTitle = styled('div')`
    font-size: 1.4rem;
    font-weight: 500
`;

export const FieldSpan = styled('span')`
    margin-right: 1rem;
    color: #205CE9;
    font-weight: 500

`;