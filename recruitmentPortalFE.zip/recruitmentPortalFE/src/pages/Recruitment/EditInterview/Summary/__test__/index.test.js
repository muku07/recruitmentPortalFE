import InterviewSummary from "../";
import { render, screen } from "@testing-library/react";
import { DateTime } from "luxon";
import dayjs from 'dayjs';

const data = {
    candidate : {
        candidate:"sam",
        candidateID:1,
    },
    interview : {
        date: DateTime.now(),
        startTime: DateTime.now(),
        endTime: DateTime.now(),
        jobTitle: "Job title",
        assessmentForm: "Assessment Form",
        assessmentFormID: 1,
    },
    panel : {
        interviewers: ["i1", "i2", "i3"],
        extInterviewers: ["iex1", "iex2", "iex3"],
    },
    comment : { 
        comment: "Comment",
        setComment: ()=>{}
    },
    page : {
        page: 3,
        setPage: ()=>{}
    }
}

const RenderComponent = () => {
    render(<InterviewSummary 
        candidate={data.candidate}
        interview={data.interview}
        panel={data.panel}
        comment={data.comment}
        page = {data.page}
    />)
}

const TestComponent = (id, expected) => {
    const text = screen.getByTestId(id)
    expect(text.textContent).toBe(expected)
}


test("Test candidate ID and Name", async ()=> {
    RenderComponent()
    TestComponent("candidateID", data.candidate.candidateID.toString())
    TestComponent("candidate", data.candidate.candidate)  
})


test("Test Interview Details", async ()=> {
    RenderComponent()
    TestComponent("date", data.interview.date.toLocaleString(DateTime.DATE_SHORT))
    TestComponent("time", data.interview.startTime.toLocaleString(DateTime.TIME_SIMPLE) + " - " + data.interview.endTime.toLocaleString(DateTime.TIME_SIMPLE))
    TestComponent("type", data.interview.assessmentForm)
    TestComponent("jobtitle", data.interview.jobTitle)
})

test("Test Panel Details", async ()=> {
    RenderComponent()
    TestComponent("interviewers", data.panel.interviewers.join(", "))
    TestComponent("extInterviewers", data.panel.extInterviewers.join(", "))
})