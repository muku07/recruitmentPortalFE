import * as React from "react";
import { useState, useEffect } from "react";
import { DateTime } from "luxon";
import { useNavigate, useLocation } from "react-router-dom";
import TabContext from "@mui/lab/TabContext";
import axios from "axios";
import dayjs, { Dayjs } from "dayjs";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import { Stepper, Step, StepLabel, Grid, Button } from "@mui/material";
import Summary from "./Summary";
import Select from "./Select";
import Candidate from "./Candidate";
import Details from "./Details";
import {
  EditInterviewerDetailsContext,
  ScheduleInterviewContext,
} from "./Context/InterviewEditDetailsContext";
import InformativeSaveChangesPopup from "./SaveChangesPopup/SaveChangesPopup";
import {
  ContentWrapper,
  StyledTab,
  StyledTabList,
  TitleContainer,
  ViewTabPanel,
} from "./InterviewStyles";

const TabViewStatus = {
  candidate: "Select Candidate",
  details: "Set the details",
  interviewers: "Select interviewers",
  summary: "Summary",
};

function EditInterview() {
  const navigate = useNavigate();
  const useLocationData = useLocation();
  // console.log("useLocationData");
  // console.log(useLocationData);

  console.log("useLocationData.state");
  console.log(useLocationData.state);

  // console.log("useLocationData.state.data.state");
  // console.log(useLocationData.state.data.state);

  // console.log("useLocationData.state.data.state.interviewType");
  // console.log(useLocationData.state.data.state.interviewType);

  // console.log("useLocationData.state.data.state.interviewEndDateTime");
  // console.log(useLocationData.state.data.state.interviewEndDateTime);

  // console.log("useLocationData.state.data.state.interviewStartDateTime");
  // console.log(useLocationData.state.data.state.interviewStartDateTime);

  // console.log("useLocationData.state.data.state.candidate");
  // console.log(useLocationData.state.data.state.candidate);

  // console.log("useLocationData.state.interviewers");
  // console.log(useLocationData.state.interviewers);

  // console.log("useLocationData.state.inteviewersOutside");
  // console.log(useLocationData.state.inteviewersOutside);

  const [label, setLabel] = useState("Found");
  const [labelColour, setLabelColour] = useState("");
  const [emailId, setEmailId] = React.useState(
    useLocationData.state.data.state.candidate.emailId
  );

  const [firstName, setFirstName] = React.useState(
    useLocationData.state.data.state.candidate.firstName
  );
  const [lastName, setLastName] = React.useState(
    useLocationData.state.data.state.candidate.lastName
  );
  const [candidate_Id, setCandidate_Id] = React.useState(
    useLocationData.state.data.state.candidate.candidateId
  );
  const [mobileNumber, setMobileNumber] = React.useState(
    useLocationData.state.data.state.candidate.mobileNumber
  );
  const [startDateTime, setStartDateTime] = React.useState(
    useLocationData.state.data.state.interviewStartDateTime
  );
  const [endDateTime, setEndDateTime] = React.useState(
    useLocationData.state.data.state.interviewEndDateTime
  );
  const [jobTitle, setJobTitle] = React.useState(
    useLocationData.state.data.state.interviewType.interviewTypeName
  );
  // const [technologies, setTechnologies] = React.useState("");
  const [technologies, setTechnologies] = React.useState([]);
  // const [interviewers, setInterviewers] = React.useState([]);
  const [interviewers, setInterviewers] = React.useState(
    useLocationData.state.interviewers
  );

  const [userId, setUserId] = React.useState(
    useLocationData.state.data.state.userIds
  );

  // this cannot be populated at this time without having the comma separated values
  // from the interview details page, at this moment in time the calendar
  // the current data coming is a carbon copy of the internal interviewers

  const [internalInterviewerEmailId, setInternalInterviewerEmailId] =
    React.useState("");
  // const [externalInterviewerEmailId, setExternalInterviewerEmailId] =
  //   React.useState("");
  const [externalInterviewerEmailId, setExternalInterviewerEmailId] =
    React.useState(useLocationData.state.data.state.externalInterviewerEmailId);

  // chips is the value for the colleciton of interviewers on the select interviewers page
  // it fills the data for the internal interviewers, this will have to be populated
  // with the data of  useLocationData.state.interviewers however, it crashes the page
  // when done directly in to the array
  const [chips, setChips] = useState([]);
  const [currentChip, setCurrentChip] = useState("");
  const [interviewTypeName, setInterviewTypeName] =
    React.useState("Assestment one");
  const [instructionsComment, setInstructionsComment] = React.useState(
    useLocationData.state.data.state.additionalNote
  );
  const [openCancelPopup, setOpenCancelPopup] = React.useState(false);
  const [openSaveChangesPopup, setOpenSaveChangesPopup] = React.useState(false);
  const [view, setView] = useState(TabViewStatus.candidate);
  const [page, setPage] = useState(0);
  const [assessmentForm, SetAssessmentForm] = useState([{}]);
  const [assessmentFormID, SetAssessmentFormID] = useState();
  const [candidateInterviewId, setCandidateInterviewId] = useState(
    useLocationData.state.data.state.candidateInterviewId
  );

  const [candidateAdditionalNote, setCandidateAdditionalNote] =
    React.useState("");
  const [interviewerAdditionalNote, setInterviewerAdditionalNote] =
    React.useState("");

  function PageStepper() {
    return (
      <>
        <EditInterviewerDetailsContext.Provider
          value={{
            page,
            setPage,
            label,
            setLabel,
            labelColour,
            setLabelColour,
            emailId,
            setEmailId,
            firstName,
            setFirstName,
            lastName,
            setLastName,
            candidate_Id,
            setCandidate_Id,
            mobileNumber,
            setMobileNumber,
            startDateTime,
            setStartDateTime,
            endDateTime,
            setEndDateTime,
            jobTitle,
            setJobTitle,
            technologies,
            setTechnologies,
            interviewers,
            setInterviewers,
            instructionsComment,
            setInstructionsComment,
            candidateAdditionalNote,
            setCandidateAdditionalNote,
            interviewerAdditionalNote,
            setInterviewerAdditionalNote,
            interviewTypeName,
            setInterviewTypeName,
            assessmentForm,
            SetAssessmentForm,
            assessmentFormID,
            SetAssessmentFormID,
            externalInterviewerEmailId,
            setExternalInterviewerEmailId,
            internalInterviewerEmailId,
            setInternalInterviewerEmailId,
            chips,
            setChips,
            currentChip,
            setCurrentChip,
            setUserId,
            userId,
          }}
        >
          {page == 0 ? <Candidate /> : <></>}
          {page == 1 ? <Details /> : <></>}
          {page == 2 ? <Select /> : <></>}
          {page == 3 ? <Summary /> : <></>}
        </EditInterviewerDetailsContext.Provider>
      </>
    );
  }
  let nextPage = () => {
    if (page < 3) setPage(page + 1);
  };

  let prevPage = () => {
    if (page > 0) setPage(page - 1);
  };

  function CancelEvent() {
    navigate("/recruitment");
  }

  function handleOpenCancelPopup() {
    setOpenCancelPopup(true);
  }

  function handleCloseCancelPopup() {
    setOpenCancelPopup(false);
  }
  function handleAgreedCancelPopup() {
    setOpenCancelPopup(false);
    CancelEvent();
  }

  function CancelPopup() {
    return (
      <>
        <Dialog
          open={openCancelPopup}
          onClose={handleCloseCancelPopup}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogTitle id="alert-dialog-title">{"ALERT!"}</DialogTitle>
          <DialogContent>
            <DialogContentText data-testid="alert-dialog-description">
              You will be redirected to the Interviews screen, progress <br />
              will not be saved. Do you wish to continue?
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button variant="contained" onClick={handleCloseCancelPopup}>
              Disagree
            </Button>
            <Button
              variant="outlined"
              onClick={handleAgreedCancelPopup}
              autoFocus
            >
              Agree
            </Button>
          </DialogActions>
        </Dialog>
      </>
    );
  }
  function PreviousButton() {
    if (page > 0) {
      return (
        <>
          <Button
            style={{ "margin-left": "5px" }}
            onClick={prevPage}
            variant="contained"
          >
            Previous
          </Button>
        </>
      );
    } else {
      return <></>;
    }
  }
  function NextButton() {
    if (page !== 3) {
      return (
        <>
          <Button onClick={nextPage} variant="contained" sx={{ ml: "0.5rem" }}>
            Next
          </Button>
        </>
      );
    } else {
      return <></>;
    }
  }
  function handleOpenSavePopup() {
    setOpenSaveChangesPopup(true);
  }
  function SaveButton() {
    if (page === 3) {
      return (
        <>
          <Button
            onClick={handleOpenSavePopup}
            variant="contained"
            sx={{ ml: "0.5rem" }}
            color="success"
          >
            Edit Interview
          </Button>

          <ScheduleInterviewContext.Provider
            value={{
              emailId,
              setEmailId,
              firstName,
              setFirstName,
              lastName,
              setLastName,
              candidate_Id,
              setCandidate_Id,
              mobileNumber,
              setMobileNumber,
              startDateTime,
              setStartDateTime,
              endDateTime,
              setEndDateTime,
              jobTitle,
              setJobTitle,
              technologies,
              setTechnologies,
              interviewers,
              setInterviewers,
              instructionsComment,
              setInstructionsComment,
              candidateAdditionalNote,
              setCandidateAdditionalNote,
              interviewerAdditionalNote,
              setInterviewerAdditionalNote,
              interviewTypeName,
              setInterviewTypeName,
              assessmentForm,
              SetAssessmentForm,
              assessmentFormID,
              SetAssessmentFormID,
              externalInterviewerEmailId,
              setExternalInterviewerEmailId,
              internalInterviewerEmailId,
              setInternalInterviewerEmailId,
              setUserId,
              userId,
              openCancelPopup,
              setOpenCancelPopup,
              openSaveChangesPopup,
              setOpenSaveChangesPopup,
              candidateInterviewId,
            }}
          >
            <InformativeSaveChangesPopup />
          </ScheduleInterviewContext.Provider>
        </>
      );
    } else {
      return <></>;
    }
  }

  useEffect(() => {}, [interviewers]);
  return (
    <>
      <main>
        <ContentWrapper>
          <Grid container>
            <Grid item md={6}>
              <TitleContainer>
                <span>Edit Interview</span>
              </TitleContainer>
            </Grid>
            <Grid
              item
              md={6}
              sx={{
                display: "flex",
                flexDirection: "row-reverse",
                alignItems: "center",
              }}
            >
              <div>
                <Button onClick={handleOpenCancelPopup} variant="outlined">
                  {" "}
                  Cancel{" "}
                </Button>
                {CancelPopup()}
                {PreviousButton()}
                {NextButton()}
                {SaveButton()}
              </div>
            </Grid>
          </Grid>

          <Stepper sx={{ mt: "1rem", mb: "1rem" }} activeStep={page}>
            <Step>
              <StepLabel>Select Candidate</StepLabel>
            </Step>

            <Step>
              <StepLabel>Set Details</StepLabel>
            </Step>

            <Step>
              <StepLabel>Select Interviewers</StepLabel>
            </Step>

            <Step>
              <StepLabel>Summary</StepLabel>
            </Step>
          </Stepper>

          {PageStepper()}

          <Grid container sx={{ mt: "2rem" }}>
            <Grid
              item
              md={12}
              sx={{
                display: "flex",
                flexDirection: "row-reverse",
                alignItems: "center",
              }}
            >
              <div>
                <Button onClick={handleOpenCancelPopup} variant="outlined">
                  {" "}
                  Cancel{" "}
                </Button>
                {CancelPopup()}
                {PreviousButton()}
                {NextButton()}
                {SaveButton()}
              </div>
            </Grid>
          </Grid>
        </ContentWrapper>
      </main>
    </>
  );
}
export default EditInterview;
