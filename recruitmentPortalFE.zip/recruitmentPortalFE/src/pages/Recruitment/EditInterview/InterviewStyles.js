import { styled } from "@mui/material/styles";
import TabList from "@mui/lab/TabList";
import Tab from "@mui/material/Tab";
import TabPanel from "@mui/lab/TabPanel";
import { Card, Stack, TextField } from "@mui/material";
// export const ContentWrapper = styled("div")`
//   margin: auto;
//   padding: 1.5rem 0rem;
//   height: auto;
//   width: 80%;
//   margin-bottom: 2rem;
// `;

export const ContentWrapper = styled("div")`
    padding: 2rem 3rem;

`;

export const TitleContainer = styled("div")`
  padding: 1rem 0rem;
  display: flex;
  align-items: center;
  gap: 8px;

  span {
    text-align: center;
    font-weight: 500;
    font-size: 1.5rem;
  }
`;

export const StyledTabList = styled(TabList)`
  min-height: 2rem;
  margin: 0.3rem 0;
`;

export const ViewTabPanel = styled(TabPanel)`
  padding: 0;
  margin-bottom: 1rem;
`;





export const StyledNameHeader = styled("h2")``;

export const StyledPositionHeader = styled("h6")`
  color: var(--accent);
`;

export const HeaderNameContainer = styled("div")`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;

  text-align: center;

  margin-bottom: 1rem;
`;


export const StyledTab = styled(Tab)`
  max-height: 2rem;
  &.Mui-selected {
    font-weight: 700;
  }
  & {
    max-height: 2rem;
    min-height: 2rem;
  }
`;

