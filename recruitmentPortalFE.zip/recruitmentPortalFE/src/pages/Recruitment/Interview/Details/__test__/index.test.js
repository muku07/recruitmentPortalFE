import Details from "../index";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { Routes, Route, MemoryRouter } from "react-router-dom";
import userEvent from '@testing-library/user-event';
import "@testing-library/jest-dom/extend-expect";
import { TextField } from "@mui/material";
import { CalendarPicker } from "@mui/x-date-pickers";
import { DateTime } from "luxon";
import dayjs, { Dayjs } from 'dayjs';

var date = DateTime.now();
var startTime = dayjs();
var endTime = dayjs();
var jobTitle = "";
var assessmentForm = "";
var assessmentFormID = "";

const renderComponent = () => {
    render (
        <MemoryRouter>
            <Routes>
                <Route
                    path="/"
                    element={<Details interview={{
                        date:date,
                        SetDate: (e => {date = e}),
                        startTime: dayjs(),
                        SetStartTime: (e => {startTime = e}),
                        endTime: dayjs(),
                        SetEndTime: (e => {endTime = e}),
                        jobTitle: "",
                        SetJobTitle: (e => {jobTitle = e}),
                        technology: "",
                        SetTechnology: (e => {assessmentForm = e}),
                        technologyId: -1,
                        SetTechnologyId: (e => {assessmentFormID = e})
                    }} />}
                    />
            </Routes>
        </MemoryRouter>
    )
};

async function TextFieldTest(testId, labelValue, testInputValue, testExpected) {
    renderComponent();

    var textField = await screen.findByLabelText(testId);
    var label = textField.childNodes[0];
    var input = textField.childNodes[1].childNodes[0];

    await userEvent.type(input, testInputValue);

    expect(textField).toBeInTheDocument();
    expect(label.textContent).toBe(labelValue);
    expect(input.value).toBe(testExpected);
}

test("Does component render?", async () => {
    renderComponent();
    
    var container = await screen.findByTestId("container");
    expect(container).toBeInTheDocument();
});

test("TextField: Job Title", async () => {
    TextFieldTest("jobTitleTextField", "Job Title", "Software Engineer", "Software Engineer");
});

test("Select: Technology", async () => {
    renderComponent();

    var selectDropdown = await screen.findByTestId("technologyDropdown");
    var label = selectDropdown.childNodes[0];
    
    expect(selectDropdown).toBeInTheDocument();
    expect(label.textContent).toBe("Technology");
});

test("TimePicker: Start Time", async () => {
    TextFieldTest("startTimePicker", "Start Time", "0937P", "09:37PM");
});

test("TimePicker: End Time", async () => {
    TextFieldTest("endTimePicker", "End Time", "1128P", "11:28PM");
});

test("CalendarPicker: Date", async () => {
    renderComponent();
    var calendarPicker = await screen.findByTestId("dateCalendarPicker");

    expect(calendarPicker.childNodes[0]).toBeInTheDocument();
});

test("TextField: Disabled Date", async () => {
    renderComponent();

    var textField = await screen.findByTestId("dateTextField");
    var label = textField.childNodes[0];
    var input = textField.childNodes[1].childNodes[0];

    expect(textField).toBeInTheDocument();
    expect(label.textContent).toBe("Date");
    expect(input.value).toBe((new Date()).toLocaleDateString('en-gb'));
});