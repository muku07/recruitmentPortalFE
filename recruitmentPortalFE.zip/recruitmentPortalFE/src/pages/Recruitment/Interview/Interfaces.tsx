import { DateTime } from "luxon";
import dayjs, { Dayjs } from 'dayjs';


export interface Person {
    candidate: string
    setCandidate(c : string): void;
    candidateID: number;
    setCandidateID(id : number): void;
}
  
export interface Interview{
    date: DateTime;
    SetDate(date: DateTime): void;
    startTime: DateTime;
    SetStartTime(time: DateTime): void;
    endTime: DateTime;
    SetEndTime(time: DateTime): void;
    jobTitle: string;
    SetJobTitle(job: string): void;
    technology: string;
    SetTechnology(type:string): void;
    technologyId: number;
    SetTechnology(type:number): void;
};
  
export interface Panel{
    interviewers: string[];
    setInterviewers(interviwers: string[]): void;
    extInterviewers: string[];
    setExtInterviewers(interviwers: string[]): void; 
}