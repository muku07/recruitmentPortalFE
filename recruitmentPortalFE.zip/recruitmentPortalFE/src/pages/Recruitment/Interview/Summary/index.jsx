import * as React from "react";
import { useContext } from "react";
import { CardContainer, FieldSpan, SummaryTitle } from "./SummaryStyles";
import { InterviewerDetailsContext } from "../Context/InterviewerDetailsContext";
import {
  Grid,
  Link,
  Step,
  StepContent,
  StepLabel,
  Stepper,
} from "@mui/material";

function InterviewSummary() {
  const contextData = useContext(InterviewerDetailsContext);
  let interviers = contextData.interviewers;
  let interviersOutside = contextData.externalInterviewerEmailId;
  const mapped = interviers.map((item) => `${item.firstName} ${item.lastName}`);
  const interviewees = mapped.join(", ");
  const mappedOutside = contextData.externalInterviewerEmailId.split(",");
  const intervieweesOutside = mappedOutside.join(", ");
  const DATETIME = new Date(contextData.endDateTime);
  const month = new Date(contextData.startDateTime).toLocaleString("default", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
  const timeStart = new Date(contextData.startDateTime).toLocaleString(
    "default",
    { hour: "numeric", minute: "numeric" }
  );
  const timeEnd = new Date(contextData.endDateTime).toLocaleString("default", {
    hour: "numeric",
    minute: "numeric",
  });
  function fullName() {
    return (
      <>
        {contextData.firstName} {contextData.lastName}
      </>
    );
  }

  return (
    <CardContainer>
      <SummaryTitle>Summary</SummaryTitle>
      <Stepper orientation="vertical" sx={{ mt: "2rem", mb: "1rem" }}>
        <Step active={true}>
          <StepLabel>
            <Grid container>
              <Grid item md={8}>
                {" "}
                Select Candidate{" "}
              </Grid>
              <Grid item md={4} sx={{ textAlign: "right" }}>
                {" "}
                <Link
                  onClick={(e) => {
                    contextData.setPage(0);
                  }}
                >
                  Return to step
                </Link>{" "}
              </Grid>
            </Grid>
          </StepLabel>
          <StepContent sx={{ p: "1rem" }}>
            <Grid container spacing={1}>
              <Grid item md={4}>
                <FieldSpan>ID: </FieldSpan>{" "}
                <span data-testid="candidateID">
                  {contextData.candidate_Id}
                </span>{" "}
              </Grid>
              <Grid item md={4}>
                <FieldSpan>Full Name: </FieldSpan>{" "}
                <span data-testid="candidate">{fullName()}</span>{" "}
              </Grid>
            </Grid>
          </StepContent>
        </Step>

        <Step active={true}>
          <StepLabel>
            <Grid container>
              <Grid item md={8}>
                {" "}
                Set Details{" "}
              </Grid>
              <Grid item md={4} sx={{ textAlign: "right" }}>
                {" "}
                <Link
                  onClick={(e) => {
                    contextData.setPage(1);
                  }}
                >
                  Return to step
                </Link>{" "}
              </Grid>
            </Grid>
          </StepLabel>
          <StepContent sx={{ p: "1rem" }}>
            <a
              style={{
                color: "blue",
                paddingRight: "10px",
              }}
            >
              Date:
            </a>
            {month}
            <a
              style={{
                color: "blue",
                paddingLeft: "40px",
                paddingRight: "10px",
              }}
            >
              Timeframe:
            </a>
            {timeStart} - {timeEnd}
            <a
              style={{
                color: "blue",
                paddingLeft: "40px",
                paddingRight: "10px",
              }}
            >
              Assestment form type:
            </a>
            {contextData.interviewTypeName}
            <br />
            <a
              style={{
                color: "blue",
                paddingRight: "10px",
              }}
            >
              Technology:
            </a>
            {contextData.technologies.map((item) => {
              return <>{item.techName}</>;
            })}
            {/* <a
              style={{
                color: "blue",
                paddingRight: "10px",
                paddingLeft: "72px",
              }}
            >
              Job Title:
            </a>
            {contextData.jobTitle} */}
          </StepContent>
        </Step>

        <Step active={true}>
          <StepLabel>
            <Grid container>
              <Grid item md={8}>
                {" "}
                Select Interviewers{" "}
              </Grid>
              <Grid item md={4} sx={{ textAlign: "right" }}>
                {" "}
                <Link
                  onClick={(e) => {
                    contextData.setPage(2);
                  }}
                >
                  Return to step
                </Link>{" "}
              </Grid>
            </Grid>
          </StepLabel>

          <StepContent sx={{ p: "1rem" }}>
            <Grid
              style={{
                padding: "10px",
              }}
              container
              spacing={1}
            >
              <a
                style={{
                  color: "blue",
                  paddingRight: "10px",
                }}
              >
                Interviewers:
              </a>
              {interviewees}
            </Grid>
            <Grid
              style={{
                padding: "10px",
              }}
              container
              spacing={1}
            >
              <a
                style={{
                  color: "blue",
                  paddingRight: "10px",
                }}
              >
                People outside the organization
              </a>
              {intervieweesOutside}
            </Grid>
          </StepContent>
        </Step>
      </Stepper>
    </CardContainer>
  );
}

export default InterviewSummary;
