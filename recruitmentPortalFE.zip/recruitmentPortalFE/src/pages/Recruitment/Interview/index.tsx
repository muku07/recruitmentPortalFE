import * as React from "react";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import { Stepper, Step, StepLabel, Grid, Button } from "@mui/material";
import Summary from "./Summary";
import Select from "./Select";
import Candidate from "./Candidate";
import Details from "./Details";
import {
  InterviewerDetailsContext,
  ScheduleInterviewContext,
} from "./Context/InterviewerDetailsContext";
import InformativeSaveChangesPopup from "./SaveChangesPopup/SaveChangesPopup";
import { ContentWrapper, TitleContainer } from "./InterviewStyles";

const TabViewStatus = {
  candidate: "Select Candidate",
  details: "Set the details",
  interviewers: "Select interviewers",
  summary: "Summary",
};

function Interview() {
  const navigate = useNavigate();
  const [label, setLabel] = useState(" Search ");
  const [labelColour, setLabelColour] = useState("");
  const [emailId, setEmailId] = React.useState("");
  const [firstName, setFirstName] = React.useState("");
  const [lastName, setLastName] = React.useState("");
  const [candidate_Id, setCandidate_Id] = React.useState();
  const [mobileNumber, setMobileNumber] = React.useState("");
  const [startDateTime, setStartDateTime] = React.useState(
    new Date().setHours(16, 0, 0, 0)
  );
  const [endDateTime, setEndDateTime] = React.useState(
    new Date().setHours(17, 0, 0, 0)
  );
  const [jobTitle, setJobTitle] = React.useState("");
  // const [technologies, setTechnologies] = React.useState("");
  const [technologies, setTechnologies] = React.useState([]);
  const [interviewers, setInterviewers] = React.useState([]);
  const [userId, setUserId] = React.useState([]);
  const [internalInterviewerEmailId, setInternalInterviewerEmailId] =
    React.useState("");
  const [externalInterviewerEmailId, setExternalInterviewerEmailId] =
    React.useState("");
  const [chips, setChips] = useState([]);
  const [currentChip, setCurrentChip] = useState("");
  const [interviewTypeName, setInterviewTypeName] =
    React.useState("Assestment one");
  const [instructionsComment, setInstructionsComment] = React.useState("");
  const [candidateAdditionalNote, setCandidateAdditionalNote] =
    React.useState("");
  const [interviewerAdditionalNote, setInterviewerAdditionalNote] =
    React.useState("");
  const [openCancelPopup, setOpenCancelPopup] = React.useState(false);
  const [openSaveChangesPopup, setOpenSaveChangesPopup] = React.useState(false);
  const [view, setView] = useState(TabViewStatus.candidate);
  const [page, setPage] = useState(0);
  const [assessmentForm, SetAssessmentForm] = useState([{}]);
  const [assessmentFormID, SetAssessmentFormID] = useState();

  function PageStepper() {
    return (
      <>
        <InterviewerDetailsContext.Provider
          value={{
            page,
            setPage,
            label,
            setLabel,
            labelColour,
            setLabelColour,
            emailId,
            setEmailId,
            firstName,
            setFirstName,
            lastName,
            setLastName,
            candidate_Id,
            setCandidate_Id,
            mobileNumber,
            setMobileNumber,
            startDateTime,
            setStartDateTime,
            endDateTime,
            setEndDateTime,
            jobTitle,
            setJobTitle,
            technologies,
            setTechnologies,
            interviewers,
            setInterviewers,
            instructionsComment,
            setInstructionsComment,
            candidateAdditionalNote,
            setCandidateAdditionalNote,
            interviewerAdditionalNote,
            setInterviewerAdditionalNote,
            interviewTypeName,
            setInterviewTypeName,
            assessmentForm,
            SetAssessmentForm,
            assessmentFormID,
            SetAssessmentFormID,
            externalInterviewerEmailId,
            setExternalInterviewerEmailId,
            internalInterviewerEmailId,
            setInternalInterviewerEmailId,
            chips,
            setChips,
            currentChip,
            setCurrentChip,
            setUserId,
            userId,
          }}
        >
          {page == 0 ? <Candidate /> : <></>}
          {page == 1 ? <Details /> : <></>}
          {page == 2 ? <Select /> : <></>}
          {page == 3 ? <Summary /> : <></>}
        </InterviewerDetailsContext.Provider>
      </>
    );
  }

  let nextPage = () => {
    if (page < 3) setPage(page + 1);
  };

  let prevPage = () => {
    if (page > 0) setPage(page - 1);
  };

  function CancelEvent() {
    navigate("/recruitment");
  }

  function handleOpenCancelPopup() {
    setOpenCancelPopup(true);
  }

  function handleCloseCancelPopup() {
    setOpenCancelPopup(false);
  }
  function handleAgreedCancelPopup() {
    setOpenCancelPopup(false);
    CancelEvent();
  }

  function CancelPopup() {
    return (
      <>
        <Dialog
          open={openCancelPopup}
          onClose={handleCloseCancelPopup}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogTitle id="alert-dialog-title">{"ALERT!"}</DialogTitle>
          <DialogContent>
            <DialogContentText data-testid="alert-dialog-description">
              You will be redirected to the Interviews screen, progress <br />
              will not be saved. Do you wish to continue?
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button variant="contained" onClick={handleCloseCancelPopup}>
              Disagree
            </Button>
            <Button
              variant="outlined"
              onClick={handleAgreedCancelPopup}
              autoFocus
            >
              Agree
            </Button>
          </DialogActions>
        </Dialog>
      </>
    );
  }
  function PreviousButton() {
    if (page > 0) {
      return (
        <>
          <Button
            style={{ "margin-left": "5px" }}
            onClick={prevPage}
            variant="contained"
          >
            Previous
          </Button>
        </>
      );
    } else {
      return <></>;
    }
  }
  function NextButton() {
    if (page !== 3) {
      return (
        <>
          <Button onClick={nextPage} variant="contained" sx={{ ml: "0.5rem" }}>
            Next
          </Button>
        </>
      );
    } else {
      return <></>;
    }
  }
  function handleOpenSavePopup() {
    setOpenSaveChangesPopup(true);
  }
  function SaveButton() {
    if (page === 3) {
      return (
        <>
          <Button
            onClick={handleOpenSavePopup}
            variant="contained"
            sx={{ ml: "0.5rem" }}
            color="success"
          >
            Schedule Interview
          </Button>

          <ScheduleInterviewContext.Provider
            value={{
              emailId,
              setEmailId,
              firstName,
              setFirstName,
              lastName,
              setLastName,
              candidate_Id,
              setCandidate_Id,
              mobileNumber,
              setMobileNumber,
              startDateTime,
              setStartDateTime,
              endDateTime,
              setEndDateTime,
              jobTitle,
              setJobTitle,
              technologies,
              setTechnologies,
              interviewers,
              setInterviewers,
              instructionsComment,
              setInstructionsComment,
              candidateAdditionalNote,
              setCandidateAdditionalNote,
              interviewerAdditionalNote,
              setInterviewerAdditionalNote,
              interviewTypeName,
              setInterviewTypeName,
              assessmentForm,
              SetAssessmentForm,
              assessmentFormID,
              SetAssessmentFormID,
              externalInterviewerEmailId,
              setExternalInterviewerEmailId,
              internalInterviewerEmailId,
              setInternalInterviewerEmailId,
              setUserId,
              userId,
              openCancelPopup,
              setOpenCancelPopup,
              openSaveChangesPopup,
              setOpenSaveChangesPopup,
            }}
          >
            <InformativeSaveChangesPopup />
          </ScheduleInterviewContext.Provider>
        </>
      );
    } else {
      return <></>;
    }
  }

  useEffect(() => {}, [interviewers]);
  return (
    <>
      <main>
        <ContentWrapper>
          <Grid container>
            <Grid item md={6}>
              <TitleContainer>
                <span>Schedule Interview</span>
              </TitleContainer>
            </Grid>
            <Grid
              item
              md={6}
              sx={{
                display: "flex",
                flexDirection: "row-reverse",
                alignItems: "center",
              }}
            >
              <div>
                <Button onClick={handleOpenCancelPopup} variant="outlined">
                  {" "}
                  Cancel{" "}
                </Button>
                {CancelPopup()}
                {PreviousButton()}
                {NextButton()}
                {SaveButton()}
              </div>
            </Grid>
          </Grid>

          <Stepper sx={{ mt: "1rem", mb: "1rem" }} activeStep={page}>
            <Step>
              <StepLabel>Select Candidate</StepLabel>
            </Step>

            <Step>
              <StepLabel>Set Details</StepLabel>
            </Step>

            <Step>
              <StepLabel>Select Interviewers</StepLabel>
            </Step>

            <Step>
              <StepLabel>Summary</StepLabel>
            </Step>
          </Stepper>

          {PageStepper()}

          <Grid container sx={{ mt: "2rem" }}>
            <Grid
              item
              md={12}
              sx={{
                display: "flex",
                flexDirection: "row-reverse",
                alignItems: "center",
              }}
            >
              <div>
                <Button onClick={handleOpenCancelPopup} variant="outlined">
                  {" "}
                  Cancel{" "}
                </Button>
                {CancelPopup()}
                {PreviousButton()}
                {NextButton()}
                {SaveButton()}
              </div>
            </Grid>
          </Grid>
        </ContentWrapper>
      </main>
    </>
  );
}
export default Interview;
