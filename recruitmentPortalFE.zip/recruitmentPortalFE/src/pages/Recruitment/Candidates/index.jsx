import * as React from "react";
import { useState } from "react";

export default function Candidates() {
    
    
    return (
        <>
        Candidates Tab
        </>
    )
}