import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Landing from "./pages/Landing";
import "bootstrap/dist/css/bootstrap.css";
import Home from "./pages/old/Homepage/Home";
import SupervisorDashboard from "./pages/old/SupervisorDashboard";
import LearnAndDev from "./pages/old/EngineerDashboard/LearningAndDevelopment";
import Faqs from "./pages/old/Homepage/FAQs";
import EssentialLinks from "./pages/old/EngineerDashboard/EssentialLinks";
import BlogModerator from "./pages/Blog/ModerateBlog";
import EngineerProfiles from "./pages/old/Homepage/EngineerProfiles";
import Certifications from "./pages/old/SupervisorDashboard/Certifications";
import Accelerator from "./pages/Accelerator";
import EngineerDashboard from "./pages/old/EngineerDashboard";
import BlogHome from "./pages/Blog";
import Myprofile from "./pages/old/EngineerDashboard/MyProfile";
import News from "./pages/old/Homepage/News";
import Article from "./pages/old/Homepage/News/Article";
// import RewardsandRecognition from "./pages/old/Homepage/RewardsandRecognition";
import EditUserProfile from "./pages/Profile/EditUserProfile";
import ManageProfiles from "./pages/old/SupervisorDashboard/ManageProfiles";
import { Layout } from "./components/Layout";
import ViewProfile from "./pages/Profile/ViewProfile";
import ActivateProfile from "./pages/old/SuperUserDashboard/ActivateProfiles";
import RegisterUser from "./pages/Profile/Dashboard/RegisterUser";
import ProtectedRoute from "./Services/Authentication/ProtectedRoute";
import ExitProfile from "./pages/Profile/Dashboard/Leaver";

import { MsalProvider } from "@azure/msal-react";
import AzureLogin from "./Services/Authentication/AzureLogIn";
import ReadBlog from "./pages/Blog/ReadBlog";
import AddBlog from "./pages/Blog/AddBlogs";
import ListProfiles from "./pages/Profile/Dashboard/ListProfiles";
import OldListProfiles from "./pages/Profile/Dashboard/OldListProfiles";
import ProfileDashboard from "./pages/Profile/Dashboard";
import Recruitment from "./pages/Recruitment";
import Interview from "./pages/Recruitment/Interview/index.tsx";
import InterviewDetails from "./pages/Recruitment/InterviewDetails/index";
import EditInterview from "./pages/Recruitment/EditInterview/index";
import InterviewMaterials from "./pages/Recruitment/InterviewMaterials/index";
import MaterialList from "./pages/Recruitment/Materials/index";

function App({ msalInstance }) {
  const ROLES = {
    vis: "ROLE_VISITOR",
    user: "ROLE_USER",
    admin: "ROLE_ADMIN",
    sUser: "ROLE_SUPER_USER",
    sVisor: "ROLE_SUPER_VISOR",
  };

  return (
    <MsalProvider instance={msalInstance}>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<AzureLogin />} />
          <Route path="/welcome" element={<Landing />} />

          {/* Header, sidebar and footer used on child pages */}
          <Route element={<Layout />}>
            {/* Protected routes with with visitor which is a fallback if login API fails return */}
            <Route
              element={
                <ProtectedRoute
                  allowedRoles={[
                    ROLES.vis,
                    ROLES.user,
                    ROLES.admin,
                    ROLES.sUser,
                    ROLES.sVisor,
                  ]}
                />
              }
            >
              <Route path="/home" element={<Home />} />
            </Route>

            {/* Protected routes with no roles, therefore all roles */}
            <Route
              element={
                <ProtectedRoute
                  allowedRoles={[
                    ROLES.user,
                    ROLES.admin,
                    ROLES.sUser,
                    ROLES.sVisor,
                  ]}
                />
              }
            >
              <Route path="/employee-profiles" element={<ProfileDashboard />} />
              <Route path="/view-profile" element={<ViewProfile />} />
              <Route path="/edit-user-profile" element={<EditUserProfile />} />
              <Route path="/dashboard" element={<SupervisorDashboard />} />
              <Route path="/learning-development" element={<LearnAndDev />} />
              <Route path="/faqs" element={<Faqs />} />
              <Route path="/essential-links" element={<EssentialLinks />} />
              <Route path="/certifications" element={<Certifications />} />
              <Route path="/news" element={<News />} />
              <Route path="/news/article" element={<Article />} />
              <Route path="/blogs" element={<BlogHome />} />
              <Route path="/blogs/add" element={<AddBlog />} />
              <Route path="/blogs/:blogId" element={<ReadBlog />} />
              <Route path="/accelerators" element={<Accelerator />} />
              <Route path="/recruitment" element={<Recruitment />} />
              <Route path="/recruitment/interview" element={<Interview />} />
              <Route
                path="/recruitment/interview-details"
                element={<InterviewDetails />}
              />
              <Route
                path="/recruitment/edit-details"
                element={<EditInterview />}
              />

              <Route
                path="/recruitment/interview-materials"
                element={<InterviewMaterials />}
              />
            </Route>

            <Route
              path="/recruitment/material-list"
              element={<MaterialList />}
            />

            <Route element={<ProtectedRoute allowedRoles={[ROLES.admin]} />}>
              {/* <Route
                path="/supervisor/accelerators"
                element={<Accelerator />}
              /> */}
              <Route
                path="/supervisor/blog-moderator"
                element={<BlogModerator />}
              />
              <Route
                path="/engineerdashboard"
                element={<EngineerDashboard />}
              />
              <Route path="/my-profile" element={<Myprofile />} />
              <Route path="/supervisor/manage" element={<ManageProfiles />} />
              <Route path="/engineers" element={<EngineerProfiles />} />
              <Route path="/superuser/activate" element={<ActivateProfile />} />
              <Route path="/superuser/exit-profile" element={<ExitProfile />} />
            </Route>
          </Route>

          <Route path="*" element={<p>There's nothing here: 404!</p>} />
        </Routes>
      </BrowserRouter>
    </MsalProvider>
  );
}

export default App;
